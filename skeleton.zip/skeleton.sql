-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2020 at 06:08 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skeleton`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `module` varchar(100) DEFAULT NULL,
  `controller` varchar(100) DEFAULT NULL,
  `method` varchar(100) DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `created_at` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`id`, `user_id`, `module`, `controller`, `method`, `activity`, `ip_address`, `created_at`) VALUES
(1, 1, NULL, 'users', 'login', 'Logged in.', '::1', 1592304925),
(2, 1, NULL, 'users', 'login', 'Logged in.', '::1', 1592323271),
(3, 3, NULL, 'users', 'login', 'Logged in.', '::1', 1592323336),
(4, 1, NULL, 'users', 'login', 'Logged in.', '::1', 1592324240);

-- --------------------------------------------------------

--
-- Table structure for table `entities`
--

CREATE TABLE `entities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `owner_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `type` enum('user','group','object') NOT NULL,
  `subtype` varchar(50) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `language` varchar(50) DEFAULT NULL,
  `privacy` tinyint(1) NOT NULL DEFAULT '2',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `updated_at` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `deleted_at` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `entities`
--

INSERT INTO `entities` (`id`, `parent_id`, `owner_id`, `type`, `subtype`, `username`, `language`, `privacy`, `enabled`, `deleted`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 0, 0, 'user', 'administrator', 'admin', 'english', 2, 1, 0, 1526871009, 0, 0),
(2, 0, 0, 'user', 'administrator', 'keshav', NULL, 2, 1, 0, 1592306887, 0, 0),
(3, 0, 0, 'user', 'regular', 'test1234', NULL, 2, 1, 0, 1592323181, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `guid` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `metadata`
--

CREATE TABLE `metadata` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `guid` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `value` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `objects`
--

CREATE TABLE `objects` (
  `guid` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` longtext,
  `content` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `name` varchar(100) NOT NULL,
  `value` longtext NOT NULL,
  `tab` varchar(50) NOT NULL DEFAULT '',
  `field_type` varchar(50) NOT NULL DEFAULT 'text',
  `options` varchar(255) NOT NULL DEFAULT '',
  `required` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`name`, `value`, `tab`, `field_type`, `options`, `required`) VALUES
('active_modules', 'a:4:{i:0;s:9:\"MediaFile\";i:1;s:5:\"dummy\";i:2;s:5:\"media\";i:3;s:9:\"media_old\";}', 'modules', 'text', '', 1),
('active_plugins', 'a:0:{}', 'plugins', 'text', '', 1),
('admin_email', 'admin@localhost', 'email', 'text', '', 1),
('allowed_types', 'gif|png|jpeg|jpg|pdf|doc|txt|docx|xls|zip|rar|xls|mp4', 'upload', 'text', '', 1),
('allow_multi_session', 'true', 'users', 'dropdown', 'a:2:{s:4:\"true\";s:12:\"lang:CSK_YES\";s:5:\"false\";s:11:\"lang:CSK_NO\";}', 1),
('allow_registration', 'true', 'users', 'dropdown', 'a:2:{s:4:\"true\";s:12:\"lang:CSK_YES\";s:5:\"false\";s:11:\"lang:CSK_NO\";}', 1),
('base_controller', 'welcome', 'general', 'dropdown', '', 1),
('email_activation', 'true', 'users', 'dropdown', 'a:2:{s:4:\"true\";s:12:\"lang:CSK_YES\";s:5:\"false\";s:11:\"lang:CSK_NO\";}', 1),
('google_analytics_id', 'UA-XXXXX-Y', 'general', 'text', '', 0),
('google_site_verification', '', 'general', 'text', '', 0),
('language', 'english', 'language', 'dropdown', 'a:2:{s:7:\"english\";s:7:\"english\";s:6:\"french\";s:6:\"french\";}', 1),
('languages', 'a:1:{i:0;s:7:\"english\";}', 'language', 'dropdown', '', 1),
('login_type', 'both', 'users', 'dropdown', 'a:3:{s:4:\"both\";s:13:\"lang:CSK_BOTH\";s:8:\"username\";s:23:\"lang:CSK_INPUT_USERNAME\";s:5:\"email\";s:28:\"lang:CSK_INPUT_EMAIL_ADDRESS\";}', 1),
('mail_protocol', 'mail', 'email', 'dropdown', 'a:3:{s:4:\"mail\";s:4:\"Mail\";s:4:\"smtp\";s:4:\"SMTP\";s:8:\"sendmail\";s:8:\"Sendmail\";}', 1),
('manual_activation', 'false', 'users', 'dropdown', 'a:2:{s:4:\"true\";s:12:\"lang:CSK_YES\";s:5:\"false\";s:11:\"lang:CSK_NO\";}', 1),
('max_height', '0', 'upload', 'number', '', 1),
('max_size', '0', 'upload', 'number', '', 1),
('max_width', '0', 'upload', 'number', '', 1),
('min_height', '0', 'upload', 'number', '', 1),
('min_width', '0', 'upload', 'number', '', 1),
('per_page', '10', 'general', 'dropdown', 'a:3:{i:10;i:10;i:20;i:20;i:30;i:30;}', 1),
('recaptcha_private_key', '', 'captcha', 'text', '', 0),
('recaptcha_site_key', '', 'captcha', 'text', '', 0),
('sendmail_path', '/usr/sbin/sendmail', 'email', 'text', '', 0),
('server_email', 'noreply@localhost', 'email', 'text', '', 1),
('site_author', 'Kader Bouyakoub', 'general', 'text', '', 0),
('site_description', 'A skeleton application for building CodeIgniter application.', 'general', 'text', '', 0),
('site_favicon', '', 'general', 'text', '', 0),
('site_keywords', 'these, are, site, keywords', 'general', 'text', '', 0),
('site_name', 'Skeleton', 'general', 'text', '', 1),
('smtp_crypto', 'none', 'email', 'dropdown', 'a:3:{s:4:\"none\";s:13:\"lang:CSK_NONE\";s:3:\"ssl\";s:3:\"SSL\";s:3:\"tls\";s:3:\"TLS\";}', 1),
('smtp_host', '', 'email', 'text', '', 0),
('smtp_pass', '', 'email', 'password', '', 0),
('smtp_port', '', 'email', 'text', '', 0),
('smtp_user', '', 'email', 'text', '', 0),
('theme', 'default', 'theme', 'text', '', 1),
('upload_path', 'content/uploads', 'upload', 'text', '', 0),
('use_captcha', 'false', 'captcha', 'dropdown', 'a:2:{s:4:\"true\";s:12:\"lang:CSK_YES\";s:5:\"false\";s:11:\"lang:CSK_NO\";}', 1),
('use_gravatar', 'false', 'users', 'dropdown', 'a:2:{s:4:\"true\";s:12:\"lang:CSK_YES\";s:5:\"false\";s:11:\"lang:CSK_NO\";}', 1),
('use_recaptcha', 'false', 'captcha', 'dropdown', 'a:2:{s:4:\"true\";s:12:\"lang:CSK_YES\";s:5:\"false\";s:11:\"lang:CSK_NO\";}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `relations`
--

CREATE TABLE `relations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `guid_from` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid_to` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `relation` varchar(100) NOT NULL,
  `created_at` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `updated_at` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `guid` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `first_name` varchar(32) NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `gender` enum('unspecified','male','female') NOT NULL DEFAULT 'unspecified',
  `online` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`guid`, `email`, `password`, `first_name`, `last_name`, `gender`, `online`) VALUES
(1, 'admin@localhost', '$2a$08$MnCsgx3mmz3khvfFfDaEi.BaVS.gXVY/aQ1TmYEJVSAxm3cvfgtQO', 'Admin', 'Skeleton', 'male', 1),
(2, 'keshavkantsingh2018@gmail.com', '$2a$08$6cKtdhFLK/EgJED1YqP89uHQFcP5M7.nDOgnUmkf01LqmWpvCy0m.', 'kesh', 'singh', 'unspecified', 0),
(3, 'test@1111.com', '$2a$08$QIXWj0w9wY5uqY9sDmtgCeCd1y2H5e3ADdgP.bkvjLIrU8bnGonxC', 'test', 'test', 'male', 0);

-- --------------------------------------------------------

--
-- Table structure for table `variables`
--

CREATE TABLE `variables` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `guid` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `value` longtext,
  `params` longtext,
  `created_at` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `updated_at` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `variables`
--

INSERT INTO `variables` (`id`, `guid`, `name`, `value`, `params`, `created_at`, `updated_at`) VALUES
(4, 1, 'online_token', '$P$B5JhPET8K5Wa1SRWkGYXWCu4NPldsI0', '::1', 1592324240, 1592402192);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entities`
--
ALTER TABLE `entities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_username` (`username`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`guid`);

--
-- Indexes for table `metadata`
--
ALTER TABLE `metadata`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_values` (`guid`,`name`);

--
-- Indexes for table `objects`
--
ALTER TABLE `objects`
  ADD PRIMARY KEY (`guid`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `relations`
--
ALTER TABLE `relations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`guid`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- Indexes for table `variables`
--
ALTER TABLE `variables`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_values` (`guid`,`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `entities`
--
ALTER TABLE `entities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `metadata`
--
ALTER TABLE `metadata`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `relations`
--
ALTER TABLE `relations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `variables`
--
ALTER TABLE `variables`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
