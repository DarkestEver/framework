<div class="container">
	<?php the_alert(); ?> 
	<?php the_content(); ?> 
</div>
<?php echo get_partial('footer'); ?> 
