<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-06-18 14:53:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-18 14:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-18 14:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-18 14:53:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-18 14:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-18 14:53:29 --> KB_Loader class Initialized
DEBUG - 2020-06-18 14:53:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-18 14:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-18 14:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-18 14:53:30 --> Hash class already loaded. Second attempt ignored.
DEBUG - 2020-06-18 14:53:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-18 14:53:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-18 14:53:30 --> Total execution time: 0.6904
DEBUG - 2020-06-18 14:53:30 --> KB_Loader class Initialized
DEBUG - 2020-06-18 14:53:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-18 14:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-18 14:53:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-18 14:53:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-18 14:53:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-18 14:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-18 14:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-18 14:53:30 --> KB_Loader class Initialized
DEBUG - 2020-06-18 14:53:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-18 14:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-18 14:53:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-18 14:53:31 --> User_agent class already loaded. Second attempt ignored.
