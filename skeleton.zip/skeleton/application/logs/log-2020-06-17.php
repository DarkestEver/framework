<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-06-17 15:55:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:55:48 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:55:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:55:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:55:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:55:49 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:55:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:55:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:55:49 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-17 15:55:49 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-17 15:55:49 --> Total execution time: 0.1882
DEBUG - 2020-06-17 15:56:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-17 15:56:01 --> 404 Page Not Found: Content/common
DEBUG - 2020-06-17 15:56:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-17 15:56:01 --> 404 Page Not Found: Content/common
DEBUG - 2020-06-17 15:56:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:56:32 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:56:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:56:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:32 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-17 15:56:32 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-17 15:56:32 --> Hash class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:56:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:56:32 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:56:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:56:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:32 --> Total execution time: 0.2135
DEBUG - 2020-06-17 15:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:56:33 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:56:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:56:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:33 --> Total execution time: 0.4523
DEBUG - 2020-06-17 15:56:33 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:56:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:56:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:33 --> Total execution time: 0.6245
DEBUG - 2020-06-17 15:56:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:56:34 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:56:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:56:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:56:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:34 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:56:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:56:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:56:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:30 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:30 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-17 15:57:30 --> 404 Page Not Found: 
DEBUG - 2020-06-17 15:57:37 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:37 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:38 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-17 15:57:39 --> 404 Page Not Found: Content/common
DEBUG - 2020-06-17 15:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-17 15:57:39 --> 404 Page Not Found: Content/common
DEBUG - 2020-06-17 15:57:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:42 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:42 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:43 --> Total execution time: 0.3521
DEBUG - 2020-06-17 15:57:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:43 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:43 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:43 --> Total execution time: 0.5797
DEBUG - 2020-06-17 15:57:43 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:43 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:44 --> Total execution time: 0.8663
DEBUG - 2020-06-17 15:57:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:45 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:45 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:47 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:47 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-17 15:57:47 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-17 15:57:47 --> Total execution time: 0.4353
DEBUG - 2020-06-17 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:48 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:48 --> Total execution time: 0.5897
DEBUG - 2020-06-17 15:57:48 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:49 --> Total execution time: 1.2077
DEBUG - 2020-06-17 15:57:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:49 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:50 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:57:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:57:50 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:57:50 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:57:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:57:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 15:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 15:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 15:58:17 --> KB_Loader class Initialized
DEBUG - 2020-06-17 15:58:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 15:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 15:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:58:17 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-17 15:58:17 --> 404 Page Not Found: 
DEBUG - 2020-06-17 16:07:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:07:42 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:07:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:07:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:42 --> Total execution time: 0.1922
DEBUG - 2020-06-17 16:07:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:07:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:07:42 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:07:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:07:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:42 --> Total execution time: 0.2340
DEBUG - 2020-06-17 16:07:42 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:07:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:07:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:42 --> Total execution time: 0.4312
DEBUG - 2020-06-17 16:07:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:07:51 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:07:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:52 --> Total execution time: 0.2162
DEBUG - 2020-06-17 16:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:07:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:07:52 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:07:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:52 --> Total execution time: 0.3133
DEBUG - 2020-06-17 16:07:52 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:07:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:07:52 --> Total execution time: 0.4436
DEBUG - 2020-06-17 16:12:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:12:55 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:12:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:12:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:12:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:12:55 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-17 16:12:55 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-17 16:12:55 --> Total execution time: 0.2727
DEBUG - 2020-06-17 16:12:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:12:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:12:56 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:12:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:12:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:12:56 --> Total execution time: 0.2575
DEBUG - 2020-06-17 16:12:56 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:12:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:12:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:12:56 --> Total execution time: 0.4494
DEBUG - 2020-06-17 16:13:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:13:09 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:13:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:13:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:13:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:13:09 --> Total execution time: 0.2203
DEBUG - 2020-06-17 16:13:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:13:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:13:10 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:13:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:13:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:13:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:13:10 --> Total execution time: 0.2724
DEBUG - 2020-06-17 16:13:10 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:13:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:13:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:13:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:13:10 --> Total execution time: 0.5272
DEBUG - 2020-06-17 16:14:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:14:07 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:14:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:14:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:07 --> Total execution time: 0.2638
DEBUG - 2020-06-17 16:14:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:14:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:14:07 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:14:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:14:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:08 --> Total execution time: 0.2138
DEBUG - 2020-06-17 16:14:08 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:14:08 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:14:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:08 --> Total execution time: 0.3664
DEBUG - 2020-06-17 16:14:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:14:13 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:14:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:14:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:13 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-17 16:14:13 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-17 16:14:13 --> Total execution time: 0.3423
DEBUG - 2020-06-17 16:14:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:14:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:14:14 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:14:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:14:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:14 --> Total execution time: 0.2342
DEBUG - 2020-06-17 16:14:14 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:14:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:14:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:14:14 --> Total execution time: 0.3923
DEBUG - 2020-06-17 16:18:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:18:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:18:09 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:18:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:18:09 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:18:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:18:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:18:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:18:10 --> Total execution time: 0.4233
DEBUG - 2020-06-17 16:18:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:18:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:18:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:18:10 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:18:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:18:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:18:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:41:19 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:41:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:41:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:19 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-17 16:41:19 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-17 16:41:19 --> Total execution time: 0.2697
DEBUG - 2020-06-17 16:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:41:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:41:19 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:41:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:41:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:19 --> Total execution time: 0.2131
DEBUG - 2020-06-17 16:41:19 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:41:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:41:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:20 --> Total execution time: 0.3739
DEBUG - 2020-06-17 16:41:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:41:38 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:41:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:41:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:38 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-17 16:41:38 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-17 16:41:38 --> Total execution time: 0.2111
DEBUG - 2020-06-17 16:41:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:41:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:41:38 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:41:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:41:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:39 --> Total execution time: 0.2052
DEBUG - 2020-06-17 16:41:39 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:41:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:41:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:41:39 --> Total execution time: 0.4260
DEBUG - 2020-06-17 16:43:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:43:19 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:43:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:43:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:43:19 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-17 16:43:19 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-17 16:43:19 --> Could not find the language line "title"
ERROR - 2020-06-17 16:43:19 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\application\modules\media\controllers\Content.php 105
DEBUG - 2020-06-17 16:51:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:51:23 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:51:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:51:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:51:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:53:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 16:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 16:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 16:53:27 --> KB_Loader class Initialized
DEBUG - 2020-06-17 16:53:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 16:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 16:53:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 16:53:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:02:55 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:02:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:02:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:02:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:03:03 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:03:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:03:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:03 --> Total execution time: 0.2370
DEBUG - 2020-06-17 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:03:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:03:04 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:03:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:03:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:04 --> Total execution time: 0.4062
DEBUG - 2020-06-17 17:03:04 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:03:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:03:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:04 --> Total execution time: 0.6239
DEBUG - 2020-06-17 17:03:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:03:07 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:03:08 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:08 --> Total execution time: 0.2635
DEBUG - 2020-06-17 17:03:08 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:03:08 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:03:08 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:03:08 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:08 --> Total execution time: 0.2930
DEBUG - 2020-06-17 17:03:08 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:03:08 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:08 --> Total execution time: 0.4854
DEBUG - 2020-06-17 17:03:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:03:36 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:03:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:36 --> Total execution time: 0.2471
DEBUG - 2020-06-17 17:03:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:03:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:03:37 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:03:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:37 --> Total execution time: 0.3846
DEBUG - 2020-06-17 17:03:37 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:03:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:03:37 --> Total execution time: 0.5590
DEBUG - 2020-06-17 17:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:04:51 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:04:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:04:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:04:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:04:51 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:04:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:04:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:04:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:04:51 --> Total execution time: 0.2355
DEBUG - 2020-06-17 17:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:04:52 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:04:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:04:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:04:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:04:52 --> Total execution time: 0.3808
DEBUG - 2020-06-17 17:04:52 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:04:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:04:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:04:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:04:52 --> Total execution time: 0.5811
DEBUG - 2020-06-17 17:05:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:05:06 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:05:06 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:05:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:05:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:05:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:05:06 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:05:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:05:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:05:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:05:07 --> Total execution time: 0.3209
DEBUG - 2020-06-17 17:05:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:05:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:05:07 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:05:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:05:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:05:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:05:07 --> Total execution time: 0.3267
DEBUG - 2020-06-17 17:05:07 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:05:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:05:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:05:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:05:07 --> Total execution time: 0.5452
DEBUG - 2020-06-17 17:05:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:05:14 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:05:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:05:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:05:15 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-17 17:05:15 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-17 17:05:15 --> Could not find the language line "title"
ERROR - 2020-06-17 17:05:15 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\content\modules\MediaFile\controllers\Content.php 105
DEBUG - 2020-06-17 17:06:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:06:07 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:06:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:06:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:06:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:06:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:06:13 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:06:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:06:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:06:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:06:13 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-17 17:06:13 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-17 17:06:13 --> Could not find the language line "title"
ERROR - 2020-06-17 17:06:13 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\application\modules\media_old\controllers\Content.php 105
DEBUG - 2020-06-17 17:12:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:12:51 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:12:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:12:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:12:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:12:51 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-17 17:12:51 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-17 17:12:51 --> Could not find the language line "title"
ERROR - 2020-06-17 17:12:51 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\content\modules\MediaFile\controllers\Content.php 105
DEBUG - 2020-06-17 17:12:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:12:56 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:12:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:12:56 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-17 17:12:56 --> Severity: Notice --> Undefined property: Content::$_module C:\xampp\htdocs\skeleton\application\modules\media\controllers\Content.php 70
DEBUG - 2020-06-17 17:12:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:12:56 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:12:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:12:56 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-17 17:12:56 --> Severity: Notice --> Undefined property: Content::$_module C:\xampp\htdocs\skeleton\application\modules\media\controllers\Content.php 70
DEBUG - 2020-06-17 17:37:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:37:15 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:37:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:37:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:37:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 15:37:16 --> Total execution time: 0.3195
DEBUG - 2020-06-17 17:37:16 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:37:16 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:37:16 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:37:16 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:37:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:37:16 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:37:16 --> Total execution time: 0.2844
DEBUG - 2020-06-17 17:37:16 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:37:16 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:37:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:37:16 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:37:16 --> Total execution time: 0.4860
DEBUG - 2020-06-17 17:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:55:40 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:55:40 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:55:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:55:40 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:55:40 --> Total execution time: 0.2454
DEBUG - 2020-06-17 17:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:55:40 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:55:41 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:55:41 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:55:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:55:41 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:55:41 --> Total execution time: 0.3222
DEBUG - 2020-06-17 17:55:41 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:55:41 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:55:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:55:41 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:55:41 --> Total execution time: 0.4998
DEBUG - 2020-06-17 17:56:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-17 17:56:11 --> 404 Page Not Found: Test1234/index
DEBUG - 2020-06-17 17:56:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:56:23 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:56:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:56:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:24 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-17 17:56:24 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-17 17:56:24 --> Total execution time: 0.2873
DEBUG - 2020-06-17 17:56:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:56:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:56:24 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:56:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:56:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:24 --> Total execution time: 0.3870
DEBUG - 2020-06-17 17:56:24 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:56:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:56:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:24 --> Total execution time: 0.6647
DEBUG - 2020-06-17 17:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:56:54 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:56:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:56:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:54 --> Total execution time: 0.3282
DEBUG - 2020-06-17 17:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:56:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:56:55 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:56:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:56:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:55 --> Total execution time: 0.3254
DEBUG - 2020-06-17 17:56:55 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:56:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:56:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:56:55 --> Total execution time: 0.5047
DEBUG - 2020-06-17 17:59:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:59:55 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:59:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:59:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:59:55 --> Total execution time: 0.2517
DEBUG - 2020-06-17 17:59:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:59:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 17:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 17:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 17:59:56 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:59:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:59:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:59:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:59:56 --> Total execution time: 0.3500
DEBUG - 2020-06-17 17:59:56 --> KB_Loader class Initialized
DEBUG - 2020-06-17 17:59:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 17:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 17:59:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:59:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 17:59:56 --> Total execution time: 0.5505
DEBUG - 2020-06-17 20:18:21 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 20:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 20:18:21 --> No URI present. Default controller set.
DEBUG - 2020-06-17 20:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 20:18:21 --> KB_Loader class Initialized
DEBUG - 2020-06-17 20:18:21 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 20:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 20:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 20:18:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 20:18:21 --> Total execution time: 0.3001
DEBUG - 2020-06-17 20:18:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 20:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 20:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 20:18:26 --> KB_Loader class Initialized
DEBUG - 2020-06-17 20:18:26 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 20:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 20:18:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 20:18:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 20:18:26 --> Total execution time: 0.2512
DEBUG - 2020-06-17 20:18:26 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 20:18:26 --> UTF-8 Support Enabled
DEBUG - 2020-06-17 20:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 20:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-17 20:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 20:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-17 20:18:26 --> KB_Loader class Initialized
DEBUG - 2020-06-17 20:18:26 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 20:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 20:18:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 20:18:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 20:18:26 --> Total execution time: 0.3809
DEBUG - 2020-06-17 20:18:26 --> KB_Loader class Initialized
DEBUG - 2020-06-17 20:18:26 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-17 20:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-17 20:18:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 20:18:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-17 20:18:26 --> Total execution time: 0.5806
