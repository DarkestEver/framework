<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-16 12:47:42 --> Unable to connect to the database
DEBUG - 2020-06-16 12:47:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-06-16 12:47:51 --> Unable to connect to the database
DEBUG - 2020-06-16 12:47:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-06-16 12:48:11 --> Unable to connect to the database
DEBUG - 2020-06-16 12:48:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-06-16 12:51:24 --> Unable to connect to the database
DEBUG - 2020-06-16 12:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:52:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:52:36 --> No URI present. Default controller set.
DEBUG - 2020-06-16 12:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:52:36 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:52:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:52:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:52:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:52:36 --> Total execution time: 0.2835
DEBUG - 2020-06-16 12:55:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:17 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 12:55:17 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 12:55:17 --> Total execution time: 0.2438
DEBUG - 2020-06-16 12:55:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:25 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 12:55:25 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 12:55:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:25 --> No URI present. Default controller set.
DEBUG - 2020-06-16 12:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:25 --> Total execution time: 0.2979
DEBUG - 2020-06-16 12:55:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:33 --> Total execution time: 0.1913
DEBUG - 2020-06-16 12:55:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:33 --> Total execution time: 0.2315
DEBUG - 2020-06-16 12:55:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:33 --> Total execution time: 0.3948
DEBUG - 2020-06-16 12:55:37 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:37 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:37 --> Total execution time: 0.2104
DEBUG - 2020-06-16 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:38 --> Total execution time: 0.2420
DEBUG - 2020-06-16 12:55:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:38 --> Total execution time: 0.3859
DEBUG - 2020-06-16 12:55:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:46 --> Total execution time: 0.2360
DEBUG - 2020-06-16 12:55:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:47 --> Total execution time: 0.2310
DEBUG - 2020-06-16 12:55:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:47 --> Total execution time: 0.3687
DEBUG - 2020-06-16 12:55:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:55:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:55:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:55:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:55:48 --> Total execution time: 0.2479
DEBUG - 2020-06-16 12:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:08 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:08 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:08 --> Total execution time: 0.2528
DEBUG - 2020-06-16 12:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:08 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:09 --> Total execution time: 0.1905
DEBUG - 2020-06-16 12:58:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:09 --> Total execution time: 0.4169
DEBUG - 2020-06-16 12:58:16 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:16 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:16 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:17 --> Total execution time: 0.1886
DEBUG - 2020-06-16 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:17 --> Total execution time: 0.2379
DEBUG - 2020-06-16 12:58:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:17 --> Total execution time: 0.4687
DEBUG - 2020-06-16 12:58:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:20 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 12:58:20 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 12:58:20 --> Total execution time: 0.2479
DEBUG - 2020-06-16 12:58:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:20 --> Total execution time: 0.2776
DEBUG - 2020-06-16 12:58:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:21 --> Total execution time: 0.4656
DEBUG - 2020-06-16 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:24 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 12:58:24 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 12:58:24 --> Total execution time: 0.2831
DEBUG - 2020-06-16 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:24 --> Total execution time: 0.2327
DEBUG - 2020-06-16 12:58:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:25 --> Total execution time: 0.3797
DEBUG - 2020-06-16 12:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:31 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 12:58:31 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 12:58:31 --> Total execution time: 0.2514
DEBUG - 2020-06-16 12:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:32 --> Total execution time: 0.1999
DEBUG - 2020-06-16 12:58:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:32 --> Total execution time: 0.3416
DEBUG - 2020-06-16 12:58:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:51 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 12:58:51 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 12:58:51 --> Total execution time: 0.2428
DEBUG - 2020-06-16 12:58:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:58:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:51 --> Total execution time: 0.2276
DEBUG - 2020-06-16 12:58:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:58:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:58:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:58:51 --> Total execution time: 0.3614
DEBUG - 2020-06-16 12:59:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:00 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 12:59:00 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 12:59:00 --> Total execution time: 0.3179
DEBUG - 2020-06-16 12:59:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:01 --> Total execution time: 0.3302
DEBUG - 2020-06-16 12:59:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:01 --> Total execution time: 0.5258
DEBUG - 2020-06-16 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:09 --> Total execution time: 0.1716
DEBUG - 2020-06-16 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:10 --> Total execution time: 0.2888
DEBUG - 2020-06-16 12:59:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:10 --> Total execution time: 0.4645
DEBUG - 2020-06-16 12:59:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 10:59:18 --> Total execution time: 0.4492
DEBUG - 2020-06-16 12:59:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:18 --> Total execution time: 0.1900
DEBUG - 2020-06-16 12:59:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:19 --> Total execution time: 0.3655
DEBUG - 2020-06-16 12:59:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:36 --> Total execution time: 0.2288
DEBUG - 2020-06-16 12:59:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:36 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:36 --> Total execution time: 0.2737
DEBUG - 2020-06-16 12:59:36 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:36 --> Total execution time: 0.4168
DEBUG - 2020-06-16 12:59:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:43 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:43 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:43 --> Total execution time: 0.2116
DEBUG - 2020-06-16 12:59:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:44 --> Total execution time: 0.2972
DEBUG - 2020-06-16 12:59:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:44 --> Total execution time: 0.4613
DEBUG - 2020-06-16 12:59:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:53 --> Total execution time: 0.1948
DEBUG - 2020-06-16 12:59:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:54 --> Total execution time: 0.2103
DEBUG - 2020-06-16 12:59:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:54 --> Total execution time: 0.3715
DEBUG - 2020-06-16 12:59:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:56 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 12:59:56 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 12:59:56 --> Total execution time: 0.2201
DEBUG - 2020-06-16 12:59:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:56 --> Total execution time: 0.2235
DEBUG - 2020-06-16 12:59:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:57 --> Total execution time: 0.4073
DEBUG - 2020-06-16 12:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:59 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:59 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 12:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 12:59:59 --> Total execution time: 0.2111
DEBUG - 2020-06-16 12:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 12:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 12:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 12:59:59 --> KB_Loader class Initialized
DEBUG - 2020-06-16 12:59:59 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:00:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:00 --> Total execution time: 0.2420
DEBUG - 2020-06-16 13:00:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:00:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:00:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:00 --> Total execution time: 0.3757
DEBUG - 2020-06-16 13:00:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:00:06 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:00:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:00:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:07 --> Total execution time: 0.1886
DEBUG - 2020-06-16 13:00:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:00:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:00:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:00:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:00:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:07 --> Total execution time: 0.2867
DEBUG - 2020-06-16 13:00:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:00:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:00:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:07 --> Total execution time: 0.4696
DEBUG - 2020-06-16 13:00:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:00:13 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:00:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:00:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:13 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:00:13 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:00:13 --> Total execution time: 0.2296
DEBUG - 2020-06-16 13:00:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:00:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:00:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:00:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:00:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:14 --> Total execution time: 0.2198
DEBUG - 2020-06-16 13:00:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:00:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:00:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:00:14 --> Total execution time: 0.4328
DEBUG - 2020-06-16 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:01 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:01:01 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 13:01:01 --> Could not find the language line "CSK_PLUGINS_SELECT_ALL"
DEBUG - 2020-06-16 13:01:01 --> Total execution time: 0.1998
DEBUG - 2020-06-16 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:01 --> Total execution time: 0.2491
DEBUG - 2020-06-16 13:01:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:01 --> Total execution time: 0.4898
DEBUG - 2020-06-16 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:05 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:01:05 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 13:01:05 --> Could not find the language line "CSK_PLUGINS_SELECT_ALL"
DEBUG - 2020-06-16 13:01:05 --> Total execution time: 0.2247
DEBUG - 2020-06-16 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:05 --> Total execution time: 0.2071
DEBUG - 2020-06-16 13:01:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:06 --> Total execution time: 0.3529
DEBUG - 2020-06-16 13:01:08 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:08 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:09 --> Total execution time: 0.2073
DEBUG - 2020-06-16 13:01:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:09 --> Total execution time: 0.2412
DEBUG - 2020-06-16 13:01:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:09 --> Total execution time: 0.4674
DEBUG - 2020-06-16 13:01:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:13 --> Total execution time: 0.2065
DEBUG - 2020-06-16 13:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:27 --> Total execution time: 0.1827
DEBUG - 2020-06-16 13:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:27 --> Total execution time: 0.2294
DEBUG - 2020-06-16 13:01:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:28 --> Total execution time: 0.4770
DEBUG - 2020-06-16 13:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:45 --> Total execution time: 0.2115
DEBUG - 2020-06-16 13:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:01:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:45 --> Total execution time: 0.2590
DEBUG - 2020-06-16 13:01:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:01:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:01:45 --> Total execution time: 0.4163
DEBUG - 2020-06-16 13:03:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:03:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:03:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:03:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:03 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:03:03 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 13:03:03 --> Could not find the language line "CSK_PLUGINS_SELECT_ALL"
DEBUG - 2020-06-16 13:03:03 --> Total execution time: 0.2209
DEBUG - 2020-06-16 13:03:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:03:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:03:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:03:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:03:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:04 --> Total execution time: 0.2586
DEBUG - 2020-06-16 13:03:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:03:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:03:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:04 --> Total execution time: 0.4714
DEBUG - 2020-06-16 13:03:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:03:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:03:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:03:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:07 --> Total execution time: 0.1876
DEBUG - 2020-06-16 13:03:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:03:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:03:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:03:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:03:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:07 --> Total execution time: 0.2291
DEBUG - 2020-06-16 13:03:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:03:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:03:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:07 --> Total execution time: 0.4459
DEBUG - 2020-06-16 13:03:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:03:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:03:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:09 --> Total execution time: 0.1779
DEBUG - 2020-06-16 13:03:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:03:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:03:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:03:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:09 --> Total execution time: 0.2338
DEBUG - 2020-06-16 13:03:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:03:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:03:10 --> Total execution time: 0.4472
DEBUG - 2020-06-16 13:21:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:21:35 --> No URI present. Default controller set.
DEBUG - 2020-06-16 13:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:21:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:21:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:21:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:21:35 --> Total execution time: 0.2440
DEBUG - 2020-06-16 13:21:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:21:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:21:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:21:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:21:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:21:51 --> Total execution time: 0.2328
DEBUG - 2020-06-16 13:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:21:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:21:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:21:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:21:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:21:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:21:52 --> Total execution time: 0.2195
DEBUG - 2020-06-16 13:21:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:21:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:21:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:21:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:21:52 --> Total execution time: 0.3767
DEBUG - 2020-06-16 13:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:22:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:22:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:22:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:00 --> Total execution time: 0.1942
DEBUG - 2020-06-16 13:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:22:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:22:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:22:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:01 --> Total execution time: 0.3049
DEBUG - 2020-06-16 13:22:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:22:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:01 --> Total execution time: 0.4469
DEBUG - 2020-06-16 13:22:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:22:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:22:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:22:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:48 --> Total execution time: 0.2043
DEBUG - 2020-06-16 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:22:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:22:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:22:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:48 --> Total execution time: 0.2920
DEBUG - 2020-06-16 13:22:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:22:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:22:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:48 --> Total execution time: 0.4506
DEBUG - 2020-06-16 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:22:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:22:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:56 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:22:56 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:22:56 --> Total execution time: 0.2440
DEBUG - 2020-06-16 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:22:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:22:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:56 --> Total execution time: 0.3112
DEBUG - 2020-06-16 13:22:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:22:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:22:56 --> Total execution time: 0.4698
DEBUG - 2020-06-16 13:23:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:23:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:23:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:23:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:04 --> Total execution time: 0.1866
DEBUG - 2020-06-16 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:23:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:23:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:23:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:05 --> Total execution time: 0.2283
DEBUG - 2020-06-16 13:23:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:23:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:23:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:05 --> Total execution time: 0.3944
DEBUG - 2020-06-16 13:23:08 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:23:08 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:23:08 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:09 --> Total execution time: 0.2218
DEBUG - 2020-06-16 13:23:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:23:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:23:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:23:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:09 --> Total execution time: 0.2952
DEBUG - 2020-06-16 13:23:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:23:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:23:09 --> Total execution time: 0.4529
DEBUG - 2020-06-16 13:23:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:23:59 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:23:59 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:24:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:00 --> Total execution time: 0.2432
DEBUG - 2020-06-16 13:24:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:24:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:24:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:24:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:24:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:00 --> Total execution time: 0.2556
DEBUG - 2020-06-16 13:24:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:24:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:24:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:00 --> Total execution time: 0.4740
DEBUG - 2020-06-16 13:24:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:24:05 --> No URI present. Default controller set.
DEBUG - 2020-06-16 13:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:24:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:24:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:24:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:05 --> Total execution time: 0.2281
DEBUG - 2020-06-16 13:24:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:24:07 --> No URI present. Default controller set.
DEBUG - 2020-06-16 13:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:24:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:24:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:24:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:07 --> Total execution time: 0.2314
DEBUG - 2020-06-16 13:24:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:24:28 --> No URI present. Default controller set.
DEBUG - 2020-06-16 13:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:24:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:24:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:24:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:28 --> Total execution time: 0.1748
DEBUG - 2020-06-16 13:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:24:29 --> No URI present. Default controller set.
DEBUG - 2020-06-16 13:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:24:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:24:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:24:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:24:29 --> Total execution time: 0.3180
DEBUG - 2020-06-16 13:26:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:18 --> Total execution time: 0.2167
DEBUG - 2020-06-16 13:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:18 --> Total execution time: 0.2250
DEBUG - 2020-06-16 13:26:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:18 --> Total execution time: 0.3650
DEBUG - 2020-06-16 13:26:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:25 --> Total execution time: 0.1942
DEBUG - 2020-06-16 13:26:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:25 --> Total execution time: 0.1888
DEBUG - 2020-06-16 13:26:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:25 --> Total execution time: 0.3339
DEBUG - 2020-06-16 13:26:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:28 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:26:28 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:26:28 --> Total execution time: 0.3075
DEBUG - 2020-06-16 13:26:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:28 --> Total execution time: 0.2364
DEBUG - 2020-06-16 13:26:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:29 --> Total execution time: 0.3795
DEBUG - 2020-06-16 13:26:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:34 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:26:34 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:26:34 --> Total execution time: 0.2435
DEBUG - 2020-06-16 13:26:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:34 --> Total execution time: 0.2480
DEBUG - 2020-06-16 13:26:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:35 --> Total execution time: 0.4082
DEBUG - 2020-06-16 13:26:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:49 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:26:49 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:26:49 --> Total execution time: 0.2347
DEBUG - 2020-06-16 13:26:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:50 --> Total execution time: 0.2354
DEBUG - 2020-06-16 13:26:50 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:50 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:50 --> Total execution time: 0.3871
DEBUG - 2020-06-16 13:26:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:53 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:26:53 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:26:53 --> Total execution time: 0.2840
DEBUG - 2020-06-16 13:26:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:54 --> Total execution time: 0.2734
DEBUG - 2020-06-16 13:26:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:54 --> Total execution time: 0.3965
DEBUG - 2020-06-16 13:26:57 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:57 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:57 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:57 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:26:57 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:26:57 --> Total execution time: 0.2966
DEBUG - 2020-06-16 13:26:57 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:57 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:26:57 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:57 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:57 --> Total execution time: 0.2106
DEBUG - 2020-06-16 13:26:57 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:26:57 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:26:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:26:58 --> Total execution time: 0.3514
DEBUG - 2020-06-16 13:27:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:27:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:27:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:27:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 11:27:10 --> Total execution time: 0.1928
DEBUG - 2020-06-16 13:27:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:27:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:27:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:27:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:27:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:11 --> Total execution time: 0.3178
DEBUG - 2020-06-16 13:27:11 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:27:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:27:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:11 --> Total execution time: 0.5358
DEBUG - 2020-06-16 13:27:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:27:15 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:27:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:27:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:15 --> Total execution time: 0.2008
DEBUG - 2020-06-16 13:27:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:27:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:27:15 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:27:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:27:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:15 --> Total execution time: 0.2318
DEBUG - 2020-06-16 13:27:15 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:27:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:27:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:15 --> Total execution time: 0.4413
DEBUG - 2020-06-16 13:27:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:27:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:27:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:27:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:30 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:27:30 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:27:30 --> Total execution time: 0.2218
DEBUG - 2020-06-16 13:27:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:27:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:27:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:27:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:27:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:30 --> Total execution time: 0.2612
DEBUG - 2020-06-16 13:27:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:27:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:27:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:27:30 --> Total execution time: 0.4463
DEBUG - 2020-06-16 13:28:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:06 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:06 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:06 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:28:06 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:28:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:07 --> Total execution time: 0.2062
DEBUG - 2020-06-16 13:28:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:07 --> Total execution time: 0.2897
DEBUG - 2020-06-16 13:28:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:08 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:08 --> Total execution time: 0.4335
DEBUG - 2020-06-16 13:28:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:18 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:28:18 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:28:18 --> Total execution time: 0.2789
DEBUG - 2020-06-16 13:28:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:18 --> Total execution time: 0.2677
DEBUG - 2020-06-16 13:28:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:18 --> Total execution time: 0.4107
DEBUG - 2020-06-16 13:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:22 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:22 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:22 --> Total execution time: 0.2649
DEBUG - 2020-06-16 13:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:22 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:22 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:23 --> Total execution time: 0.2278
DEBUG - 2020-06-16 13:28:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:23 --> Total execution time: 0.3733
DEBUG - 2020-06-16 13:28:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:30 --> Total execution time: 0.1887
DEBUG - 2020-06-16 13:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:30 --> Total execution time: 0.1887
DEBUG - 2020-06-16 13:28:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:30 --> Total execution time: 0.3420
DEBUG - 2020-06-16 13:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:36 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:36 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:36 --> Total execution time: 0.2349
DEBUG - 2020-06-16 13:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:36 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:37 --> Total execution time: 0.1828
DEBUG - 2020-06-16 13:28:37 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:37 --> Total execution time: 0.3465
DEBUG - 2020-06-16 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:42 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:42 --> Total execution time: 0.2047
DEBUG - 2020-06-16 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:43 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:43 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:43 --> Total execution time: 0.2450
DEBUG - 2020-06-16 13:28:43 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:43 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:43 --> Total execution time: 0.3943
DEBUG - 2020-06-16 13:28:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:46 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:28:46 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:28:46 --> Total execution time: 0.2248
DEBUG - 2020-06-16 13:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:46 --> Total execution time: 0.2211
DEBUG - 2020-06-16 13:28:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:46 --> Total execution time: 0.3658
DEBUG - 2020-06-16 13:28:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:49 --> Total execution time: 0.2126
DEBUG - 2020-06-16 13:28:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:28:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:49 --> Total execution time: 0.3096
DEBUG - 2020-06-16 13:28:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:28:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:28:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:28:49 --> Total execution time: 0.4693
DEBUG - 2020-06-16 13:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:01 --> Total execution time: 0.1964
DEBUG - 2020-06-16 13:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:01 --> Total execution time: 0.2100
DEBUG - 2020-06-16 13:29:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:01 --> Total execution time: 0.3559
DEBUG - 2020-06-16 13:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:05 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:29:05 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:29:05 --> Total execution time: 0.2556
DEBUG - 2020-06-16 13:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:05 --> Total execution time: 0.3443
DEBUG - 2020-06-16 13:29:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:05 --> Total execution time: 0.4961
DEBUG - 2020-06-16 13:29:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:34 --> Total execution time: 0.1956
DEBUG - 2020-06-16 13:29:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:35 --> Total execution time: 0.2259
DEBUG - 2020-06-16 13:29:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:35 --> Total execution time: 0.3906
DEBUG - 2020-06-16 13:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:38 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 13:29:38 --> Could not find the language line "back"
DEBUG - 2020-06-16 13:29:38 --> Total execution time: 0.2259
DEBUG - 2020-06-16 13:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:38 --> Total execution time: 0.2582
DEBUG - 2020-06-16 13:29:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:39 --> Total execution time: 0.3998
DEBUG - 2020-06-16 13:29:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:44 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 13:29:44 --> Could not find the language line "back"
DEBUG - 2020-06-16 13:29:44 --> Total execution time: 0.2578
DEBUG - 2020-06-16 13:29:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:44 --> Total execution time: 0.2658
DEBUG - 2020-06-16 13:29:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:44 --> Total execution time: 0.4183
DEBUG - 2020-06-16 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:47 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 13:29:47 --> Could not find the language line "back"
DEBUG - 2020-06-16 13:29:47 --> Total execution time: 0.2141
DEBUG - 2020-06-16 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:47 --> Total execution time: 0.2749
DEBUG - 2020-06-16 13:29:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:48 --> Total execution time: 0.4451
DEBUG - 2020-06-16 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 13:29:55 --> 404 Page Not Found: Reports/ajax
DEBUG - 2020-06-16 13:29:58 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:58 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:58 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:58 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 13:29:58 --> Could not find the language line "back"
DEBUG - 2020-06-16 13:29:58 --> Total execution time: 0.2404
DEBUG - 2020-06-16 13:29:58 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:58 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:29:58 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:58 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:58 --> Total execution time: 0.1988
DEBUG - 2020-06-16 13:29:58 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:29:58 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:29:58 --> Total execution time: 0.3635
DEBUG - 2020-06-16 13:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:30:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:30:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:30:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:30:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:30:05 --> Total execution time: 0.1847
DEBUG - 2020-06-16 13:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:30:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:30:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:30:06 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:30:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:30:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:30:06 --> Total execution time: 0.2485
DEBUG - 2020-06-16 13:30:06 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:30:06 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:30:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:30:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:30:06 --> Total execution time: 0.4719
DEBUG - 2020-06-16 13:34:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:34:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:34:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:34:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:34:29 --> Total execution time: 0.2010
DEBUG - 2020-06-16 13:34:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:34:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:34:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:34:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:34:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:34:29 --> Total execution time: 0.2354
DEBUG - 2020-06-16 13:34:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:34:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:34:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:34:30 --> Total execution time: 0.3868
DEBUG - 2020-06-16 13:38:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:38:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:38:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:35 --> Total execution time: 0.1972
DEBUG - 2020-06-16 13:38:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:38:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:38:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:38:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:35 --> Total execution time: 0.3328
DEBUG - 2020-06-16 13:38:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:38:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:38:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:36 --> Total execution time: 0.4697
DEBUG - 2020-06-16 13:38:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:38:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:38:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:38:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:38 --> Total execution time: 0.2120
DEBUG - 2020-06-16 13:38:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:38:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:38:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:38:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:38:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:39 --> Total execution time: 0.2227
DEBUG - 2020-06-16 13:38:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:38:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:38:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:39 --> Total execution time: 0.4369
DEBUG - 2020-06-16 13:38:40 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:38:41 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:38:41 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:38:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:41 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:41 --> Total execution time: 0.2052
DEBUG - 2020-06-16 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:38:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:38:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:38:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:45 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 13:38:45 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 13:38:45 --> Total execution time: 0.2931
DEBUG - 2020-06-16 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:38:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:38:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:38:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:45 --> Total execution time: 0.2338
DEBUG - 2020-06-16 13:38:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:38:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:38:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:38:45 --> Total execution time: 0.3897
DEBUG - 2020-06-16 13:40:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:40:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:40:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:40:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:40:03 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 13:40:03 --> 404 Page Not Found: 
DEBUG - 2020-06-16 13:42:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:07 --> Total execution time: 0.2231
DEBUG - 2020-06-16 13:42:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:07 --> Total execution time: 0.2483
DEBUG - 2020-06-16 13:42:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:07 --> Total execution time: 0.3922
DEBUG - 2020-06-16 13:42:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:12 --> Total execution time: 0.2166
DEBUG - 2020-06-16 13:42:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:13 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:13 --> Total execution time: 0.2982
DEBUG - 2020-06-16 13:42:13 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:13 --> Total execution time: 0.4551
DEBUG - 2020-06-16 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:45 --> Total execution time: 0.2564
DEBUG - 2020-06-16 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:45 --> Total execution time: 0.2244
DEBUG - 2020-06-16 13:42:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:46 --> Total execution time: 0.3897
DEBUG - 2020-06-16 13:42:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:42:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:42:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:42:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:42:56 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 13:42:56 --> 404 Page Not Found: 
DEBUG - 2020-06-16 13:43:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:43:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:43:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:43:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:43:01 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 13:43:01 --> 404 Page Not Found: 
DEBUG - 2020-06-16 13:43:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 13:43:07 --> 404 Page Not Found: Dummy/index
DEBUG - 2020-06-16 13:43:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:43:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:43:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:43:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:43:27 --> Total execution time: 0.2328
DEBUG - 2020-06-16 13:43:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:43:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:43:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:43:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:43:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:43:27 --> Total execution time: 0.2417
DEBUG - 2020-06-16 13:43:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:43:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:43:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:43:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:43:27 --> Total execution time: 0.3973
DEBUG - 2020-06-16 13:43:57 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:43:57 --> No URI present. Default controller set.
DEBUG - 2020-06-16 13:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:43:57 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:43:57 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:43:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:43:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:43:57 --> Total execution time: 0.1964
DEBUG - 2020-06-16 13:44:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:44:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:44:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:44:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:44:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:44:00 --> Total execution time: 0.2399
DEBUG - 2020-06-16 13:44:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:44:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:44:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:44:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:44:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:44:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:44:00 --> Total execution time: 0.2476
DEBUG - 2020-06-16 13:44:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:44:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:44:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:44:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:44:01 --> Total execution time: 0.3476
DEBUG - 2020-06-16 13:45:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:45:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:45:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:45:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:45:29 --> Total execution time: 0.2344
DEBUG - 2020-06-16 13:45:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:45:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:45:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:45:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:45:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:45:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:45:30 --> Total execution time: 0.2584
DEBUG - 2020-06-16 13:45:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:45:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:45:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:45:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:45:30 --> Total execution time: 0.3722
DEBUG - 2020-06-16 13:46:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:46:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:46:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:46:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:46:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:46:00 --> Total execution time: 0.1879
DEBUG - 2020-06-16 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 13:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 13:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 13:46:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:46:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:46:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:46:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:46:01 --> Total execution time: 0.3084
DEBUG - 2020-06-16 13:46:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 13:46:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 13:46:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:46:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 13:46:01 --> Total execution time: 0.4692
DEBUG - 2020-06-16 14:01:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:05 --> Total execution time: 0.3760
DEBUG - 2020-06-16 14:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:32 --> Total execution time: 0.2375
DEBUG - 2020-06-16 14:01:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:33 --> Total execution time: 0.3022
DEBUG - 2020-06-16 14:01:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:33 --> Total execution time: 0.4861
DEBUG - 2020-06-16 14:01:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:53 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 14:01:53 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 14:01:53 --> Could not find the language line "CSK_PLUGINS_SELECT_ALL"
DEBUG - 2020-06-16 14:01:53 --> Total execution time: 0.2641
DEBUG - 2020-06-16 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:53 --> Total execution time: 0.2890
DEBUG - 2020-06-16 14:01:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:53 --> Total execution time: 0.4885
DEBUG - 2020-06-16 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:58 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:58 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:58 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:58 --> Total execution time: 0.2628
DEBUG - 2020-06-16 14:01:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:59 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:59 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:59 --> Total execution time: 0.3216
DEBUG - 2020-06-16 14:01:59 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:59 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:01:59 --> Total execution time: 0.4636
DEBUG - 2020-06-16 14:01:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:01:59 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:01:59 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:02:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:02:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:02:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:02:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:02:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:02:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:08:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:08:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:08:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:08:28 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 14:08:28 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 14:08:28 --> Total execution time: 0.3268
DEBUG - 2020-06-16 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:08:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:08:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:08:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:08:28 --> Total execution time: 0.2678
DEBUG - 2020-06-16 14:08:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:08:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:08:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:08:28 --> Total execution time: 0.3957
DEBUG - 2020-06-16 14:10:58 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:10:58 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:10:58 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:10:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:10:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:10:58 --> Total execution time: 0.1917
DEBUG - 2020-06-16 14:10:58 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:10:58 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:10:58 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:10:58 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:10:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:10:59 --> Total execution time: 0.2390
DEBUG - 2020-06-16 14:10:59 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:10:59 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:10:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:10:59 --> Total execution time: 0.4037
DEBUG - 2020-06-16 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:11 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:11 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:11 --> Total execution time: 0.2181
DEBUG - 2020-06-16 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:12 --> Total execution time: 0.2307
DEBUG - 2020-06-16 14:11:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:12 --> Total execution time: 0.3913
DEBUG - 2020-06-16 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:32 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 14:11:32 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 14:11:32 --> Total execution time: 0.2746
DEBUG - 2020-06-16 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:32 --> Total execution time: 0.2241
DEBUG - 2020-06-16 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:33 --> Total execution time: 0.3872
DEBUG - 2020-06-16 14:11:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:44 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 14:11:44 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 14:11:44 --> Total execution time: 0.2182
DEBUG - 2020-06-16 14:11:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:44 --> Total execution time: 0.2237
DEBUG - 2020-06-16 14:11:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:44 --> Total execution time: 0.1663
DEBUG - 2020-06-16 14:11:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:46 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 14:11:46 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 14:11:46 --> Total execution time: 0.3017
DEBUG - 2020-06-16 14:11:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:46 --> Total execution time: 0.2184
DEBUG - 2020-06-16 14:11:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:11:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:11:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:11:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:11:46 --> Total execution time: 0.1840
DEBUG - 2020-06-16 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:12:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:12:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:12:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:25 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 14:12:25 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 14:12:25 --> Total execution time: 0.2694
DEBUG - 2020-06-16 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:12:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:12:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:12:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:25 --> Total execution time: 0.1932
DEBUG - 2020-06-16 14:12:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:12:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:26 --> Total execution time: 0.3434
DEBUG - 2020-06-16 14:12:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:12:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:12:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:12:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:12:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:32 --> Total execution time: 0.1820
DEBUG - 2020-06-16 14:12:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:12:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:12:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:12:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:12:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:33 --> Total execution time: 0.2068
DEBUG - 2020-06-16 14:12:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:12:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:12:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:33 --> Total execution time: 0.3525
DEBUG - 2020-06-16 14:12:37 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:12:37 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:12:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:12:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:37 --> Total execution time: 0.1999
DEBUG - 2020-06-16 14:12:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:12:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:12:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:12:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:12:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:38 --> Total execution time: 0.2874
DEBUG - 2020-06-16 14:12:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:12:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:12:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:12:38 --> Total execution time: 0.4351
DEBUG - 2020-06-16 14:13:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:13:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:13:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:13:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:17 --> Total execution time: 0.1963
DEBUG - 2020-06-16 14:13:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:13:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:13:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:13:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:13:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:17 --> Total execution time: 0.3002
DEBUG - 2020-06-16 14:13:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:13:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:13:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:17 --> Total execution time: 0.4506
DEBUG - 2020-06-16 14:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:13:42 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:13:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:13:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:42 --> Total execution time: 0.2245
DEBUG - 2020-06-16 14:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:13:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:13:42 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:13:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:13:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:42 --> Total execution time: 0.1895
DEBUG - 2020-06-16 14:13:42 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:13:43 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:13:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:13:43 --> Total execution time: 0.3253
DEBUG - 2020-06-16 14:15:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:19 --> Total execution time: 0.2206
DEBUG - 2020-06-16 14:15:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:20 --> Total execution time: 0.2440
DEBUG - 2020-06-16 14:15:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:20 --> Total execution time: 0.3997
DEBUG - 2020-06-16 14:15:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:24 --> Total execution time: 0.2294
DEBUG - 2020-06-16 14:15:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:24 --> Total execution time: 0.2689
DEBUG - 2020-06-16 14:15:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:24 --> Total execution time: 0.3384
DEBUG - 2020-06-16 14:15:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:35 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 14:15:35 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 14:15:35 --> Total execution time: 0.2204
DEBUG - 2020-06-16 14:15:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:35 --> Total execution time: 0.2197
DEBUG - 2020-06-16 14:15:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:35 --> Total execution time: 0.3745
DEBUG - 2020-06-16 14:15:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:38 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:38 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 14:15:38 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 14:15:38 --> Could not find the language line "CSK_PLUGINS_SELECT_ALL"
DEBUG - 2020-06-16 14:15:38 --> Total execution time: 0.2260
DEBUG - 2020-06-16 14:15:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:15:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:39 --> Total execution time: 0.2515
DEBUG - 2020-06-16 14:15:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:15:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:15:39 --> Total execution time: 0.5217
DEBUG - 2020-06-16 14:16:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:16:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:16:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:16:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:01 --> Total execution time: 0.2104
DEBUG - 2020-06-16 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:16:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:16:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:16:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:01 --> Total execution time: 0.2324
DEBUG - 2020-06-16 14:16:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:16:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:16:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:01 --> Total execution time: 0.3812
DEBUG - 2020-06-16 14:16:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:16:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:16:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:20 --> Total execution time: 0.2301
DEBUG - 2020-06-16 14:16:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:16:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:16:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:16:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:20 --> Total execution time: 0.1959
DEBUG - 2020-06-16 14:16:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:16:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:16:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:20 --> Total execution time: 0.3533
DEBUG - 2020-06-16 14:16:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:16:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:16:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:24 --> Total execution time: 0.2145
DEBUG - 2020-06-16 14:16:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:16:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:16:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:16:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:25 --> Total execution time: 0.2654
DEBUG - 2020-06-16 14:16:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:16:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:16:25 --> Total execution time: 0.4526
DEBUG - 2020-06-16 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:24 --> Total execution time: 0.2191
DEBUG - 2020-06-16 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:24 --> Total execution time: 0.2473
DEBUG - 2020-06-16 14:19:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:24 --> Total execution time: 0.4264
DEBUG - 2020-06-16 14:19:26 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:26 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:26 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:26 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 14:19:26 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 14:19:26 --> Total execution time: 0.2817
DEBUG - 2020-06-16 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:27 --> Total execution time: 0.3929
DEBUG - 2020-06-16 14:19:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:27 --> Total execution time: 0.5479
DEBUG - 2020-06-16 14:19:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:45 --> Total execution time: 0.2320
DEBUG - 2020-06-16 14:19:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:45 --> Total execution time: 0.2618
DEBUG - 2020-06-16 14:19:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:46 --> Total execution time: 0.4609
DEBUG - 2020-06-16 14:19:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:52 --> Total execution time: 0.2206
DEBUG - 2020-06-16 14:19:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:19:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:52 --> Total execution time: 0.2283
DEBUG - 2020-06-16 14:19:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:19:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:19:52 --> Total execution time: 0.4566
DEBUG - 2020-06-16 14:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:20:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:20:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:03 --> Total execution time: 0.2711
DEBUG - 2020-06-16 14:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:20:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:20:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:20:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:03 --> Total execution time: 0.2372
DEBUG - 2020-06-16 14:20:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:20:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:20:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:04 --> Total execution time: 0.3904
DEBUG - 2020-06-16 14:20:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:20:06 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:20:06 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:20:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:06 --> Total execution time: 0.2672
DEBUG - 2020-06-16 14:20:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:20:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:20:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:20:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:07 --> Total execution time: 0.2743
DEBUG - 2020-06-16 14:20:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:20:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:07 --> Total execution time: 0.4405
DEBUG - 2020-06-16 14:20:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:20:37 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:20:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:37 --> Total execution time: 0.2299
DEBUG - 2020-06-16 14:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:20:37 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:20:37 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:20:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:37 --> Total execution time: 0.2394
DEBUG - 2020-06-16 14:20:37 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:20:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:37 --> Total execution time: 0.4340
DEBUG - 2020-06-16 14:20:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:20:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:20:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:20:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:20:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:21:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:21:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:21:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:21:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:09 --> Total execution time: 0.1875
DEBUG - 2020-06-16 14:24:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:10 --> Total execution time: 0.2953
DEBUG - 2020-06-16 14:24:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:10 --> Total execution time: 0.4256
DEBUG - 2020-06-16 14:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:18 --> Total execution time: 0.2475
DEBUG - 2020-06-16 14:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:18 --> Total execution time: 0.2609
DEBUG - 2020-06-16 14:24:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:18 --> Total execution time: 0.4315
DEBUG - 2020-06-16 14:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:24 --> Total execution time: 0.1887
DEBUG - 2020-06-16 14:24:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:24 --> Total execution time: 0.1837
DEBUG - 2020-06-16 14:24:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:24 --> Total execution time: 0.3252
DEBUG - 2020-06-16 14:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:29 --> Total execution time: 0.2328
DEBUG - 2020-06-16 14:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:29 --> Total execution time: 0.2470
DEBUG - 2020-06-16 14:24:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:30 --> Total execution time: 0.4072
DEBUG - 2020-06-16 14:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:31 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 14:24:31 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 14:24:31 --> Total execution time: 0.2296
DEBUG - 2020-06-16 14:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:32 --> Total execution time: 0.2563
DEBUG - 2020-06-16 14:24:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:32 --> Total execution time: 0.4541
DEBUG - 2020-06-16 14:24:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:46 --> Total execution time: 0.2096
DEBUG - 2020-06-16 14:24:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:46 --> Total execution time: 0.2148
DEBUG - 2020-06-16 14:24:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:46 --> Total execution time: 0.3740
DEBUG - 2020-06-16 14:24:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:24:55 --> No URI present. Default controller set.
DEBUG - 2020-06-16 14:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:24:55 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:24:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:24:55 --> Total execution time: 0.3059
DEBUG - 2020-06-16 14:25:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:03 --> Total execution time: 0.2266
DEBUG - 2020-06-16 14:25:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:03 --> Total execution time: 0.2401
DEBUG - 2020-06-16 14:25:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:03 --> Total execution time: 0.5633
DEBUG - 2020-06-16 14:25:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 14:25:11 --> 404 Page Not Found: Media/index
DEBUG - 2020-06-16 14:25:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 14:25:18 --> 404 Page Not Found: Media-manager/index
DEBUG - 2020-06-16 14:25:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:31 --> Total execution time: 0.2823
DEBUG - 2020-06-16 14:25:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:31 --> Total execution time: 0.2198
DEBUG - 2020-06-16 14:25:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:31 --> Total execution time: 0.3882
DEBUG - 2020-06-16 14:25:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 14:25:33 --> 404 Page Not Found: Media/index
DEBUG - 2020-06-16 14:25:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:39 --> Total execution time: 0.1890
DEBUG - 2020-06-16 14:25:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:39 --> Total execution time: 0.2983
DEBUG - 2020-06-16 14:25:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:39 --> Total execution time: 0.4609
DEBUG - 2020-06-16 14:25:41 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:25:41 --> No URI present. Default controller set.
DEBUG - 2020-06-16 14:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:25:41 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:25:41 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:25:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:41 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:25:41 --> Total execution time: 0.3262
DEBUG - 2020-06-16 14:26:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:25 --> Total execution time: 0.2100
DEBUG - 2020-06-16 14:26:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:26 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:26 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:26 --> Total execution time: 0.2401
DEBUG - 2020-06-16 14:26:26 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:26 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:26 --> Total execution time: 0.4231
DEBUG - 2020-06-16 14:26:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:30 --> Total execution time: 0.2863
DEBUG - 2020-06-16 14:26:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:30 --> Total execution time: 0.1761
DEBUG - 2020-06-16 14:26:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:30 --> Total execution time: 0.3199
DEBUG - 2020-06-16 14:26:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:43 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:43 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:47 --> No URI present. Default controller set.
DEBUG - 2020-06-16 14:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:47 --> Total execution time: 0.1922
DEBUG - 2020-06-16 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:52 --> Total execution time: 0.2171
DEBUG - 2020-06-16 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:26:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:52 --> Total execution time: 0.2715
DEBUG - 2020-06-16 14:26:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:26:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:26:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:26:53 --> Total execution time: 0.4469
DEBUG - 2020-06-16 14:26:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:27:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:27:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:27:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:27:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:36:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 14:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 14:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 14:36:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 14:36:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 14:36:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 14:36:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 15:53:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 15:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 15:53:30 --> No URI present. Default controller set.
DEBUG - 2020-06-16 15:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 15:53:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 15:53:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 15:53:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 15:53:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 15:53:30 --> Total execution time: 0.2460
DEBUG - 2020-06-16 16:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:09:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:09:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:09:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:09:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:09:02 --> Total execution time: 0.2334
DEBUG - 2020-06-16 16:09:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:09:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:09:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:09:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:09:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:09:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:09:03 --> Total execution time: 0.3353
DEBUG - 2020-06-16 16:09:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:09:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:09:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:09:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:09:03 --> Total execution time: 0.5254
DEBUG - 2020-06-16 16:09:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:09:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:09:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:09:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:09:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:13:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:13:59 --> No URI present. Default controller set.
DEBUG - 2020-06-16 16:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:13:59 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:13:59 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:14:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:14:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:14:00 --> Total execution time: 0.2255
DEBUG - 2020-06-16 16:14:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:14:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:14:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:14:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:14:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:14:03 --> Total execution time: 0.2212
DEBUG - 2020-06-16 16:14:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:14:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:14:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:14:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:14:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:14:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:14:04 --> Total execution time: 0.3633
DEBUG - 2020-06-16 16:14:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:14:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:14:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:14:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:14:04 --> Total execution time: 0.5514
DEBUG - 2020-06-16 16:14:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:14:15 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:14:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:14:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:14:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:17:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:17:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:17:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:17:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:17:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:26:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:26:35 --> No URI present. Default controller set.
DEBUG - 2020-06-16 16:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:26:36 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:26:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:26:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:26:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:26:36 --> Total execution time: 1.5524
DEBUG - 2020-06-16 16:26:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:26:39 --> No URI present. Default controller set.
DEBUG - 2020-06-16 16:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:26:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:26:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:26:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:26:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:26:39 --> Total execution time: 0.7172
DEBUG - 2020-06-16 16:41:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:41:42 --> No URI present. Default controller set.
DEBUG - 2020-06-16 16:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:41:42 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:41:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:41:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:41:42 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 16:41:42 --> Could not find the language line "CSK_BTN_ADMIN_PANEL"
ERROR - 2020-06-16 16:41:42 --> Could not find the language line "CSK_BTN_VIEW_PROFILE"
ERROR - 2020-06-16 16:41:42 --> Could not find the language line "CSK_BTN_SETTINGS"
ERROR - 2020-06-16 16:41:42 --> Could not find the language line "CSK_BTN_LOGOUT"
DEBUG - 2020-06-16 16:41:42 --> Total execution time: 0.3798
DEBUG - 2020-06-16 16:41:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:41:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:41:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:41:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:41:49 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_SYSTEM"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_ADMIN_PANEL"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_GLOBAL_SETTINGS"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_SYSTEM_INFORMATION"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_USERS"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_USERS_MANAGE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONTENT"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_EXTENSIONS"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_MODULES"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_PLUGINS"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_THEMES"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_LANGUAGES"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_REPORTS"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_BTN_HELP"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_DOCUMENTATION"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_EXTENSIONS"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_TRANSLATIONS"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_SKELETON_SHOP"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_BTN_VIEW_SITE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_BTN_VIEW_PROFILE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_BTN_EDIT_PROFILE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_BTN_LOGOUT"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_DASHBOARD"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_FOOTER_TEXT"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_VERSION_TEXT"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_BTN_CLOSE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_ADMIN_PANEL"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_USERS"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_BTN_MANAGE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_THEMES"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_BTN_MANAGE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_LANGUAGES"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_BTN_MANAGE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_SKELETON"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONFIRM_ACTIVATE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONFIRM_DEACTIVATE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONFIRM_DELETE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONFIRM_DELETE_SELECTED"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONFIRM_DISABLE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONFIRM_ENABLE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONFIRM_INSTALL"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONFIRM_DELETE_PERMANENT"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONFIRM_RESTORE"
ERROR - 2020-06-16 16:41:49 --> Could not find the language line "CSK_ADMIN_CONFIRM_UPLOAD"
DEBUG - 2020-06-16 16:41:49 --> Total execution time: 0.4581
DEBUG - 2020-06-16 16:41:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:41:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:41:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:41:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:41:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:41:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:41:49 --> Total execution time: 0.2072
DEBUG - 2020-06-16 16:41:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:41:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:41:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:41:50 --> Total execution time: 0.4364
DEBUG - 2020-06-16 16:41:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:41:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:41:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:41:56 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_SYSTEM"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_ADMIN_PANEL"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_GLOBAL_SETTINGS"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_SYSTEM_INFORMATION"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_USERS"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_USERS_MANAGE"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_CONTENT"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_EXTENSIONS"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_MODULES"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_PLUGINS"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_THEMES"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_LANGUAGES"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_REPORTS"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_BTN_HELP"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_DOCUMENTATION"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_EXTENSIONS"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_TRANSLATIONS"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_SKELETON_SHOP"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_BTN_VIEW_SITE"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_BTN_VIEW_PROFILE"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_BTN_EDIT_PROFILE"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_BTN_LOGOUT"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_DASHBOARD"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_FOOTER_TEXT"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_ADMIN_VERSION_TEXT"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "CSK_BTN_CLOSE"
DEBUG - 2020-06-16 16:41:56 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 16:41:56 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "title"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "form_validation_required"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "form_validation_min_length"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "form_validation_max_length"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "pagination_first_link"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "pagination_next_link"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "pagination_prev_link"
ERROR - 2020-06-16 16:41:56 --> Could not find the language line "pagination_last_link"
ERROR - 2020-06-16 16:41:56 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 16:43:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:43:09 --> KB_Loader class Initialized
ERROR - 2020-06-16 16:43:09 --> Severity: Notice --> Undefined variable: full_lang C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
DEBUG - 2020-06-16 16:43:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 16:43:09 --> Severity: Notice --> Undefined variable: full_lang C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Notice --> Undefined variable: full_lang C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Notice --> Undefined variable: full_lang C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
DEBUG - 2020-06-16 16:43:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:43:09 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 16:43:09 --> Severity: Notice --> Undefined variable: full_lang C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Notice --> Undefined variable: full_lang C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_SYSTEM"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_ADMIN_PANEL"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_GLOBAL_SETTINGS"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_SYSTEM_INFORMATION"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_USERS"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_USERS_MANAGE"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_CONTENT"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_EXTENSIONS"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_MODULES"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_PLUGINS"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_THEMES"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_LANGUAGES"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_REPORTS"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_BTN_HELP"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_DOCUMENTATION"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_EXTENSIONS"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_TRANSLATIONS"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_SKELETON_SHOP"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_BTN_VIEW_SITE"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_BTN_VIEW_PROFILE"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_BTN_EDIT_PROFILE"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_BTN_LOGOUT"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_DASHBOARD"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_FOOTER_TEXT"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_ADMIN_VERSION_TEXT"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "CSK_BTN_CLOSE"
DEBUG - 2020-06-16 16:43:09 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 16:43:09 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 16:43:09 --> Severity: Notice --> Undefined variable: full_lang C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "title"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "form_validation_required"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "form_validation_min_length"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "form_validation_max_length"
ERROR - 2020-06-16 16:43:09 --> Severity: Notice --> Undefined variable: full_lang C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\xampp\htdocs\skeleton\skeleton\core\KB_Lang.php 286
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "pagination_first_link"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "pagination_next_link"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "pagination_prev_link"
ERROR - 2020-06-16 16:43:09 --> Could not find the language line "pagination_last_link"
ERROR - 2020-06-16 16:43:09 --> Invalid driver requested: Kbcore_media
ERROR - 2020-06-16 16:43:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\skeleton\skeleton\system\core\Exceptions.php:271) C:\xampp\htdocs\skeleton\skeleton\system\core\Common.php 597
DEBUG - 2020-06-16 16:43:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:43:55 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:43:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:43:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:43:55 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_SYSTEM"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_ADMIN_PANEL"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_GLOBAL_SETTINGS"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_SYSTEM_INFORMATION"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_USERS"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_USERS_MANAGE"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_CONTENT"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_EXTENSIONS"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_MODULES"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_PLUGINS"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_THEMES"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_LANGUAGES"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_REPORTS"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_BTN_HELP"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_DOCUMENTATION"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_EXTENSIONS"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_TRANSLATIONS"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_SKELETON_SHOP"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_BTN_VIEW_SITE"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_BTN_VIEW_PROFILE"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_BTN_EDIT_PROFILE"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_BTN_LOGOUT"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_DASHBOARD"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_FOOTER_TEXT"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_ADMIN_VERSION_TEXT"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "CSK_BTN_CLOSE"
DEBUG - 2020-06-16 16:43:55 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 16:43:55 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "title"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "form_validation_required"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "form_validation_min_length"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "form_validation_max_length"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "pagination_first_link"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "pagination_next_link"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "pagination_prev_link"
ERROR - 2020-06-16 16:43:55 --> Could not find the language line "pagination_last_link"
ERROR - 2020-06-16 16:43:55 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 16:50:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 16:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 16:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 16:50:59 --> KB_Loader class Initialized
DEBUG - 2020-06-16 16:50:59 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 16:50:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 16:50:59 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:07:45 --> No URI present. Default controller set.
DEBUG - 2020-06-16 17:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:07:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:07:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:07:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:45 --> Total execution time: 0.2050
DEBUG - 2020-06-16 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:07:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:07:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:48 --> Total execution time: 0.2151
DEBUG - 2020-06-16 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:07:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:07:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:49 --> Total execution time: 0.2831
DEBUG - 2020-06-16 17:07:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:07:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:49 --> Total execution time: 0.4999
DEBUG - 2020-06-16 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:07:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:07:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:53 --> Total execution time: 0.2006
DEBUG - 2020-06-16 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:07:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:07:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:53 --> Total execution time: 0.2232
DEBUG - 2020-06-16 17:07:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:07:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:07:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:07:53 --> Total execution time: 0.3708
DEBUG - 2020-06-16 17:07:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:08:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:08:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:08:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:08:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:08:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:08:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:00 --> Total execution time: 0.3050
DEBUG - 2020-06-16 17:08:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:08:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:08:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:08:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:08:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:00 --> Total execution time: 0.1959
DEBUG - 2020-06-16 17:08:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:08:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:08:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:01 --> Total execution time: 0.3576
DEBUG - 2020-06-16 17:08:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:08:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:08:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:08:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:08:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:04 --> Total execution time: 0.2435
DEBUG - 2020-06-16 17:08:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:08:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:08:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:08:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:08:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:05 --> Total execution time: 0.2167
DEBUG - 2020-06-16 17:08:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:08:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:08:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:08:05 --> Total execution time: 0.3818
DEBUG - 2020-06-16 17:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:02 --> Total execution time: 0.2053
DEBUG - 2020-06-16 17:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:03 --> Total execution time: 0.2021
DEBUG - 2020-06-16 17:09:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:03 --> Total execution time: 0.3792
DEBUG - 2020-06-16 17:09:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:05 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 17:09:05 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 17:09:05 --> Total execution time: 0.2873
DEBUG - 2020-06-16 17:09:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:05 --> Total execution time: 0.2555
DEBUG - 2020-06-16 17:09:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:06 --> Total execution time: 0.4907
DEBUG - 2020-06-16 17:09:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:19 --> Total execution time: 0.1944
DEBUG - 2020-06-16 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:19 --> Total execution time: 0.2903
DEBUG - 2020-06-16 17:09:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:19 --> Total execution time: 0.5059
DEBUG - 2020-06-16 17:09:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:25 --> Total execution time: 0.2047
DEBUG - 2020-06-16 17:09:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:25 --> Total execution time: 0.2214
DEBUG - 2020-06-16 17:09:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:25 --> Total execution time: 0.5061
DEBUG - 2020-06-16 17:09:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:32 --> Total execution time: 0.2503
DEBUG - 2020-06-16 17:09:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:32 --> Total execution time: 0.2979
DEBUG - 2020-06-16 17:09:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:32 --> Total execution time: 0.4652
DEBUG - 2020-06-16 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:36 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:36 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 17:09:36 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 17:09:36 --> Could not find the language line "title"
ERROR - 2020-06-16 17:09:36 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 17:09:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:09:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:09:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:09:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:09:54 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 17:09:54 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 17:09:54 --> Could not find the language line "title"
ERROR - 2020-06-16 17:09:54 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 17:10:50 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:10:50 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:10:50 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:10:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:10:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:10:50 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 17:10:50 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 17:10:50 --> Could not find the language line "title"
ERROR - 2020-06-16 17:10:50 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 17:57:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:57:56 --> No URI present. Default controller set.
DEBUG - 2020-06-16 17:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:57:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:57:57 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:57:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:57:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:57:57 --> Total execution time: 0.2654
DEBUG - 2020-06-16 17:57:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:00 --> Total execution time: 0.2338
DEBUG - 2020-06-16 17:58:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:00 --> Total execution time: 0.2948
DEBUG - 2020-06-16 17:58:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:00 --> Total execution time: 0.5439
DEBUG - 2020-06-16 17:58:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:05 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 17:58:05 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 17:58:05 --> Could not find the language line "title"
ERROR - 2020-06-16 17:58:05 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 17:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:09 --> Total execution time: 0.2111
DEBUG - 2020-06-16 17:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:10 --> Total execution time: 0.3278
DEBUG - 2020-06-16 17:58:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:10 --> Total execution time: 0.4663
DEBUG - 2020-06-16 17:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:14 --> Total execution time: 0.2172
DEBUG - 2020-06-16 17:58:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:15 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:15 --> Total execution time: 0.1822
DEBUG - 2020-06-16 17:58:15 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:15 --> Total execution time: 0.3276
DEBUG - 2020-06-16 17:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:18 --> Total execution time: 0.2154
DEBUG - 2020-06-16 17:58:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:18 --> Total execution time: 0.2109
DEBUG - 2020-06-16 17:58:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:18 --> Total execution time: 0.3901
DEBUG - 2020-06-16 17:58:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:22 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:22 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:22 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:22 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:22 --> Total execution time: 0.2826
DEBUG - 2020-06-16 17:58:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:23 --> Total execution time: 0.1859
DEBUG - 2020-06-16 17:58:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:23 --> Total execution time: 0.3294
DEBUG - 2020-06-16 17:58:26 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:26 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:26 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:26 --> Total execution time: 0.2015
DEBUG - 2020-06-16 17:58:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:27 --> Total execution time: 0.1927
DEBUG - 2020-06-16 17:58:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:27 --> Total execution time: 0.3399
DEBUG - 2020-06-16 17:58:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:32 --> Total execution time: 0.1824
DEBUG - 2020-06-16 17:58:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:32 --> Total execution time: 0.1911
DEBUG - 2020-06-16 17:58:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:33 --> Total execution time: 0.3375
DEBUG - 2020-06-16 17:58:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:46 --> Total execution time: 0.2120
DEBUG - 2020-06-16 17:58:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:47 --> Total execution time: 0.2927
DEBUG - 2020-06-16 17:58:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:47 --> Total execution time: 0.4663
DEBUG - 2020-06-16 17:58:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:52 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 17:58:52 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 17:58:52 --> Total execution time: 0.3198
DEBUG - 2020-06-16 17:58:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:58:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:53 --> Total execution time: 0.3563
DEBUG - 2020-06-16 17:58:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:58:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:58:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:53 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:58:53 --> Total execution time: 0.6208
DEBUG - 2020-06-16 17:59:40 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:59:40 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:59:40 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:59:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:59:40 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:59:40 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 17:59:41 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 17:59:41 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:59:41 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:59:41 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:59:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:59:41 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:59:41 --> Total execution time: 0.2819
DEBUG - 2020-06-16 17:59:41 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:59:41 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 17:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 17:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 17:59:41 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:59:41 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:59:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:59:42 --> Total execution time: 0.2483
DEBUG - 2020-06-16 17:59:42 --> KB_Loader class Initialized
DEBUG - 2020-06-16 17:59:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 17:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:59:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 17:59:42 --> Total execution time: 0.4185
DEBUG - 2020-06-16 18:00:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:00:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:00:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:00:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:00:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:00:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:00:27 --> No URI present. Default controller set.
DEBUG - 2020-06-16 18:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:00:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:00:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:00:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:00:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:00:27 --> Total execution time: 0.2086
DEBUG - 2020-06-16 18:00:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:00:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:00:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:00:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:00:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:00:30 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:00:30 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:00:30 --> Total execution time: 0.2531
DEBUG - 2020-06-16 18:00:50 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:00:50 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:00:50 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:00:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:00:50 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:00:50 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:00:50 --> Total execution time: 0.2358
DEBUG - 2020-06-16 18:01:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:03 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:01:03 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:01:03 --> Total execution time: 0.3006
DEBUG - 2020-06-16 18:01:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:10 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:01:10 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:01:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:11 --> No URI present. Default controller set.
DEBUG - 2020-06-16 18:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:11 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:11 --> Total execution time: 0.2070
DEBUG - 2020-06-16 18:01:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:18 --> Total execution time: 0.1884
DEBUG - 2020-06-16 18:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:19 --> Total execution time: 0.3803
DEBUG - 2020-06-16 18:01:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:19 --> Total execution time: 0.5740
DEBUG - 2020-06-16 18:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:22 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:22 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:22 --> Total execution time: 0.2130
DEBUG - 2020-06-16 18:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:22 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:22 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:22 --> Total execution time: 0.2536
DEBUG - 2020-06-16 18:01:22 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:22 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:22 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:22 --> Total execution time: 0.5232
DEBUG - 2020-06-16 18:01:26 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:26 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:26 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:26 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:01:26 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:01:26 --> Total execution time: 0.2269
DEBUG - 2020-06-16 18:01:26 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:26 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:27 --> Total execution time: 0.2690
DEBUG - 2020-06-16 18:01:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:27 --> Total execution time: 0.4997
DEBUG - 2020-06-16 18:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:45 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:01:45 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:01:45 --> Total execution time: 0.2543
DEBUG - 2020-06-16 18:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:01:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:45 --> Total execution time: 0.2268
DEBUG - 2020-06-16 18:01:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:01:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:01:45 --> Total execution time: 0.4094
DEBUG - 2020-06-16 18:02:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:02:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:02:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:02:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:05 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:02:05 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:02:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:02:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:02:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:02:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:05 --> Total execution time: 0.4259
DEBUG - 2020-06-16 18:02:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:02:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:02:06 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:02:06 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:02:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:06 --> Total execution time: 0.2393
DEBUG - 2020-06-16 18:02:06 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:02:06 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:02:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:06 --> Total execution time: 0.4149
DEBUG - 2020-06-16 18:02:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:02:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:02:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:02:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:02:10 --> No URI present. Default controller set.
DEBUG - 2020-06-16 18:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:02:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:02:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:02:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:10 --> Total execution time: 0.1895
DEBUG - 2020-06-16 18:02:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:02:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:02:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:02:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:12 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:02:12 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:02:12 --> Total execution time: 0.2400
DEBUG - 2020-06-16 18:02:16 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:02:16 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:02:16 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:02:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:16 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:16 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:02:16 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:02:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:02:17 --> No URI present. Default controller set.
DEBUG - 2020-06-16 18:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:02:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:02:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:02:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:02:17 --> Total execution time: 0.2045
DEBUG - 2020-06-16 18:02:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 18:02:25 --> 404 Page Not Found: Test1234/index
DEBUG - 2020-06-16 18:03:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 18:03:00 --> 404 Page Not Found: Settings/index
DEBUG - 2020-06-16 18:17:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:09 --> No URI present. Default controller set.
DEBUG - 2020-06-16 18:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:09 --> Total execution time: 0.2119
DEBUG - 2020-06-16 18:17:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:11 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:12 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:17:12 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:17:12 --> Total execution time: 0.2644
DEBUG - 2020-06-16 18:17:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:20 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:17:20 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:17:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:21 --> No URI present. Default controller set.
DEBUG - 2020-06-16 18:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:21 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:21 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:21 --> Total execution time: 0.2308
DEBUG - 2020-06-16 18:17:26 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:26 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:27 --> Total execution time: 0.2078
DEBUG - 2020-06-16 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:27 --> Total execution time: 0.2756
DEBUG - 2020-06-16 18:17:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:27 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:27 --> Total execution time: 0.4975
DEBUG - 2020-06-16 18:17:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:30 --> Total execution time: 0.2108
DEBUG - 2020-06-16 18:17:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:31 --> Total execution time: 0.3532
DEBUG - 2020-06-16 18:17:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:31 --> Total execution time: 0.4641
DEBUG - 2020-06-16 18:17:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:33 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:17:33 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-16 18:17:33 --> Total execution time: 0.2390
DEBUG - 2020-06-16 18:17:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:34 --> Total execution time: 0.2626
DEBUG - 2020-06-16 18:17:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:34 --> Total execution time: 0.4542
DEBUG - 2020-06-16 18:17:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:47 --> Total execution time: 0.2093
DEBUG - 2020-06-16 18:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:47 --> Total execution time: 0.1968
DEBUG - 2020-06-16 18:17:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:47 --> Total execution time: 0.3611
DEBUG - 2020-06-16 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:54 --> Total execution time: 0.1773
DEBUG - 2020-06-16 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:17:55 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:55 --> Total execution time: 0.2875
DEBUG - 2020-06-16 18:17:55 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:17:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:17:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:17:55 --> Total execution time: 0.5561
DEBUG - 2020-06-16 18:18:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:01 --> Total execution time: 0.2197
DEBUG - 2020-06-16 18:18:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:01 --> Total execution time: 0.2321
DEBUG - 2020-06-16 18:18:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:01 --> Total execution time: 0.3591
DEBUG - 2020-06-16 18:18:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:05 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:18:05 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:18:05 --> Could not find the language line "title"
ERROR - 2020-06-16 18:18:05 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:14 --> Total execution time: 0.2276
DEBUG - 2020-06-16 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:14 --> Total execution time: 0.2364
DEBUG - 2020-06-16 18:18:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:14 --> Total execution time: 0.3785
DEBUG - 2020-06-16 18:18:21 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:21 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:21 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:21 --> Total execution time: 0.2190
DEBUG - 2020-06-16 18:18:21 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:21 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:21 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:21 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:21 --> Total execution time: 0.2537
DEBUG - 2020-06-16 18:18:21 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:21 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:21 --> Total execution time: 0.4061
DEBUG - 2020-06-16 18:18:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:18:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:18:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:18:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:18:25 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:18:25 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:18:25 --> Could not find the language line "title"
ERROR - 2020-06-16 18:18:25 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:19:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:19:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:19:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:19:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:19:46 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:19:46 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:19:46 --> Could not find the language line "title"
ERROR - 2020-06-16 18:19:46 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:24:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:24:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:24:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:24:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:24:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:24:24 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:24:24 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:24:24 --> Could not find the language line "title"
ERROR - 2020-06-16 18:24:24 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:27:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 18:27:03 --> 404 Page Not Found: Media/content
DEBUG - 2020-06-16 18:27:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:27:43 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:27:43 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:27:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:27:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:27:44 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:27:44 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:27:44 --> Could not find the language line "title"
ERROR - 2020-06-16 18:27:44 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:30:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:30:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:30:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:30:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:30:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:30:47 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:30:47 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:30:47 --> Could not find the language line "title"
ERROR - 2020-06-16 18:30:47 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:32:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:32:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:32:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:32:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:32:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:32:34 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:32:34 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:32:34 --> Could not find the language line "title"
ERROR - 2020-06-16 18:32:34 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:32:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 18:32:43 --> 404 Page Not Found: Media1/content
DEBUG - 2020-06-16 18:32:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:32:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:32:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:32:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:32:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:32:48 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:32:48 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:32:48 --> Could not find the language line "title"
ERROR - 2020-06-16 18:32:48 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:35:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:35:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:35:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:39 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:35:39 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:35:39 --> Could not find the language line "title"
ERROR - 2020-06-16 18:35:40 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:35:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:35:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:35:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:35:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:35:48 --> No URI present. Default controller set.
DEBUG - 2020-06-16 18:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:35:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:35:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:35:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:49 --> Total execution time: 0.2107
DEBUG - 2020-06-16 18:35:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:35:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:35:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:35:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:52 --> Total execution time: 0.2708
DEBUG - 2020-06-16 18:35:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:35:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:35:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:35:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:52 --> Total execution time: 0.2801
DEBUG - 2020-06-16 18:35:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:35:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:35:52 --> Total execution time: 0.5911
DEBUG - 2020-06-16 18:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:36:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:36:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:36:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:36:12 --> Total execution time: 0.2031
DEBUG - 2020-06-16 18:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:36:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:36:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:36:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:36:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:36:12 --> Total execution time: 0.1869
DEBUG - 2020-06-16 18:36:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:36:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:36:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:36:12 --> Total execution time: 0.3246
DEBUG - 2020-06-16 18:36:16 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:36:16 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:36:16 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:36:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:36:16 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:36:16 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:36:16 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:36:16 --> Could not find the language line "title"
ERROR - 2020-06-16 18:36:16 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:51:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 18:51:35 --> 404 Page Not Found: Home/index
DEBUG - 2020-06-16 18:51:41 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:51:41 --> No URI present. Default controller set.
DEBUG - 2020-06-16 18:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:51:41 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:51:41 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:51:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:51:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:51:42 --> Total execution time: 0.2191
DEBUG - 2020-06-16 18:51:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:51:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:51:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:51:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:51:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:51:46 --> Total execution time: 0.2232
DEBUG - 2020-06-16 18:51:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:51:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:51:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:51:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:51:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:51:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:51:46 --> Total execution time: 0.2572
DEBUG - 2020-06-16 18:51:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:51:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:51:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:51:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:51:46 --> Total execution time: 0.4724
DEBUG - 2020-06-16 18:53:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:53:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:53:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:53:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:53:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:53:39 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:53:39 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:53:39 --> Could not find the language line "title"
ERROR - 2020-06-16 18:53:39 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:54:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:54:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:54:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:54:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:54:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:54:30 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:54:30 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:54:30 --> Could not find the language line "title"
ERROR - 2020-06-16 18:54:30 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:54:50 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:54:50 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:54:50 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:54:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:54:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:54:50 --> Total execution time: 0.3243
DEBUG - 2020-06-16 18:54:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:54:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:54:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:54:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:54:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:54:51 --> Total execution time: 0.2359
DEBUG - 2020-06-16 18:54:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:54:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:54:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:54:51 --> Total execution time: 0.3528
DEBUG - 2020-06-16 18:57:21 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:57:21 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:57:21 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:57:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:57:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:57:21 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:57:21 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:57:21 --> Could not find the language line "title"
ERROR - 2020-06-16 18:57:21 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:57:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:57:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:57:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:57:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:57:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:57:33 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:57:33 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:57:33 --> Could not find the language line "title"
ERROR - 2020-06-16 18:57:33 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 18:57:37 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 18:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 18:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 18:57:37 --> KB_Loader class Initialized
DEBUG - 2020-06-16 18:57:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 18:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:57:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:57:37 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 18:57:37 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 18:57:37 --> Could not find the language line "title"
ERROR - 2020-06-16 18:57:37 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:00:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:00:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:09 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:00:09 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:00:09 --> Could not find the language line "title"
ERROR - 2020-06-16 19:00:09 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:00:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:00:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:00:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:00:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:10 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:00:10 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:00:10 --> Could not find the language line "title"
ERROR - 2020-06-16 19:00:10 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:00:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:00:11 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:00:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:00:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:11 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:00:11 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:00:11 --> Could not find the language line "title"
ERROR - 2020-06-16 19:00:11 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:00:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:00:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:00:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:00:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:12 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:00:12 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:00:12 --> Could not find the language line "title"
ERROR - 2020-06-16 19:00:12 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:00:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:00:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:00:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:00:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:13 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:00:13 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:00:13 --> Could not find the language line "title"
ERROR - 2020-06-16 19:00:13 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:00:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:00:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:00:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:00:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:29 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:00:29 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:00:29 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:00:29 --> Could not find the language line "title"
ERROR - 2020-06-16 19:00:29 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:01:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:01:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:01:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:01:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:01:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:01:02 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:01:02 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:01:02 --> Could not find the language line "title"
ERROR - 2020-06-16 19:01:02 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:05:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:05:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:05:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: prefix C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 120
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 120
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: prefix C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: prefix C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: prefix C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: prefix C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: prefix C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 153
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 160
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 160
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 160
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 160
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 160
ERROR - 2020-06-16 19:05:34 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 174
ERROR - 2020-06-16 19:05:34 --> Unable to load the requested driver: CI_
ERROR - 2020-06-16 19:05:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\skeleton\skeleton\system\core\Exceptions.php:271) C:\xampp\htdocs\skeleton\skeleton\system\core\Common.php 597
DEBUG - 2020-06-16 19:06:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:06:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:06:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 120
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 128
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 153
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 160
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 160
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 160
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 160
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 160
ERROR - 2020-06-16 19:06:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 174
ERROR - 2020-06-16 19:06:02 --> Unable to load the requested driver: CI_
ERROR - 2020-06-16 19:06:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\skeleton\skeleton\system\core\Exceptions.php:271) C:\xampp\htdocs\skeleton\skeleton\system\core\Common.php 597
DEBUG - 2020-06-16 19:06:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:06:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:06:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:06:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:06:20 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:06:20 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:06:20 --> Could not find the language line "title"
ERROR - 2020-06-16 19:06:20 --> Unable to load the requested driver: CI_Kbcore_media
DEBUG - 2020-06-16 19:09:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:09:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:09:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:10:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:10:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:10:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 19:10:17 --> Severity: Notice --> Undefined variable: lib_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 102
ERROR - 2020-06-16 19:10:17 --> Severity: Notice --> Undefined variable: lib_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 102
ERROR - 2020-06-16 19:10:17 --> Severity: Notice --> Undefined property: Kbcore::$ C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 102
DEBUG - 2020-06-16 19:10:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:10:25 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:10:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:10:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:10:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:10:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:11:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:11:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:11:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:12:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:12:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 19:12:05 --> Severity: Notice --> Undefined variable: valid_drivers C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 115
DEBUG - 2020-06-16 19:12:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:12:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:12:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:12:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:12:55 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:12:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:13:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:13:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:13:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:13:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:13:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:13:02 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:13:02 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:13:02 --> Could not find the language line "title"
ERROR - 2020-06-16 19:13:02 --> Severity: Notice --> Undefined variable: child_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 109
ERROR - 2020-06-16 19:13:02 --> Invalid driver requested: 
DEBUG - 2020-06-16 19:13:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:13:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:13:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:19:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:19:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:19:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:19:37 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:19:37 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:19:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:19:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:19:37 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:19:37 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:19:37 --> Could not find the language line "title"
ERROR - 2020-06-16 19:19:37 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:20:16 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:20:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:20:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:20:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:20:17 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:20:17 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:20:17 --> Could not find the language line "title"
ERROR - 2020-06-16 19:20:17 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:21:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:21:43 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:21:43 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:21:43 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:21:43 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:21:43 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:21:43 --> Could not find the language line "title"
ERROR - 2020-06-16 19:21:43 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:33:26 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:33:26 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:33:26 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:33:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:33:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:33:26 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:33:26 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:33:26 --> Could not find the language line "title"
ERROR - 2020-06-16 19:33:26 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:34:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:34:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:34:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 19:34:35 --> Unable to load the requested driver: CI_Kbcore_media
DEBUG - 2020-06-16 19:34:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:34:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:34:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 19:34:49 --> Unable to load the requested driver: CI_Kbcore_media
DEBUG - 2020-06-16 19:36:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:36:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:36:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:36:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:36:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:36:23 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:36:23 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:36:23 --> Could not find the language line "title"
ERROR - 2020-06-16 19:36:23 --> Severity: Notice --> Undefined variable: class_name C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 194
ERROR - 2020-06-16 19:36:23 --> Severity: error --> Exception: Class name must be a valid object or a string C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 194
DEBUG - 2020-06-16 19:37:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:37:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:37:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:37:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:37:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:37:05 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:37:05 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:37:05 --> Could not find the language line "title"
ERROR - 2020-06-16 19:37:05 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:39:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:39:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:39:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:39:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:39:39 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:39:39 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:39:39 --> Could not find the language line "title"
ERROR - 2020-06-16 19:39:39 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:40:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:40:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:40:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:40:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:40:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:40:09 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:40:09 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:40:09 --> Could not find the language line "title"
ERROR - 2020-06-16 19:40:09 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 19:40:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:40:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:40:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:40:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:40:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:40:39 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:40:39 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:40:39 --> Could not find the language line "title"
ERROR - 2020-06-16 19:40:39 --> Severity: error --> Exception: No such method: count() C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 304
DEBUG - 2020-06-16 19:42:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:42:13 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:42:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:42:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:42:13 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:42:13 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:42:13 --> Could not find the language line "title"
ERROR - 2020-06-16 19:42:13 --> Severity: error --> Exception: No such method: count() C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 304
DEBUG - 2020-06-16 19:51:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:51:42 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:51:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:51:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:51:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:51:42 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:51:42 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:51:42 --> Could not find the language line "title"
ERROR - 2020-06-16 19:51:42 --> Severity: error --> Exception: No such method: count() C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 304
DEBUG - 2020-06-16 19:53:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:53:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:53:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:53:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:53:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:53:45 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:53:45 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:53:45 --> Could not find the language line "title"
ERROR - 2020-06-16 19:53:45 --> Severity: error --> Exception: No such method: count() C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 304
DEBUG - 2020-06-16 19:53:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:53:46 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:53:46 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:53:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:53:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:53:46 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:53:46 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:53:46 --> Could not find the language line "title"
ERROR - 2020-06-16 19:53:46 --> Severity: error --> Exception: No such method: count() C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 304
DEBUG - 2020-06-16 19:54:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:54:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:54:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:54:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:54:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:54:01 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:54:01 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:54:01 --> Could not find the language line "title"
ERROR - 2020-06-16 19:54:01 --> Severity: error --> Exception: No such method: count() C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 304
DEBUG - 2020-06-16 19:56:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:56:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:56:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 19:56:45 --> Severity: Compile Error --> Cannot declare class KB_Group, because the name is already in use C:\xampp\htdocs\skeleton\skeleton\libraries\Kbcore\drivers\Kbcore_media.php 1149
DEBUG - 2020-06-16 19:57:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:57:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:57:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:57:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:57:19 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 19:57:19 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 19:57:19 --> Could not find the language line "title"
ERROR - 2020-06-16 19:57:19 --> Could not find the language line "update"
DEBUG - 2020-06-16 19:57:19 --> Total execution time: 0.3231
DEBUG - 2020-06-16 19:57:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:57:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 19:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 19:57:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 19:57:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:57:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:57:19 --> Total execution time: 0.2329
DEBUG - 2020-06-16 19:57:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 19:57:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 19:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:57:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 19:57:19 --> Total execution time: 0.4690
DEBUG - 2020-06-16 20:00:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:00:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:00:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 20:00:10 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\skeleton\skeleton\libraries\Kbcore\drivers\Kbcore_media.php 1139
DEBUG - 2020-06-16 20:03:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:03:15 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:03:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 20:03:15 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\skeleton\skeleton\libraries\Kbcore\drivers\Kbcore_media.php 106
DEBUG - 2020-06-16 20:03:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:03:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:03:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 20:03:34 --> Severity: Error --> Class Kbcore_media contains 7 abstract methods and must therefore be declared abstract or implement the remaining methods (CRUD_interface::create, CRUD_interface::get_by, CRUD_interface::get_many, ...) C:\xampp\htdocs\skeleton\skeleton\libraries\Kbcore\drivers\Kbcore_media.php 54
DEBUG - 2020-06-16 20:04:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:04:11 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:04:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:04:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:04:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:04:11 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:04:12 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:04:12 --> Could not find the language line "title"
ERROR - 2020-06-16 20:04:12 --> Severity: error --> Exception: No such method: get_many() C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 304
DEBUG - 2020-06-16 20:04:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:04:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:04:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:04:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:04:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:04:31 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:04:32 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:04:32 --> Could not find the language line "title"
ERROR - 2020-06-16 20:04:32 --> Could not find the language line "update"
DEBUG - 2020-06-16 20:04:32 --> Total execution time: 0.4939
DEBUG - 2020-06-16 20:04:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:04:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:04:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:04:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:04:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:04:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:04:32 --> Total execution time: 0.4245
DEBUG - 2020-06-16 20:04:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:04:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:04:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:04:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:04:32 --> Total execution time: 0.7104
DEBUG - 2020-06-16 20:06:46 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:06:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:06:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:06:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:06:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:06:47 --> Total execution time: 0.4946
DEBUG - 2020-06-16 20:06:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:06:47 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:06:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:47 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:06:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:06:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:06:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:48 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:06:48 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:06:48 --> Could not find the language line "title"
ERROR - 2020-06-16 20:06:48 --> Could not find the language line "update"
DEBUG - 2020-06-16 20:06:48 --> Total execution time: 0.6651
DEBUG - 2020-06-16 20:06:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:06:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:06:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:06:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:06:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:06:48 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:06:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:49 --> Total execution time: 0.5475
DEBUG - 2020-06-16 20:06:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:06:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:06:49 --> Total execution time: 0.9304
DEBUG - 2020-06-16 20:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:06:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:06:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:50 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:06:50 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:06:50 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:06:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:06:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:17:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:17:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:17:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:17:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:17:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:17:00 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:17:00 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:17:00 --> Could not find the language line "title"
ERROR - 2020-06-16 20:17:00 --> Could not find the language line "update"
DEBUG - 2020-06-16 20:17:00 --> Total execution time: 0.4559
DEBUG - 2020-06-16 20:17:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:17:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:17:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:17:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:17:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:17:01 --> Total execution time: 0.4525
DEBUG - 2020-06-16 20:17:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:17:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:17:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:17:01 --> Total execution time: 0.7195
DEBUG - 2020-06-16 20:17:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:17:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:17:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:17:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:17:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:17:39 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:17:39 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:17:39 --> Could not find the language line "title"
ERROR - 2020-06-16 20:17:39 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 20:20:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:20:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:20:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 20:20:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\skeleton\system\libraries\Driver.php 108
ERROR - 2020-06-16 20:20:17 --> Invalid driver requested: Kbcore_db
DEBUG - 2020-06-16 20:20:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:20:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:20:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 20:20:56 --> Severity: Notice --> Undefined property: Content::$db C:\xampp\htdocs\skeleton\skeleton\libraries\Kbcore\Kbcore.php 89
ERROR - 2020-06-16 20:20:57 --> Severity: error --> Exception: Call to a member function list_tables() on null C:\xampp\htdocs\skeleton\skeleton\libraries\Kbcore\Kbcore.php 89
DEBUG - 2020-06-16 20:21:40 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:21:40 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:21:40 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 20:21:40 --> Severity: Notice --> Undefined property: Content::$db C:\xampp\htdocs\skeleton\skeleton\libraries\Kbcore\Kbcore.php 89
ERROR - 2020-06-16 20:21:40 --> Severity: error --> Exception: Call to a member function list_tables() on null C:\xampp\htdocs\skeleton\skeleton\libraries\Kbcore\Kbcore.php 89
DEBUG - 2020-06-16 20:22:16 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:22:16 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:22:16 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:22:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:22:16 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:22:16 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:22:16 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:22:16 --> Could not find the language line "title"
ERROR - 2020-06-16 20:22:16 --> Invalid driver requested: Kbcore_media
DEBUG - 2020-06-16 20:27:21 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:27:21 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:27:21 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:27:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:27:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:27:21 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:27:21 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:27:21 --> Could not find the language line "title"
ERROR - 2020-06-16 20:27:21 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 105
DEBUG - 2020-06-16 20:27:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:27:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:27:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:27:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:27:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:27:51 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:27:51 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:27:51 --> Could not find the language line "title"
ERROR - 2020-06-16 20:27:51 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 105
DEBUG - 2020-06-16 20:35:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:35:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:35:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
ERROR - 2020-06-16 20:35:04 --> Severity: error --> Exception: Call to a member function initialize() on null C:\xampp\htdocs\skeleton\skeleton\libraries\Kbcore\Kbcore.php 120
DEBUG - 2020-06-16 20:35:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:35:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:35:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:35:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:35:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:35:17 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:35:17 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:35:17 --> Could not find the language line "title"
ERROR - 2020-06-16 20:35:17 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 105
DEBUG - 2020-06-16 20:36:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:36:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:36:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:36:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:36:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:36:56 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:36:56 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:36:56 --> Could not find the language line "title"
ERROR - 2020-06-16 20:36:56 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 105
DEBUG - 2020-06-16 20:38:58 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:38:58 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:38:58 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:38:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:38:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:38:58 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:38:58 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:38:58 --> Could not find the language line "title"
ERROR - 2020-06-16 20:38:58 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 105
DEBUG - 2020-06-16 20:40:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-16 20:40:51 --> Severity: error --> Exception: syntax error, unexpected ']' C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 174
DEBUG - 2020-06-16 20:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:41:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:41:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:41:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:41:01 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:41:01 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:41:01 --> Could not find the language line "title"
ERROR - 2020-06-16 20:41:01 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 105
DEBUG - 2020-06-16 20:41:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:41:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:41:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:41:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:41:24 --> Total execution time: 0.2478
DEBUG - 2020-06-16 20:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:42:11 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:42:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:42:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:42:11 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:42:11 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 54
DEBUG - 2020-06-16 20:42:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:42:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:42:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:42:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:42:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:42:28 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:42:28 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:42:28 --> Could not find the language line "title"
ERROR - 2020-06-16 20:42:28 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 105
DEBUG - 2020-06-16 20:44:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:44:55 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:44:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:44:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:44:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:44:55 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:44:55 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:44:55 --> Could not find the language line "title"
ERROR - 2020-06-16 20:44:55 --> Severity: error --> Exception: Call to a member function get_all() on null C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 121
DEBUG - 2020-06-16 20:45:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:45:10 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:45:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:45:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:45:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:45:10 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:45:10 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:45:10 --> Could not find the language line "title"
ERROR - 2020-06-16 20:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 125
ERROR - 2020-06-16 20:45:10 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 54
DEBUG - 2020-06-16 20:45:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:45:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:45:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:45:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:45:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:45:39 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:45:40 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:45:40 --> Could not find the language line "title"
ERROR - 2020-06-16 20:45:40 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 54
DEBUG - 2020-06-16 20:46:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:46:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:46:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:46:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:46:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:46:24 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:46:24 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:46:24 --> Could not find the language line "title"
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> Use of undefined constant MAIN_DIR - assumed 'MAIN_DIR' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 285
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:46:24 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:46:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:46:24 --> Severity: error --> Exception: Call to undefined function files() C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 868
DEBUG - 2020-06-16 20:48:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:48:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:48:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:48:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:48:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:48:05 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:48:05 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:48:05 --> Could not find the language line "title"
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> Use of undefined constant MAIN_DIR - assumed 'MAIN_DIR' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 285
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:48:05 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:48:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:48:05 --> Severity: error --> Exception: Call to undefined function files() C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 868
DEBUG - 2020-06-16 20:48:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:48:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:48:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:48:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:48:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:48:28 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-16 20:48:28 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-16 20:48:28 --> Could not find the language line "title"
ERROR - 2020-06-16 20:48:28 --> Severity: Warning --> Use of undefined constant MAIN_DIR - assumed 'MAIN_DIR' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 285
ERROR - 2020-06-16 20:48:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:48:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:48:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:48:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:48:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:48:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:48:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:48:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:48:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:48:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:48:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:48:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:48:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:48:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:48:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:48:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:48:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:48:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:48:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:48:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:48:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:48:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:48:29 --> Severity: error --> Exception: Call to undefined function files() C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 868
DEBUG - 2020-06-16 20:49:41 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:49:41 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:49:41 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:49:41 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Constant DS already defined C:\xampp\htdocs\skeleton\skeleton\helpers\fileeditor_helper.php 108
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:49:41 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 20:49:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 20:49:42 --> Total execution time: 0.8432
DEBUG - 2020-06-16 20:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:49:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:49:42 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:49:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:49:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:49:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:49:42 --> Total execution time: 0.2925
DEBUG - 2020-06-16 20:49:42 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:49:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:49:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:49:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:49:42 --> Total execution time: 0.5085
DEBUG - 2020-06-16 20:50:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:50:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:50:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:50:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:50:02 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Constant DS already defined C:\xampp\htdocs\skeleton\skeleton\helpers\fileeditor_helper.php 108
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:50:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:50:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:50:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:50:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:50:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:50:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:50:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:50:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:50:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:50:02 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:50:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:50:03 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:50:03 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 20:50:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 20:50:03 --> Total execution time: 0.7130
DEBUG - 2020-06-16 20:50:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:50:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:50:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:50:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:50:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:50:03 --> Total execution time: 0.3154
DEBUG - 2020-06-16 20:50:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:50:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:50:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:50:03 --> Total execution time: 0.5370
DEBUG - 2020-06-16 20:50:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:50:36 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:50:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:50:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:50:36 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:50:36 --> Severity: Notice --> Constant DS already defined C:\xampp\htdocs\skeleton\skeleton\helpers\fileeditor_helper.php 108
ERROR - 2020-06-16 20:50:36 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:50:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:50:36 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:50:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:50:36 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:50:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:50:36 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:50:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:50:37 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:50:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:50:37 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:50:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:50:37 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:50:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:50:37 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:50:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:50:37 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:50:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:50:37 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:50:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:50:37 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:50:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:50:37 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 20:50:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 20:50:37 --> Total execution time: 0.6913
DEBUG - 2020-06-16 20:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:50:37 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:50:37 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:50:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:50:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:50:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:50:37 --> Total execution time: 0.3396
DEBUG - 2020-06-16 20:50:37 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:50:37 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:50:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:50:37 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:50:38 --> Total execution time: 0.5477
DEBUG - 2020-06-16 20:52:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:52:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:52:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:52:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:52:28 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:52:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 20:52:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 20:52:28 --> Total execution time: 0.5738
DEBUG - 2020-06-16 20:52:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:52:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:52:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:52:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:52:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:52:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:52:28 --> Total execution time: 0.2675
DEBUG - 2020-06-16 20:52:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:52:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:52:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:52:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:52:29 --> Total execution time: 0.4220
DEBUG - 2020-06-16 20:52:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:52:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:52:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:52:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:52:51 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:52:51 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 20:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 20:52:51 --> Total execution time: 0.3522
DEBUG - 2020-06-16 20:52:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:52:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:52:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:52:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:52:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:52:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:52:52 --> Total execution time: 0.2267
DEBUG - 2020-06-16 20:52:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:52:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:52:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:52:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:52:52 --> Total execution time: 0.4030
DEBUG - 2020-06-16 20:53:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:53:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:53:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:53:33 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:53:33 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 20:53:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 20:53:33 --> Total execution time: 0.4566
DEBUG - 2020-06-16 20:53:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:53:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:53:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:53:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:53:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:53:33 --> Total execution time: 0.3260
DEBUG - 2020-06-16 20:53:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:53:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:53:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:53:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:53:34 --> Total execution time: 0.4823
DEBUG - 2020-06-16 20:54:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:54:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:54:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:54:53 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:54:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 20:54:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 20:54:53 --> Total execution time: 0.3874
DEBUG - 2020-06-16 20:54:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:54:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:54:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:54:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:54:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:54:54 --> Total execution time: 0.2336
DEBUG - 2020-06-16 20:54:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:54:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:54:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:54:54 --> Total execution time: 0.3822
DEBUG - 2020-06-16 20:56:53 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:56:53 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:56:53 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:56:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:56:53 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:56:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:56:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:56:53 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:56:54 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:56:54 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:56:54 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:56:54 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:56:54 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:56:54 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:56:54 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:56:54 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:56:54 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:56:54 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 20:56:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 20:56:54 --> Total execution time: 0.3718
DEBUG - 2020-06-16 20:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:56:54 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:56:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:56:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:56:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:56:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:56:54 --> Total execution time: 0.2107
DEBUG - 2020-06-16 20:56:54 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:56:54 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:56:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:56:54 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:56:54 --> Total execution time: 0.3822
DEBUG - 2020-06-16 20:58:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:58:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:58:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:58:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:58:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:58:48 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:58:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:58:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:58:49 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:58:49 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 20:58:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 20:58:49 --> Total execution time: 0.3411
DEBUG - 2020-06-16 20:58:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:58:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:58:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:58:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:58:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:58:49 --> Total execution time: 0.2417
DEBUG - 2020-06-16 20:58:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:58:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:58:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:58:49 --> Total execution time: 0.3873
DEBUG - 2020-06-16 20:59:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:13 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:13 --> Total execution time: 0.2095
DEBUG - 2020-06-16 20:59:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:14 --> Total execution time: 0.3013
DEBUG - 2020-06-16 20:59:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:14 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:14 --> Total execution time: 0.4568
DEBUG - 2020-06-16 20:59:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:17 --> Total execution time: 0.2213
DEBUG - 2020-06-16 20:59:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:17 --> Total execution time: 0.3432
DEBUG - 2020-06-16 20:59:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:18 --> Total execution time: 0.4857
DEBUG - 2020-06-16 20:59:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 18:59:21 --> Total execution time: 0.2843
DEBUG - 2020-06-16 20:59:21 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:21 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:21 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:21 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:21 --> Total execution time: 0.2503
DEBUG - 2020-06-16 20:59:21 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:21 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:21 --> Total execution time: 0.4191
DEBUG - 2020-06-16 20:59:27 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:27 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:27 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:27 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 20:59:27 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:59:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 20:59:27 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:59:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 20:59:27 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:59:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 20:59:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:59:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:59:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:59:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 20:59:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:59:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:59:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:59:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 20:59:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:59:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:59:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:59:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 20:59:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:59:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:59:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:59:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 20:59:28 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 20:59:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 20:59:28 --> Total execution time: 0.3677
DEBUG - 2020-06-16 20:59:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:28 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 20:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 20:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 20:59:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:28 --> Total execution time: 0.3106
DEBUG - 2020-06-16 20:59:28 --> KB_Loader class Initialized
DEBUG - 2020-06-16 20:59:28 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 20:59:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:28 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 20:59:28 --> Total execution time: 0.4968
DEBUG - 2020-06-16 21:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:01:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:01:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:01:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:01:23 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:01:23 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 21:01:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 21:01:23 --> Total execution time: 0.3704
DEBUG - 2020-06-16 21:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:01:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:01:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:01:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:01:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:01:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:01:23 --> Total execution time: 0.1870
DEBUG - 2020-06-16 21:01:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:01:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:01:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:01:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:01:24 --> Total execution time: 0.3273
DEBUG - 2020-06-16 21:01:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:01:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:01:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:01:34 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:01:34 --> Could not find the language line "smd_media_library"
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:01:34 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 21:01:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 21:01:34 --> Total execution time: 0.4221
DEBUG - 2020-06-16 21:01:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:01:35 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:01:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:01:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:01:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:01:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:01:35 --> Total execution time: 0.2378
DEBUG - 2020-06-16 21:01:35 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:01:35 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:01:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:01:35 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:01:35 --> Total execution time: 0.3609
DEBUG - 2020-06-16 21:02:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:02:29 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:02:29 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:02:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:29 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:02:29 --> Could not find the language line "smd_media_library"
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:29 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 21:02:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 21:02:29 --> Total execution time: 0.3646
DEBUG - 2020-06-16 21:02:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:02:29 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:02:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:02:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:02:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:30 --> Total execution time: 0.2291
DEBUG - 2020-06-16 21:02:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:02:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:02:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:30 --> Total execution time: 0.3990
DEBUG - 2020-06-16 21:02:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:02:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:02:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:39 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:02:39 --> Could not find the language line "smd_media_library"
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:39 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 21:02:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 21:02:39 --> Total execution time: 0.4316
DEBUG - 2020-06-16 21:02:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:02:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:02:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:02:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:39 --> Total execution time: 0.1955
DEBUG - 2020-06-16 21:02:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:02:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:02:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:40 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:40 --> Total execution time: 0.3387
DEBUG - 2020-06-16 21:02:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:02:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:02:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:02:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:52 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:02:52 --> Could not find the language line "smd_media_library"
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 825
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 829
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 833
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 837
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 841
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 845
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 849
ERROR - 2020-06-16 21:02:52 --> Severity: Notice --> Undefined variable: permissions C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
ERROR - 2020-06-16 21:02:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\skeleton\content\modules\media\views\content\index.php 889
DEBUG - 2020-06-16 21:02:52 --> Total execution time: 0.4036
DEBUG - 2020-06-16 21:02:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:02:52 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:02:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:02:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:02:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:52 --> Total execution time: 0.1993
DEBUG - 2020-06-16 21:02:52 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:02:52 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:02:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:52 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:02:52 --> Total execution time: 0.3275
DEBUG - 2020-06-16 21:03:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:03:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:03:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:03:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:03:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:03:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:03:01 --> Total execution time: 0.2989
DEBUG - 2020-06-16 21:03:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:03:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:03:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:03:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:03:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:03:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:03:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:03:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:03:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:05:15 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:05:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:15 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:05:15 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 21:05:15 --> Total execution time: 0.2434
DEBUG - 2020-06-16 21:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:05:15 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:05:15 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:05:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:15 --> Total execution time: 0.3034
DEBUG - 2020-06-16 21:05:15 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:05:15 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:15 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:15 --> Total execution time: 0.4399
DEBUG - 2020-06-16 21:05:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:05:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:05:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:05:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:05:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:23 --> Total execution time: 0.4850
DEBUG - 2020-06-16 21:05:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:05:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:05:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:05:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:05:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:05:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:05:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:06:43 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:06:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:06:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:06:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:06:44 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:06:44 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 21:06:44 --> Total execution time: 0.2373
DEBUG - 2020-06-16 21:06:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:06:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:06:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:06:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:06:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:06:44 --> Total execution time: 0.2329
DEBUG - 2020-06-16 21:06:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:06:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:06:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:06:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:06:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:06:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:06:45 --> Total execution time: 0.3676
DEBUG - 2020-06-16 21:06:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:06:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:06:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:06:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:06:45 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:06:45 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:06:45 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:06:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:06:45 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:07:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:07:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:07:03 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:07:03 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 21:07:03 --> Total execution time: 0.1873
DEBUG - 2020-06-16 21:07:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:07:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:07:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:07:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:07:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:07:04 --> Total execution time: 0.1764
DEBUG - 2020-06-16 21:07:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:07:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:07:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:07:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:07:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:07:04 --> Total execution time: 0.3322
DEBUG - 2020-06-16 21:10:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:06 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:06 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:07 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:10:07 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 21:10:07 --> Total execution time: 0.2046
DEBUG - 2020-06-16 21:10:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:07 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:07 --> Total execution time: 0.2907
DEBUG - 2020-06-16 21:10:07 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:07 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:07 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:07 --> Total execution time: 0.4890
DEBUG - 2020-06-16 21:10:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:09 --> Total execution time: 0.3086
DEBUG - 2020-06-16 21:10:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:09 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:09 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:09 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:32 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:10:32 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 21:10:32 --> Total execution time: 0.2065
DEBUG - 2020-06-16 21:10:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:32 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:32 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:32 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:32 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:33 --> Total execution time: 0.3846
DEBUG - 2020-06-16 21:10:33 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:33 --> Total execution time: 0.6224
DEBUG - 2020-06-16 21:10:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:34 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:10:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:10:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:10:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:10:44 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:10:44 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 21:10:44 --> Total execution time: 0.1929
DEBUG - 2020-06-16 21:15:41 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:15:41 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:15:41 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:15:41 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:15:41 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 21:15:41 --> Total execution time: 0.2168
DEBUG - 2020-06-16 21:15:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:15:56 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:15:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:15:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:15:56 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:15:56 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 21:15:56 --> Total execution time: 0.2456
DEBUG - 2020-06-16 21:19:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:19:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:19:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:19:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:19:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:19:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:19:02 --> Total execution time: 0.3007
DEBUG - 2020-06-16 21:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:19:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:19:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:19:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:19:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:19:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:19:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:19:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:19:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:19:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:35:36 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:35:36 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:35:36 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:35:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:35:36 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:37:14 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:37:14 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:37:14 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:37:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:37:14 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:37:15 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 81
DEBUG - 2020-06-16 21:37:30 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:37:30 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:37:30 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:37:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:37:30 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:38:40 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:38:40 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:38:40 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:38:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:38:40 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:44:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:44:06 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:44:06 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:44:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:44:06 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 21:44:06 --> Severity: Notice --> Undefined property: Content::$CI C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 81
ERROR - 2020-06-16 21:44:06 --> Severity: Notice --> Trying to get property 'router' of non-object C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 81
ERROR - 2020-06-16 21:44:06 --> Severity: error --> Exception: Call to a member function fetch_module() on null C:\xampp\htdocs\skeleton\content\modules\media\controllers\Content.php 81
DEBUG - 2020-06-16 21:44:16 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:44:16 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:44:16 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:44:16 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:45:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:45:12 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:45:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:45:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:45:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:47:42 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:47:42 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:47:42 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:47:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:47:42 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:48:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:48:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:48:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:48:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:48:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:50:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:50:34 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:50:34 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:50:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:50:34 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:55:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:55:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:55:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:55:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:55:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:59:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:59:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:59:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:59:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:59:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:59:47 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 21:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 21:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 21:59:47 --> KB_Loader class Initialized
DEBUG - 2020-06-16 21:59:48 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 21:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 21:59:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:00:02 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:00:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:00:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:00:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:00:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:00:13 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:00:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:00:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:00:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:02:41 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:02:41 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:02:41 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:02:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:02:41 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 22:02:41 --> Severity: error --> Exception: Using $this when not in object context C:\xampp\htdocs\skeleton\skeleton\third_party\theme\helpers\theme_helper.php 224
DEBUG - 2020-06-16 22:02:55 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:02:55 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:02:55 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:02:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:02:55 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:03:31 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:03:31 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:03:31 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:03:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:03:31 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:03:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:03:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:03:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:03:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:03:44 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:03:51 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:03:51 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:03:51 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:03:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:03:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:06:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:06:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:06:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:06:19 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 22:06:19 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 22:06:19 --> Total execution time: 0.3232
DEBUG - 2020-06-16 22:06:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:06:19 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:06:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:06:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:06:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:06:19 --> Total execution time: 0.4435
DEBUG - 2020-06-16 22:06:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:06:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:06:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:06:20 --> Total execution time: 0.5948
DEBUG - 2020-06-16 22:06:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:06:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:06:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:06:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:06:20 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:06:21 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:06:21 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:06:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:07:16 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:07:16 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:07:16 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:07:16 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 22:07:16 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 22:07:17 --> Total execution time: 0.2812
DEBUG - 2020-06-16 22:07:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:07:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:07:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:07:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:07:17 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:07:17 --> Total execution time: 0.3858
DEBUG - 2020-06-16 22:07:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:07:17 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:07:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:07:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:07:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:07:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:07:18 --> Total execution time: 0.4253
DEBUG - 2020-06-16 22:07:18 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:07:18 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:07:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:07:18 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:07:18 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:07:19 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:07:19 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:07:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:07:19 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:08:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:08:03 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:08:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:08:04 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 22:08:04 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 22:08:04 --> Total execution time: 0.4377
DEBUG - 2020-06-16 22:08:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:08:04 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:08:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:08:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:08:04 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:08:04 --> Total execution time: 0.4969
DEBUG - 2020-06-16 22:08:04 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:08:04 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:08:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:08:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:08:05 --> Total execution time: 0.6880
DEBUG - 2020-06-16 22:08:05 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:08:05 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:08:05 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:08:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:08:05 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:08:06 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:08:06 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:08:06 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:08:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:08:06 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:22 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:22 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:22 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 22:09:22 --> Could not find the language line "smd_media_library"
ERROR - 2020-06-16 22:09:22 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, class 'Content' does not have a method 'add_action' C:\xampp\htdocs\skeleton\skeleton\third_party\bkader\class-hooks.php 370
DEBUG - 2020-06-16 22:09:22 --> Total execution time: 0.4146
DEBUG - 2020-06-16 22:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:22 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:23 --> Total execution time: 0.3833
DEBUG - 2020-06-16 22:09:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:23 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:23 --> Total execution time: 0.5714
DEBUG - 2020-06-16 22:09:23 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:23 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:23 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:24 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:38 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:38 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:38 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 22:09:38 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 22:09:38 --> Total execution time: 0.2080
DEBUG - 2020-06-16 22:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:38 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:39 --> Total execution time: 0.3147
DEBUG - 2020-06-16 22:09:39 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:39 --> Total execution time: 0.5390
DEBUG - 2020-06-16 22:09:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:40 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:40 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:40 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:40 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:40 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:40 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:40 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:09:59 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:09:59 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:09:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:09:59 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 22:09:59 --> Could not find the language line "smd_media_library"
DEBUG - 2020-06-16 22:09:59 --> Total execution time: 0.2813
DEBUG - 2020-06-16 22:09:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:09:59 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:10:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:10:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:10:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:10:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:10:00 --> Total execution time: 0.4661
DEBUG - 2020-06-16 22:10:00 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:10:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:10:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:10:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:10:00 --> Total execution time: 0.7010
DEBUG - 2020-06-16 22:10:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:10:01 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:10:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:10:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:10:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:10:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:10:01 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:10:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:10:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:10:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:12:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:12:44 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:12:44 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:12:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:12:44 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 22:12:44 --> 404 Page Not Found: 
DEBUG - 2020-06-16 22:12:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:12:49 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:12:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:12:49 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 22:12:49 --> 404 Page Not Found: 
DEBUG - 2020-06-16 22:13:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-16 22:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-16 22:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-16 22:13:20 --> KB_Loader class Initialized
DEBUG - 2020-06-16 22:13:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-16 22:13:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-16 22:13:21 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-16 22:13:21 --> 404 Page Not Found: 
