<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2020-06-20 00:36:08 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:36:09 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:36:09 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:36:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:36:10 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-20 00:36:10 --> Severity: Notice --> Undefined property: Content::$_module C:\xampp\htdocs\skeleton\application\modules\media\controllers\Content.php 70
DEBUG - 2020-06-20 00:36:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:36:10 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:36:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:36:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:36:10 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-20 00:36:10 --> Severity: Notice --> Undefined property: Content::$_module C:\xampp\htdocs\skeleton\application\modules\media\controllers\Content.php 70
DEBUG - 2020-06-20 00:37:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:37:11 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:37:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:37:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:11 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-20 00:37:11 --> Severity: Notice --> Undefined property: Content::$_module C:\xampp\htdocs\skeleton\application\modules\media\controllers\Content.php 70
DEBUG - 2020-06-20 00:37:17 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:37:17 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:37:17 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:37:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:17 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-20 00:37:17 --> Severity: Notice --> Undefined property: Content::$_module C:\xampp\htdocs\skeleton\application\modules\media\controllers\Content.php 70
DEBUG - 2020-06-20 00:37:20 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:37:20 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:37:20 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:37:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:20 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-20 00:37:20 --> 404 Page Not Found: 
DEBUG - 2020-06-20 00:37:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:37:25 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:37:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:37:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:25 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:25 --> Total execution time: 0.4446
DEBUG - 2020-06-20 00:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:37:25 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:37:25 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:37:25 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:37:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:26 --> Total execution time: 0.5567
DEBUG - 2020-06-20 00:37:26 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:37:26 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:37:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:26 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:26 --> Total execution time: 1.2546
DEBUG - 2020-06-20 00:37:33 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:37:33 --> No URI present. Default controller set.
DEBUG - 2020-06-20 00:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:37:33 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:37:33 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:37:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:33 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:37:33 --> Total execution time: 0.5463
DEBUG - 2020-06-20 00:44:08 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:44:08 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:44:08 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:08 --> User_agent class already loaded. Second attempt ignored.
ERROR - 2020-06-20 00:44:08 --> Severity: Notice --> Undefined property: Content::$_module C:\xampp\htdocs\skeleton\application\modules\media\controllers\Content.php 70
DEBUG - 2020-06-20 00:44:13 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:44:13 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:44:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:44:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:13 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-20 00:44:13 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
ERROR - 2020-06-20 00:44:13 --> Could not find the language line "title"
ERROR - 2020-06-20 00:44:13 --> Severity: error --> Exception: Call to a member function count() on null C:\xampp\htdocs\skeleton\application\modules\media_old\controllers\Content.php 105
DEBUG - 2020-06-20 00:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:44:49 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:44:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:44:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:49 --> Total execution time: 0.2229
DEBUG - 2020-06-20 00:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:44:49 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:44:49 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:44:49 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:44:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:49 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:50 --> Total execution time: 0.2281
DEBUG - 2020-06-20 00:44:50 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:44:50 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:44:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:50 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:50 --> Total execution time: 0.3973
DEBUG - 2020-06-20 00:44:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:44:56 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:44:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:56 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-20 00:44:56 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-20 00:44:56 --> Total execution time: 0.3334
DEBUG - 2020-06-20 00:44:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:44:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:44:56 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:44:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:44:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:57 --> Total execution time: 0.2890
DEBUG - 2020-06-20 00:44:57 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:44:57 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:44:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:57 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:44:57 --> Total execution time: 0.5146
DEBUG - 2020-06-20 00:45:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:00 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:00 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-20 00:45:00 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-20 00:45:00 --> Total execution time: 0.2871
DEBUG - 2020-06-20 00:45:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:00 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:00 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:00 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:00 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:00 --> Total execution time: 0.2740
DEBUG - 2020-06-20 00:45:01 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:01 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:01 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:01 --> Total execution time: 0.5140
DEBUG - 2020-06-20 00:45:02 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:02 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:02 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:03 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-20 00:45:03 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-20 00:45:03 --> Total execution time: 0.3429
DEBUG - 2020-06-20 00:45:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:03 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:03 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:03 --> Total execution time: 0.2663
DEBUG - 2020-06-20 00:45:03 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:03 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:03 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:03 --> Total execution time: 0.5066
DEBUG - 2020-06-20 00:45:10 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:10 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:10 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:10 --> Config file loaded: C:\xampp\htdocs\skeleton\application\config/inputs.php
DEBUG - 2020-06-20 00:45:10 --> Config file loaded: C:\xampp\htdocs\skeleton\skeleton\config/inputs.php
DEBUG - 2020-06-20 00:45:10 --> Total execution time: 0.3327
DEBUG - 2020-06-20 00:45:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:11 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:11 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:11 --> Total execution time: 0.3208
DEBUG - 2020-06-20 00:45:11 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:11 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:11 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:11 --> Total execution time: 0.4993
DEBUG - 2020-06-20 00:45:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:24 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:24 --> Total execution time: 0.2875
DEBUG - 2020-06-20 00:45:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:24 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:24 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:24 --> Total execution time: 0.3034
DEBUG - 2020-06-20 00:45:24 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:24 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:24 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:24 --> Total execution time: 0.4747
DEBUG - 2020-06-20 00:45:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:39 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:39 --> Total execution time: 0.2647
DEBUG - 2020-06-20 00:45:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:39 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:45:39 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:39 --> Total execution time: 0.2935
DEBUG - 2020-06-20 00:45:39 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:45:39 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:45:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:39 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:45:39 --> Total execution time: 0.5065
DEBUG - 2020-06-20 00:45:44 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-06-20 00:45:44 --> 404 Page Not Found: Keshav/index
DEBUG - 2020-06-20 00:56:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:56:12 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:56:12 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:56:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:56:12 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:56:12 --> Total execution time: 0.3200
DEBUG - 2020-06-20 00:56:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:56:12 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 00:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 00:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 00:56:13 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:56:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:56:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:56:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:56:13 --> Total execution time: 0.3362
DEBUG - 2020-06-20 00:56:13 --> KB_Loader class Initialized
DEBUG - 2020-06-20 00:56:13 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 00:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 00:56:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:56:13 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 00:56:13 --> Total execution time: 0.5235
DEBUG - 2020-06-20 12:33:56 --> UTF-8 Support Enabled
DEBUG - 2020-06-20 12:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-06-20 12:33:56 --> No URI present. Default controller set.
DEBUG - 2020-06-20 12:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2020-06-20 12:33:56 --> KB_Loader class Initialized
DEBUG - 2020-06-20 12:33:56 --> Config file loaded: C:/xampp/htdocs/skeleton/skeleton/third_party/theme/config/theme.php
DEBUG - 2020-06-20 12:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2020-06-20 12:33:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 12:33:58 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2020-06-20 12:33:58 --> Total execution time: 2.5610
