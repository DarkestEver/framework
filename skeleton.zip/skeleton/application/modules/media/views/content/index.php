<?php
/**
 * CodeIgniter Skeleton
 *
 * A ready-to-use CodeIgniter skeleton  with tons of new features
 * and a whole new concept of hooks (actions and filters) as well
 * as a ready-to-use and application-free theme and plugins system.
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2018, Kader Bouyakoub <bkader@mail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package 	CodeIgniter
 * @author 		Kader Bouyakoub <bkader@mail.com>
 * @copyright	Copyright (c) 2018, Kader Bouyakoub <bkader@mail.com>
 * @license 	http://opensource.org/licenses/MIT	MIT License
 * @link 		https://goo.gl/wGXHO9
 * @since 		Version 1.0.0
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Media module - Admin: list media.
 *
 * @package 	CodeIgniter
 * @subpackage 	Skeleton
 * @category 	Modules\Views
 * @author 		Kader Bouyakoub <bkader@mail.com>
 * @link 		https://goo.gl/wGXHO9
 * @copyright 	Copyright (c) 2018, Kader Bouyakoub (https://goo.gl/wGXHO9)
 * @since 		Version 1.0.0
 * @version 	1.4.0
 */
// Upload form.
?>

	<link id="favicon" rel="shortcut icon" type="image/png" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAhFBMVEUAAAAAAAD////p6ekLCwt+fn43NzccHBzT09PIyMjFxcWysrKnp6ekpKSfn5+ampqNjY2IiIiCgoJ0dHRubm5kZGRdXV1PT09JSUlEREQjIyMTExMHBwf7+/v19fXg4ODW1tbAwMCRkZGDg4N5eXloaGhTU1M+Pj4vLy8sLCwlJSURERGNXQbaAAAAAXRSTlN4HjghaAAAAI1JREFUGNNlz0cSwkAQQ9HRdyI542xyhvvfj5opFoC167dolYzRT/5v6Qui+P6Bp3wLDakDPwM4SQGdA2B1mdFqgRw0C3wNHMVB9dr+wJMeFCHpBiqjG4n8PVEAQU5klOPtoNacpTxPRjOSrBoleA3EtmUrm5C5rpQyHSsHBWeV2JZ2lEsvhctek3GT+W8jMQY7SBmDowAAAABJRU5ErkJggg==">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jstree/3.3.7/themes/default/style.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.43.0/codemirror.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.43.0/addon/lint/lint.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.43.0/addon/dialog/dialog.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.min.css">
		<script type="text/javascript">
		var editor,
			modes = {
				"js": "javascript",
				"json": "javascript",
				"md": "text/x-markdown"
			},
			last_keyup_press = false,
			last_keyup_double = false;

		function alertBox(title, message, color) {
			iziToast.show({
				title: title,
				message: message,
				color: color,
				position: "bottomRight",
				transitionIn: "fadeInUp",
				transitionOut: "fadeOutRight",
			});
		}

		function reloadFiles(hash) {
			$.post("<?= $_SERVER['PHP_SELF'] ?>", {
				action: "reload"
			}, function(data) {
				$("#files > div").jstree("destroy");
				$("#files > div").html(data.data);
				$("#files > div").jstree();
				$("#files > div a:first").click();
				$("#path").html("");

				window.location.hash = hash || "/";

				if (hash) {
					$("#files a[data-file=\"" + hash + "\"], #files a[data-dir=\"" + hash + "\"]").click();
				}
			});
		}

		function sha512(string) {
			return crypto.subtle.digest("SHA-512", new TextEncoder("UTF-8").encode(string)).then(buffer => {
				return Array.prototype.map.call(new Uint8Array(buffer), x => (("00" + x.toString(16)).slice(-2))).join("");
			});
		}

		function setCookie(name, value, timeout) {
			if (timeout) {
				var date = new Date();
				date.setTime(date.getTime() + (timeout * 1000));
				timeout = "; expires=" + date.toUTCString();
			} else {
				timeout = "";
			}

			document.cookie = name + "=" + value + timeout + "; path=/";
		}

		function getCookie(name) {
			var cookies = decodeURIComponent(document.cookie).split(';');

			for (var i = 0; i < cookies.length; i++) {
				if (cookies[i].trim().indexOf(name + "=") == 0) {
					return cookies[i].trim().substring(name.length + 1).trim();
				}
			}

			return false;
		}

		$(function() {
			editor = CodeMirror.fromTextArea($("#editor")[0], {
				lineNumbers: true,
				mode: "application/x-httpd-php",
				indentUnit: 4,
				indentWithTabs: true,
				lineWrapping: true,
				gutters: ["CodeMirror-lint-markers"],
				lint: true
			});

			$("#files > div").jstree({
				state: {
					key: "pheditor"
				},
				plugins: ["state"]
			});

			$("#files").on("dblclick", "a[data-file]", function(event) {
				event.preventDefault();
				<?php

				$base_dir = str_replace($_SERVER['DOCUMENT_ROOT'], '', str_replace(DS, '/', MAIN_DIR));

				if (substr($base_dir, 0, 1) !== '/') {
					$base_dir = '/' . $base_dir;
				}

				?>
				window.open("<?= $base_dir ?>" + $(this).attr("data-file"));
			});

			

			$(".dropdown .new-file").click(function() {
				var path = $("#path").html();

				if (path.length > 0) {
					var name = prompt("Please enter file name:", "new-file.php"),
						end = path.substring(path.length - 1),
						file = "";

					if (name != null && name.length > 0) {
						if (end == "/") {
							file = path + name;
						} else {
							file = path.substring(0, path.lastIndexOf("/") + 1) + name;
						}

						$.post("<?= $_SERVER['PHP_SELF'] ?>", {
							action: "save",
							file: file,
							data: ""
						}, function(data) {
							alertBox(data.error ? "Error" : "Success", data.message, data.error ? "red" : "green");

							if (data.error == false) {
								reloadFiles();
							}
						});
					}
				} else {
					alertBox("Warning", "Please select a file or directory", "yellow");
				}
			});

			$(".dropdown .new-dir").click(function() {
				var path = $("#path").html();

				if (path.length > 0) {
					var name = prompt("Please enter directory name:", "new-dir"),
						end = path.substring(path.length - 1),
						dir = "";

					if (name != null && name.length > 0) {
						if (end == "/") {
							dir = path + name;
						} else {
							dir = path.substring(0, path.lastIndexOf("/") + 1) + name;
						}

						$.post("<?= $_SERVER['PHP_SELF'] ?>", {
							action: "make-dir",
							dir: dir
						}, function(data) {
							alertBox(data.error ? "Error" : "Success", data.message, data.error ? "red" : "green");

							if (data.error == false) {
								reloadFiles();
							}
						});
					}
				} else {
					alertBox("Warning", "Please select a file or directory", "yellow");
				}
			});

			$(".dropdown .save").click(function() {
				var path = $("#path").html(),
					data = editor.getValue();

				if (path.length > 0) {
					sha512(data).then(function(digest) {
						$("#digest").val(digest);
					});

					$.post("<?= $_SERVER['PHP_SELF'] ?>", {
						action: "save",
						file: path,
						data: data
					}, function(data) {
						alertBox(data.error ? "Error" : "Success", data.message, data.error ? "red" : "green");
					});
				} else {
					alertBox("Warning", "Please select a file", "yellow");
				}
			});

			$(".dropdown .close").click(function() {
				editor.setValue("");
				$("#files > div a:first").click();
				$(".dropdown").find(".save, .delete, .rename, .reopen, .close").addClass("disabled");
			});

			$(".dropdown .delete").click(function() {
				var path = $("#path").html();

				if (path.length > 0) {
					if (confirm("Are you sure to delete this file?")) {
						$.post("<?= $_SERVER['PHP_SELF'] ?>", {
							action: "delete",
							path: path
						}, function(data) {
							alertBox(data.error ? "Error" : "Success", data.message, data.error ? "red" : "green");

							if (data.error == false) {
								reloadFiles();
							}
						});
					}
				} else {
					alertBox("Warning", "Please select a file or directory", "yellow");
				}
			});

			$(".dropdown .rename").click(function() {
				var path = $("#path").html(),
					split = path.split("/"),
					file = split[split.length - 1],
					dir = split[split.length - 2],
					new_file_name;

				if (path.length > 0) {
					if (file.length > 0) {
						new_file_name = file;
					} else if (dir.length > 0) {
						new_file_name = dir;
					} else {
						new_file_name = "new-file";
					}

					var name = prompt("Please enter new name:", new_file_name);

					if (name != null && name.length > 0) {
						$.post("<?= $_SERVER['PHP_SELF'] ?>", {
							action: "rename",
							path: path,
							name: name
						}, function(data) {
							alertBox(data.error ? "Error" : "Success", data.message, data.error ? "red" : "green");

							if (data.error == false) {
								reloadFiles(path.substring(0, path.lastIndexOf("/")) + "/" + name);
							}
						});
					}
				} else {
					alertBox("Warning", "Please select a file or directory", "yellow");
				}
			});

			$(".dropdown .reopen").click(function() {
				var path = $("#path").html();

				if (path.length > 0) {
					$(window).trigger("hashchange");
				}
			});

			$(window).resize(function() {
				if (window.innerWidth >= 720) {
					var terminalHeight = $("#terminal").length > 0 ? $("#terminal").height() : 0,
						height = window.innerHeight - $(".CodeMirror")[0].getBoundingClientRect().top - terminalHeight - 30;

					$("#files, .CodeMirror").css({
						"height": height + "px"
					});
				} else {
					$("#files > div, .CodeMirror").css({
						"height": ""
					});
				}

				if (document.fullscreen) {
					$("#prompt pre").height($(window).height() - $("#prompt input.command").height() - 20);
				}
			});

			$(window).resize();

			$(".alert").click(function() {
				$(this).fadeOut();
			});

			$(document).bind("keyup keydown", function(event) {
				if ((event.ctrlKey || event.metaKey) && event.shiftKey) {
					if (event.keyCode == 78) {
						$(".dropdown .new-file").click();
						event.preventDefault();

						return false;
					} else if (event.keyCode == 83) {
						$(".dropdown .save").click();
						event.preventDefault();

						return false;
					} else if (event.keyCode == 76) {
						$("#terminal .toggle").click();
						event.preventDefault();

						return false;
					}
				}
			});

			$(document).bind("keyup", function(event) {
				if (event.keyCode == 27) {
					if (last_keyup_press == true) {
						last_keyup_double = true;

						$("#fileMenu").click();
						$("body").focus();
					} else {
						last_keyup_press = true;

						setTimeout(function() {
							if (last_keyup_double === false) {
								if (document.activeElement.tagName.toLowerCase() == "textarea") {
									if ($("#terminal #prompt").hasClass("show")) {
										$("#terminal .command").focus();
									} else {
										$(".jstree-clicked").focus();
									}
								} else if (document.activeElement.tagName.toLowerCase() == "input") {
									$(".jstree-clicked").focus();
								} else {
									editor.focus();
								}
							}

							last_keyup_press = false;
							last_keyup_double = false;
						}, 250);
					}
				}
			});

			$(window).on("hashchange", function() {
				var hash = window.location.hash.substring(1),
					data = editor.getValue();

				if (hash.length > 0) {
					sha512(data).then(function(digest) {
						if ($("#digest").val().length < 1 || $("#digest").val() == digest) {
							if (hash.substring(hash.length - 1) == "/") {
								var dir = $("a[data-dir='" + hash + "']");

								if (dir.length > -1) {
									editor.setValue("");
									$("#digest").val("");
									$("#path").html(hash);
									$(".dropdown").find(".save, .reopen, .close").addClass("disabled");
									$(".dropdown").find(".delete, .rename").removeClass("disabled");
								}
							} else {
								var file = $("a[data-file='" + hash + "']");

								if (file.length > -1) {
									$("#loading").fadeIn(250);

									$.post("<?= $_SERVER['PHP_SELF'] ?>", {
										action: "open",
										file: encodeURIComponent(hash)
									}, function(data) {
										if (data.error == true) {
											alertBox("Error", data.message, "red");

											return false;
										}

										editor.setValue(data.data);
										editor.setOption("mode", "application/x-httpd-php");

										sha512(data.data).then(function(digest) {
											$("#digest").val(digest);
										});

										if (hash.lastIndexOf(".") > 0) {
											var extension = hash.substring(hash.lastIndexOf(".") + 1);

											if (modes[extension]) {
												editor.setOption("mode", modes[extension]);
											}
										}

										$("#editor").attr("data-file", hash);
										$("#path").html(hash).hide().fadeIn(250);
										$(".dropdown").find(".save, .delete, .rename, .reopen, .close").removeClass("disabled");

										$("#loading").fadeOut(250);
									});
								}
							}
						} else if (confirm("Discard changes?")) {
							$("#digest").val("");

							$(window).trigger("hashchange");
						}
					});
				}
			});

			if (window.location.hash.length < 1) {
				window.location.hash = "/";
			} else {
				$(window).trigger("hashchange");
			}

			$("#files").on("click", ".jstree-anchor", function() {
				location.href = $(this).attr("href");
			});

			$(document).ajaxError(function(event, request, settings) {
				var message = "An error occurred with this request.";

				if (request.responseText.length > 0) {
					message = request.responseText;
				}

				if (confirm(message + " Do you want to reload the page?")) {
					location.reload();
				}

				$("#loading").fadeOut(250);
			});

			$(window).keydown(function(event) {
				if ($("#fileMenu[aria-expanded='true']").length > 0) {
					var code = event.keyCode;

					if (code == 78) {
						$(".new-file").click();
					} else if (code == 83) {
						$(".save").click();
					} else if (code == 68) {
						$(".delete").click();
					} else if (code == 82) {
						$(".rename").click();
					} else if (code == 79) {
						$(".reopen").click();
					} else if (code == 67) {
						$(".close").click();
					} else if (code == 85) {
						$(".upload-file").click();
					}
				}
			});

			$(".dropdown .upload-file").click(function() {
				$("#uploadFileModal").modal("show");
				$("#uploadFileModal input").focus();
			});

			$("#uploadFileModal button").click(function() {
				var form = $(this).closest("form"),
					formdata = false;

				form.find("input[name=destination]").val(window.location.hash.substring(1));

				if (window.FormData) {
					formdata = new FormData(form[0]);
				}

				$.ajax({
					url: "<?= $_SERVER['PHP_SELF'] ?>",
					data: formdata ? formdata : form.serialize(),
					cache: false,
					contentType: false,
					processData: false,
					type: "POST",
					success: function(data, textStatus, jqXHR) {
						alertBox(data.error ? "Error" : "Success", data.message, data.error ? "red" : "green");

						if (data.error == false) {
							reloadFiles();
						}
					}
				});
			});

			var terminal_dir = "";

			$("#terminal .command").keydown(function(event) {
				if (event.keyCode == 13 && $(this).val().length > 0) {
					var _this = $(this)
					_val = _this.val();

					if (_val.toLowerCase() == "clear") {
						$("#terminal pre").html("");
						_this.val("").focus();

						return true;
					}

					_this.prop("disabled", true);
					$("#terminal pre").append("> " + _val + "\n");
					$("#terminal pre").animate({
						scrollTop: $("#terminal pre").prop("scrollHeight")
					});

					$.post("<?= $_SERVER['PHP_SELF'] ?>", {
						action: "terminal",
						command: _val,
						dir: terminal_dir
					}, function(data) {
						if (data.error) {
							$("#terminal pre").append(data.message);
						} else {
							if (data.dir != null) {
								terminal_dir = data.dir;
							}

							if (data.result == null) {
								data.result = "Command not found\n";
							}

							$("#terminal pre").append(data.result);
						}

						$("#terminal pre").animate({
							scrollTop: $("#terminal pre").prop("scrollHeight")
						});
						_this.val("").prop("disabled", false).focus();
					});
				}
			});

			$("#terminal .toggle").click(function() {
				if ($(this).attr("aria-expanded") != "true") {
					$("#terminal .command").focus();
				}
			});

			$('#prompt').on('show.bs.collapse', function() {
				$("#terminal").find(".clear, .copy, .fullscreen").css({
					"display": "block",
					"opacity": "0",
					"margin-right": "-30px"
				}).animate({
					"opacity": "1",
					"margin-right": "0px"
				}, 250);

				if (window.innerWidth >= 720) {
					var height = window.innerHeight - $(".CodeMirror")[0].getBoundingClientRect().top - $("#terminal #prompt").height() - 55;

					$("#files, .CodeMirror").animate({
						"height": height + "px"
					}, 250);
				} else {
					$("#files > div, .CodeMirror").animate({
						"height": ""
					}, 250);
				}

				setCookie("terminal", "1", 86400);
			}).on('hide.bs.collapse', function() {
				$("#terminal").find(".clear, .copy, .fullscreen").fadeOut();

				if (window.innerWidth >= 720) {
					var height = window.innerHeight - $(".CodeMirror")[0].getBoundingClientRect().top - $("#terminal span").height() - 35;

					$("#files, .CodeMirror").animate({
						"height": height + "px"
					}, 250);
				} else {
					$("#files > div, .CodeMirror").animate({
						"height": ""
					}, 250);
				}

				setCookie("terminal", "0", 86400);
			}).on('shown.bs.collapse', function() {
				$("#terminal .command").focus();
			});

			$("#terminal button.clear").click(function() {
				$("#terminal pre").html("");
				$("#terminal .command").val("").focus();
			});

			$("#terminal button.copy").click(function() {
				$("#terminal").append($("<textarea>").html($("#terminal pre").html()));

				element = $("#terminal textarea")[0];
				element.select();
				element.setSelectionRange(0, 99999);
				document.execCommand("copy");

				$("#terminal textarea").remove();
			});

			if (getCookie("terminal") == "1") {
				$("#terminal .toggle").click();
			}

			$("#terminal .fullscreen").click(function() {
				var element = $("#terminal #prompt")[0];

				if (element.requestFullscreen) {
					element.requestFullscreen();

					setTimeout(function() {
						$("#prompt pre").height($(window).height() - $("#prompt input.command").height() - 20);
						$("#prompt input.command").focus();
					}, 500);
				}
			});

			$(window).on("fullscreenchange", function() {
				if (document.fullscreenElement == null) {
					$("#terminal #prompt pre").css("height", "");
					$(window).resize();
				}
			});
		});
	</script>
</head>

<body>

	<div class="container-fluid">

		<div class="row p-3">
			<div class="col-md-3">
				<h1>Templates</h1>
			</div>
			<div class="col-md-9">
				<div class="float-left">
					<div class="dropdown float-left">
						<button class="btn btn-secondary dropdown-toggle" type="button" id="fileMenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">File</button>
						<div class="dropdown-menu" aria-labelledby="fileMenu">
							<?php if (in_array('newfile', $permissions)) { ?>
								<a class="dropdown-item new-file" href="javascript:void(0);">New File <span class="float-right text-secondary">N</span></a>
							<?php } ?>

							<?php if (in_array('newdir', $permissions)) { ?>
								<a class="dropdown-item new-dir" href="javascript:void(0);">New Directory</a>
							<?php } ?>

							<?php if (in_array('uploadfile', $permissions)) { ?>
								<a class="dropdown-item upload-file" href="javascript:void(0);">Upload File <span class="float-right text-secondary">U</span></a>
							<?php } ?>

							<?php if (in_array('newfile', $permissions) || in_array('newdir', $permissions)) { ?>
								<div class="dropdown-divider"></div>
							<?php } ?>

							<?php if (in_array('newfile', $permissions) || in_array('editfile', $permissions)) { ?>
								<a class="dropdown-item save disabled" href="javascript:void(0);">Save <span class="float-right text-secondary">S</span></a>
							<?php } ?>

							<?php if (in_array('deletefile', $permissions) || in_array('deletedir', $permissions)) { ?>
								<a class="dropdown-item delete disabled" href="javascript:void(0);">Delete <span class="float-right text-secondary">D</span></a>
							<?php } ?>

							<?php if (in_array('renamefile', $permissions) || in_array('renamedir', $permissions)) { ?>
								<a class="dropdown-item rename disabled" href="javascript:void(0);">Rename <span class="float-right text-secondary">R</span></a>
							<?php } ?>

							<a class="dropdown-item reopen disabled" href="javascript:void(0);">Re-open <span class="float-right text-secondary">O</span></a>
							<div class="dropdown-divider"></div>
							<a class="dropdown-item close disabled" href="javascript:void(0);">Close <span class="float-right text-secondary">C</span></a>
						</div>
					</div>
					<span id="path" class="btn float-left"></span>
				</div>

				
			</div>
		</div>

		<div class="row px-3">
			<div class="col-lg-3 col-md-3 col-sm-12 col-12">
				<div id="files" class="card">
					<div class="card-block"><?= files(MAIN_DIR) ?></div>
				</div>
			</div>

			<div class="col-lg-9 col-md-9 col-sm-12 col-12">
				<div class="card">
					<div class="card-block">
						<div id="loading">
							<div class="lds-ring">
								<div></div>
								<div></div>
								<div></div>
								<div></div>
							</div>
						</div>
						<textarea id="editor" data-file="" class="form-control"></textarea>
						<input id="digest" type="hidden" readonly>
					</div>
				</div>
			</div>

			<?php if (in_array('terminal', $permissions) !== false) : ?>
				<div class="col-12">
					<div class="card">
						<div class="card-block">
							<div id="terminal">
								<div>
									<button type="button" class="btn btn-light float-right ml-1 clear" style="display: none;">Clear</button>
									<button type="button" class="btn btn-light float-right ml-1 copy" style="display: none;">Copy to clipboard</button>
									<button type="button" class="btn btn-light float-right ml-1 fullscreen" style="display: none;">Full Screen</button>
									<span class="toggle" data-toggle="collapse" data-target="#prompt">Terminal</span>
									<div style="clear:both"></div>
								</div>
								<div id="prompt" class="collapse">
									<pre></pre>
									<input name="command" type="text" value="" class="command" autocomplete="off">
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>

		</div>

	</div>

	<div class="alert"></div>

	<form method="post">
		<input name="action" type="hidden" value="upload-file">
		<input name="destination" type="hidden" value="">

		<div class="modal" id="uploadFileModal">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Upload File</h4>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
					</div>
					<div class="modal-body">
						<div>
							<input name="uploadfile[]" type="file" value="" multiple>
						</div>
						<?php

						if (function_exists('ini_get')) {
							$sizes = [
								ini_get('post_max_size'),
								ini_get('upload_max_filesize')
							];

							$max_size = max($sizes);

							echo '<small class="text-muted">Maximum file size: ' . $max_size . '</small>';
						}

						?>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-success" data-dismiss="modal">Upload</button>
					</div>
				</div>
			</div>
		</div>
	</form>
	
	

	