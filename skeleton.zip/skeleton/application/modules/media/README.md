# CodeIgniter Skeleton - Media Manage

This module allows you to manage media files on your CodeIgniter Skeleton application.
