<style>
.context-menu-active{}

#reader{float: left;width: 90%;margin-bottom: 150px;}
#wrapper {
        width: 480px;
        margin: 0 auto 0 4px;
        padding: 15px 0px;
    }

    .comment_box {
        
        list-style: none;
        background: none repeat scroll 0 0 #F6F6F6;
        float: left;
        margin-bottom: 20px;
        padding: 5px;
        box-sizing: content-box;
        border: 1px solid #CCCCCC;
        width: 100%;
        background-color: white;
        -webkit-box-shadow: -10px 0px 13px -7px #000000, 10px 0px 13px -7px #000000, 5px 5px 15px 5px rgba(0,0,0,0); 
box-shadow: -10px 0px 13px -7px #000000, 10px 0px 13px -7px #000000, 5px 5px 15px 5px rgba(0,0,0,0);

    }

    .aut {
        font-weight: bold;
    }

    .timestamp {
        font-size: 85%;
        float: right;
    }


    #comment_body {
        display: block;
        width: 100%;
        height: 150px;
    }

    .round_circle{
        background: lightblue;
        border-radius: 50%;
        width: 50px;
        height: 50px;
        vertical-align: middle;
        font-size: 10x;
  color: #fff;
  line-height: 50px;
  text-align: center;

    }	
</style>
