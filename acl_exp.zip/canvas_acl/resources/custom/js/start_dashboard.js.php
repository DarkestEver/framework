<script type="text/javascript">
	 $('.campaign_folder').click(function(){
             window.open('<?php echo site_url() ;?>' + 'campaign/index/'+  $(this).data("campaign_id") , '_self'); ;            
        });
</script>