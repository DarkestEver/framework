<script type="text/javascript">
	 $( document ).ready(function() {
        $(".editkey").editable("<?php echo site_url().'settings/ajax_custom_key_update/'; ?>",{
            width:'450px'
        });
    }); 
</script>