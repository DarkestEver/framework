<script type="text/javascript">
$('.campaign_folder').click(function(){
        selected_campaign = $(this).data("campaign_id");
        window.location.href = '<?php echo site_url()."repository/index/"?>' + selected_campaign;
});

$(document).on('click', ".open_model_new", function() {
       $('#model_new').appendTo("body").modal(); 
});
</script>
