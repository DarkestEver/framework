<script>
  $( function() {
    $( "#accordion" ).accordion({
      collapsible: true,
      heightStyle: "content"
    });
  } );


var output;
$(document).ready(function() {
   
    $(".draggable").draggable({
      opacity: 0.7, 
      revert: "invalid", // when not dropped, the item will revert back to its initial position
      containment: "document",
      helper: "clone",
      cursor: "move",
      cursorAt: { bottom: 0 }
        //scroll: true,
        //scrollSensitivity: 100
    });
    $( "ul, li" ).disableSelection();
    $(".droppable").droppable({
        drop: function (event, ui) {
            if ( (typeof ui.draggable.attr("id") !== 'undefined' ) && (typeof ui.draggable.data("module") !== 'undefined' )){
                //var emd_id = $('#emd_id').val();
                //var campaign_id = $('#campaign_id').val();
                var dragged_mod = ui.draggable.data("module");
               append_new_module( dragged_mod,999);
            }
        }
    });

    $('.draggable').on('click', function(event){
        //var emd_id = $('#emd_id').val();
        //var campaign_id = $('#campaign_id').val();
        var dragged_mod = $(this).data("module");
        append_new_module( dragged_mod,88);
    });

    function append_new_module(dragged_mod,li_new_id ) {
        var new_mod = ' li.' + dragged_mod;
        var new_module_added = $('#moduleshid' + new_mod ).clone(true);
        new_module_added.attr("id", li_new_id);
        $("html, body").animate({ scrollTop: $(document).height() }, 1500);
        $('.droppable').append(new_module_added);
        $("#" + li_new_id).append('<div   style="right: 25px;position: absolute;top:0px; color:#d43f3a" class="delete_li" data-deleteli="'+li_new_id+'"><i class="fas fa-times"></i></div>' );
        $("#" + li_new_id).append('<div class="addvariation" style="left: 0;right: auto;position: absolute;top:10px"><button type="button" class="btn btn-primary btn-sm"   data-variation="'+li_new_id+'"><i class="fab fa-buffer"></i></button></div>' );
        
    }

  

    $( ".droppable" ).sortable({
        revert: "invalid",
    });


});





</script>