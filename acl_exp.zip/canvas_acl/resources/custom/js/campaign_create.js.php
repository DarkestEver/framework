<script type="text/javascript">
	

$(function() {
    $("#categoryName").change(function() {
        if ( $('option:selected', this).text() == "DAX" )
        {
        	 $('#div_wheel').show();
        	 $("#dropdown_wheel").val();
        }
        else
        {
        	$('#div_wheel').hide();
        	$("#wheel").val('NA');
        }
    });
});


$("#dropdown_wheel").change(function() {
      $("#wheel").val($('option:selected', this).text());
});

$(document).ready(function() {
	$("#dropdown_wheel").val();
	if ( $('#categoryName').val() == "DAX" )
        {
        	 $('#div_wheel').show();
        	 $("#dropdown_wheel").val();
        }
        else
        {
        	$('#div_wheel').hide();
        	$("#wheel").val('NA');
        }


    $("#submit").click(function(e) {
       if ($('#emailname').val() == ""  || $('#categoryName').val()  == ""  || $('#vertical').val() == "" )
       {
            alert_message('Please provide value', "warning");
            e.preventDefault();
            return false;
       }
       if ($('#dropdown_wheel').val() == ""  && $('#categoryName').val()  == "DAX" )
       {
            alert_message('Please provide wheel info', "warning");
            e.preventDefault();
            return false;
       }
    });
});

</script>