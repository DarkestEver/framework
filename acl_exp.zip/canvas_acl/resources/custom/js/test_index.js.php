<script>
$(document).ready(function(){

	
var element = $("#moduleshid"); // global variable
var getCanvas; // global variable
 
    $("#publishTemplates").on('click', function () {
    	$("#moduleshid").style.opacity = "0";
    	$("#previewImage").style.opacity = "0";
         html2canvas(element, {
         onrendered: function (canvas) {

                $("#previewImage").append(canvas);
                getCanvas = canvas;
                var imgageData = getCanvas.toDataURL("image/png");
                var newData = imgageData.replace(/^data:image\/png;base64,/, "");
                $.post("upload",
			    {
			     data: newData
			    });
             }
         });
    });
});

</script>