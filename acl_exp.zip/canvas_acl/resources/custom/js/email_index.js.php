<script type="text/javascript">
    $(document).ready(function() {
        var dataTable = $('#dataTable').DataTable({
            'processing': true,
            'serverSide': true,
            'serverMethod': 'post',
            'searching': false, // Remove default Search Control
            'ajax': {
                'url':'../email/search_email',
                'data': function(data) {
                    // Read values
                    data.keyword = $('#keyword').val();
                }
            },
            'columns': [
                { data: 'campaign_name' },
                { data: 'email_name' },
                { data: 'category_name' },
                { data: 'vertical_name' },
                { data: 'wheels' },
                { data: 'createddate' },
                { data: 'status' },
                { data: 'id' }
            ],
            'columnDefs': [
                {
                    'targets': 0,
                    render: function (data, type, row, meta) {
                        return "<a href='<?php echo base_url()?>campaign/view/" + row["campaign_id"] + "' data-toggle='tooltip' title='" + row["campaign_name"] + "'>" + row["campaign_name"] + "</a>";
                    }
                },
                {
                    'targets': 1,
                    render: function (data, type, row, meta) {
                        return "<a href='<?php echo base_url()?>email/view/" + row["campaign_id"] + "/" + row["id"] + "' data-toggle='tooltip' title='" + row["email_name"] + "'>" + row["email_name"] + "</a>";
                    }
                },
                {
                    'targets': 6,
                    render: function (data, type, row, meta) {
                        return 'TBA';
                    }
                },
                {
                    'targets': 7,
                    render: function (data, type, row, meta) {
                        return "<a class='btn btn-info' href='<?php echo base_url()?>email/apicalls/" + row["id"] + "' data-toggle='tooltip' title='API'><i class='fas fa-plus'></i></a><a class='btn btn-success' data-toggle='tooltip' href='<?php echo base_url()?>email/viewLocalizedInputLinks/" + row["id"] + "' title='Link'><i class='fas fa-link'></i></a><a class='btn btn-warning' href='<?php echo base_url()?>email/get_ampscript2/" + row["id"] + "' data-toggle='tooltip' title='Code'><i class='fas fa-code'></i></a><a class='btn btn-danger' href='<?php echo base_url()?>email/export_translation_de/" + row["id"] + "' data-toggle='tooltip' title='Download DE'><i class='fas fa-download'></i></a>"
                    }
                }
            ]
        });

        $('#keyword').click(function() {
            dataTable.draw();
        });
    });
</script>
