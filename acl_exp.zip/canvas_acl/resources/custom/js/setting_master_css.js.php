<script type="text/javascript">
	 $( document ).ready(function() {
        $(".editkey").editable("<?php echo site_url().'settings/ajax_master_css/'; ?>",{
            width:'450px'
        });

        
    }); 

	$('#add_new').click(function(e){
    		 $('#new_css_model').appendTo("body").modal();
    });

	$('#btn_new_css_model').click(function(e){
    	 ajax_new();
    });

	 function ajax_new() {
	 	var css_name = $("#input_new_name").val();
	 	if (css_name == "") {

	 	alert_message("CSS Name is empty","warning");
	 	return false;
	 	}
	 	var inline_css = $("#input_new_css").val();
	 	if (inline_css == "") {
	 	
	 	alert_message("CSS is empty","warning");
	 	return false;	
	 	}
	    $.ajax({
	        type: "POST",
	        cache:false,
	        dataType: "text",
	        url: "<?php echo site_url();?>settings/ajax_master_css_add",
	        data:{
	            'data': {'css_name': css_name, 'inline_css': inline_css}
	        },
	        success: function (data) {
	            if (data == false)
	            {
	                alert_message( "css name already exists", "info");

	            }
	            else
	            {
	                 location.reload();
	            }
	        },
	        error: function () {
	            alert('Error');
	        }
	    });
	}
</script>