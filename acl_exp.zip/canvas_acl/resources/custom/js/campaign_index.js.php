<script type="text/javascript">

    $(document).ready(function() {   
        //$('.campaign_folder').unbind('click');
        select_campaign_auto();
        $("#comment_btn_toggle").click(function(){
            $(".ui-theme-settings").toggleClass("settings-open");
            $("#comment_btn_toggle").toggleClass("fas");
        });


        
    });
 $('.campaign_folder').click(function(){
             window.open('<?php echo site_url() ;?>' + 'campaign/index/'+  $(this).data("campaign_id") , '_self'); ;            
        });
function select_campaign_auto()
{
    var selected_campaign ="";
    $('.campaign_folder').unbind('click');
    $('.campaign_folder').click(function(){
        selected_campaign = $(this).data("campaign_id");
        //console.log(selected_campaign);
        $('#campaign_id').val(selected_campaign);
        $("#tree").find("a").css("color","");
        $(this).css("color","red");
        $("#campaing_name_selected_from_menu").text($(this).text());
        get_campaign_list(selected_campaign);
    });
}



function get_campaign_list(campaign_id="")
{
    var access_group = "";
    var campaign_id = $('#campaign_id').val();
    var dataTable = $('#dataTable').DataTable({
          
            'processing': true,
            'serverSide': true,
            'serverMethod': 'post',
            'searching': false, // Remove default Search Control
            searching: false, paging: false, info: false, "destroy": true,
            'ajax': {
                'url':'<?php echo base_url()?>Campaign/ajax_campaign_selected/' + campaign_id  ,
                "type": "POST",
                'data': function(data){
                }
            },
            'columns': [
               { data: 'email_name' , title:"Email Name"},
                { data: 'country_code' , title:"Country"},
                { data: 'language_code' , title:"Language"},
                { data: 'createddate', title:"Date" },
                { data: 'status' , title:"Status"},
                { data: 'id' , title:""}
            ],
            'columnDefs': [
                {
                    'targets': 0,
                    render: function (data, type, row, meta) {
                        return  "<input class='hidden_row_id' type='hidden'   data-campaign_id='" + row['campaign_id'] + "' data-edm_id ='" + row['id'] + "' data-language_code='" + row['language_code'] + "' data-country_code ='" + row['country_code'] + "'  data-email_name = '" + row['email_name']+"'   /> " 
                      + "<a  class='has_no_access LCM CT' data-toggle='tooltip' title='Edit'  href='<?php echo site_url();?>" + 'email/edit/'+ row['campaign_id']  + "/" + row['id'] +"/" + row['country_code'] +   "/" +  row['language_code']  + "'><i class='fas fa-edit'></i></a>"
                       
                        + row['email_name'] ;
                    }
                },
                
                {
                    'targets': 4,
                    render: function (data, type, row, meta) {

                        if (row['localized_status']==1) {
                            return '<i class="fas fa-lock"></i>';
                        } 
                        else {
                            return '<i class="fas fa-unlock"></i>';
                        }
                    }
                },
                {   "visible": false,
                    'targets': 5
                }
            ],

            "order": [[ 5, 'asc' ]],
            "orderFixed": [ 5, 'asc' ],
            "drawCallback": function ( settings ) {
                var api = this.api();
                var rows = api.rows( {page:'current'} ).nodes();
                var last=null;
     
                api.column(5, {page:'current'} ).data().each( function ( group, i ) {
                    if ( last !== group ) {
                        var rowData = api.row(i).data();
                        var email_status_icon = "";
                        if (rowData["status"] == 2)
                        {
                            email_status_icon = '<i class="fas fa-check-double" style="color:#004085"  data-toggle="tooltip" title="Template Published" > </i>';
                        }
                        else if (rowData["status"] == 1)
                        {
                            email_status_icon ='<i class="fas fa-save"  style="color:#155724" data-toggle="tooltip" title="Template Saved"></i>';

                        }
                        else
                        {
                            email_status_icon = '<i class="fas fa-edit"  style="color:#856404" data-toggle="tooltip" title="Template Editable"> </i>';
                        }
                        $(rows).eq( i ).before(
                            '<tr><td colspan="10" class="context-menu-active"> </td></tr><tr class="context-menu-active"><td colspan="5">' + rowData["email_name"] +'<span style=""> <a class="has_no_access LCM"   href ="<?php echo base_url(); ?>template/index/'+rowData["campaign_id"]+'/' + rowData["id"]+'" ><b>'+ email_status_icon +'</b></a>  <a class="has_no_access LCM" href ="<?php echo base_url(); ?>email/create/'+rowData["campaign_id"]+'/' + rowData["id"]+'" data-toggle="tooltip" title="Add Language"><i class="fas fa-sign-language"></i></a> <a class="has_no_access LCM copyemail" href="#" data-email_name="'+rowData["email_name"]+'" data-edm_id="'+rowData["id"]+'"><i class="far fa-clone"></i></a>   <a class="has_no_access OPS" href ="<?php echo base_url(); ?>sfmc/index/'+rowData["campaign_id"]+'/' + rowData["id"]+'" data-toggle="tooltip" title="Salesforce API"><i class="fab fa-salesforce"></i></a></td><span></tr>'
                        );
                        last = group;
                    }
                } );
            }
            });
}

$(function() {
    $.contextMenu({
            selector: '#dataTable tr.odd td,#dataTable tr.even td', 
            callback: function(key, options) {
                var td = options.$trigger;
                var tr = td.parent("tr")
                var dd = tr.find("td:first-child").find( ".hidden_row_id");
                var edm_id = dd.data('edm_id');
                var selected_edm_name = dd.data('email_name');
                var campaign_id = dd.data('campaign_id');
                var edm_id = dd.data('edm_id');
                var country_code = dd.data('country_code');
                var language_code = dd.data('language_code');
                $("#selected_edm_id").val(edm_id);
                $("#selected_campaign_id").val(campaign_id);
                $("#selected_email_name").val(selected_edm_name);

                switch(key) {
                  case "edit": alert_message("Feature is in development", "info");
                    break;
                  case "copy": 

                    alert_message("Feature is in development", "info");
                    break;
                  case "delete": alert_message("Feature is in development", "info");
                    break;
                  case "input":
                    window.open('<?php echo site_url() ;?>' + 'email/edit/'+ campaign_id + "/" + edm_id  +"/" + country_code + "/" + language_code , '_self'); 
                    break;
                  case "preview_desktop":
                    window.open('<?php echo site_url() ;?>' + 'email/desktopPreview/'+ campaign_id + "/" + edm_id  +"/" + country_code + "/" + language_code , '_self'); 
                    break;
                  case "preview_mobile":
                    window.open('<?php echo site_url() ;?>' + 'email/preview/'+ campaign_id + "/" + edm_id  +"/" + country_code + "/" + language_code , '_self'); 
                    break;
                }
                
            },
            items: {
                "edit": {name: "Edit", icon: "edit"},
                "copy": {name: "Copy", icon: "copy"},
                "delete": {name: "Delete", icon: "delete"},
                "input": {name: "Visual Input", icon: "delete"},
                "sep1": "---------",
                "preview_desktop": {name: "Preview Desktop", icon: "edit"},
                "preview_mobile": {name: "Preview Mobile", icon: "copy"},
            }
        });

        
});


$(document).on('click', "a.copyemail", function() {
       $('#copyemail_model').appendTo("body").modal(); 
       var copy_edm_id =  $(this).data('edm_id');
       var copy_email_name =  $(this).data('email_name');
       $('#selected_edm_id').val(copy_edm_id);    
});

$(document).on('click', "#btn_copy_new_email_name", function() {
       var campaign_id = $("#campaign_id").val();  
       var edm_id = $("#selected_edm_id").val();  
       var new_email_mail = $("#input_copy_new_email_name").val();
       ajax_copy_email(new_email_mail, campaign_id, edm_id);
});

function ajax_copy_email(new_email_mail, campaign_id, copy_edm_id) {
    $.ajax({
        type: "POST",
        cache:false,
        dataType: "text",
        url: "<?php echo site_url();?>email/create_email_copy",
        data:{
            'data': {'campaign_id': campaign_id, 'edm_id': copy_edm_id, 'new_email_mail':new_email_mail}
        },
        success: function (data) {
            console.log(data);
            if (data == false)
            {
                alert_message( "Email name already exists", "info");

            }
            else
            {
                 get_campaign_list(campaign_id);
            }
        },
        error: function () {
            alert('Error');
        }
    });
}
//$('#copyemail_model').on('shown.bs.modal', function () {
    
//});

$(function() {
    $.contextMenu({
            selector: '.create_new_folder', 
            callback: function(key, options) {
                var vfolder_id = options.$trigger;
                folder_id = vfolder_id.data('folder_id');
                $("#hidden_folder_id").val(folder_id);     
                switch(key) {
                  case "add":
                    $('#newFolder').appendTo("body").modal(); 
                    break;
                  case "edit":
                    $('#editFolder').appendTo("body").modal(); 
                     $("#input_folder_id_edit").val(vfolder_id.data('folder_name'));
                    break;
                  case "delete":
                    break;
                  case "cadd":
                    $('#newCampaing').appendTo("body").modal();
                    break;
                }
                
            },
            items: {
                "add": {name: "Add Folder", icon: "add"},
                "edit": {name: "Edit", icon: "edit"},
                "cadd": {name: "Campaign Add", icon: "copy"},
                "delete": {name: "Delete", icon: "delete"},

                
            }
        });       
});

$(function() {
    $.contextMenu({
            selector: '.campaign_folder', 
            callback: function(key, options) {
                var vfolder_id = options.$trigger;

                campaign_id = vfolder_id.data('campaign_id');
                $("#hidden_folder_id").val(campaign_id);
                
               // console.log(campaign_id);
                switch(key) {
                  case "add":
                    $('#newEmail').appendTo("body").modal();
                    break;
                  case "edit":
                    alert_message("Feature is in development", "info");
                    break;
                  case "delete":
                    alert_message("Feature is in development", "info");
                    break;
                }
                
            },
            items: {
                "add": {name: "New Email", icon: "add"},
                "edit": {name: "Edit", icon: "edit"},
                "delete": {name: "Delete", icon: "copy"},               
            }
        });       
});

function ajax_add_new_fodlder(parent_id,f_name) {
    $.ajax({
        type: "POST",
        cache:false,
        dataType: "text",
        url: "<?php echo site_url();?>campaign/newfoder",
        data:{
            'data': {'parent_id': parent_id, 'f_name': f_name}
        },
        success: function (data) {
            if (data == false)
            {
                alert_message( "folder name already exists", "info");
            }
            else
            {
               var parent_folder = $('*[data-folder_id="'+parent_id+'"]');
               var add_new_folder_html = '<ul style="" ><li><span class="explr-plus explr-minus" title="click to expand/collapse"></span><span class="explr-line"></span><a data-folder_id="'+data+'" class="icon-folder create_new_folder" href="#">'+f_name+'</a><ul style=""></ul></li></ul>';
               parent_folder.append(add_new_folder_html);

            }
        },
        error: function () {
            alert('Error');
        }
    });
}



$('#btn_new_folder').click(function() {

    if ($("#input_folder_id").val() == "")
    {
        alert_message("info","Please provide fodler name");
    }   
    else
    {
        var parent_id =  $("#hidden_folder_id").val();
        var f_name = $("#input_folder_id").val();
        ajax_add_new_fodlder(parent_id,f_name);
    }
          
})


function ajax_update_folder(id,f_name) {
    $.ajax({
        type: "POST",
        cache:false,
        dataType: "text",
        url: "<?php echo site_url();?>campaign/ajax_update_folder",
        data:{
            'data': {'id': id, 'f_name': f_name}
        },
        success: function (data) {
            if (data == false)
            {
                alert_message( "folder name already exists", "info");
            }
            else
            {
              $('*[data-folder_id="'+id+'"]').text (f_name);
            }
        },
        error: function () {
            alert('Error');
        }
    });
}

$('#btn_edit_folder').click(function() {

    if ($("#input_folder_id_edit").val() == "")
    {
        alert_message("info","Please provide fodler name");
    }   
    else
    {
        var id = $("#hidden_folder_id").val(); 
        var f_name =  $("#input_folder_id_edit").val();
        ajax_update_folder(id,f_name);
    }
          
})


$('#btn_campaing_name_new').click(function() {

    if ($("#campaing_name_new").val() == "")
    {
        alert_message("info","Please provide Campaign name");
    }   
    else
    {
        var folder_id = $("#hidden_folder_id").val(); 
        var campaing_name =  $("#campaing_name_new").val();
        $.ajax({
            type: "POST",
            cache:false,
            dataType: "text",
            url: "<?php echo site_url();?>campaign/ajax_createCampaignwithinfolder",
            data:{
                'data': {'folder_id': folder_id, 'campaing_name': campaing_name}
            },
            success: function (data) {
                if (data == false)
                {
                    alert_message( "Campaign name already exists", "info");
                }
                else
                {
                  var parent_folder = $('*[data-folder_id="'+folder_id+'"]').parent('li').find('ul');
                  parent_folder.css("display", "block");
                  var add_new_folder_html = '<li class="icon-text"><span class="explr-line"></span><a class="icon-text campaign_folder" data-campaign_id="'+data+'" href="#">'+campaing_name+'</a></li>';
                  parent_folder.append(add_new_folder_html);
                  select_campaign_auto();
                }
            },
            error: function () {
                alert('Error');
            }
        });
    }
          
})




$('#newEmail').on('shown.bs.modal', function () {
  $('#btn_save_new_email').click(function(e){
    if ($('#emailname').val()=="") {
        alert_message('Please enter email name.','warning');
        //e.preventDefault();
        return false;
    }
    else{
        var options = $('#marketName > option:selected');
         if(options.length == 0){
             alert_message('Please select countries','warning');
            // e.preventDefault();
             return false;
         }
    }


    var campaign_id = $("#hidden_folder_id").val(); 
    var emailname =  $("#emailname").val();
    var countries_code =  $("#marketName").val();
    $.ajax({
        type: "POST",
        cache:false,
        dataType: "text",
        url: "<?php echo site_url();?>campaign/ajax_add_new_email",
        data:{
            'data': {'campaign_id': campaign_id, 'emailname': emailname, 'countries_code':countries_code }
        },
        success: function (data) {
            if (data == false)
            {
                alert_message( "Email name already exists", "info");
            }
            else
            {
               get_campaign_list(campaign_id);
            }
        },
        error: function () {
            alert('Error');
        }
    });

});
})



<?php if (!empty($campaign_id_url)) {  ?>
       $('#campaign_id').val(<?php echo $campaign_id_url; ?>) ; 
       $("a[data-campaign_id='<?php echo $campaign_id_url; ?>']").css("color","red");;
       get_campaign_list( );
<?php } ?>





$(function () {
        $("a.reply").click(function () {
            var id = $(this).attr("id");
            $("#parent_id").attr("value", id);
            $("#name").focus();
        });
    });

</script>


