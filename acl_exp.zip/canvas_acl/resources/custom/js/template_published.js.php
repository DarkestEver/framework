<script>


function ajax_updateStatusTemplate(status) {
    $.ajax({
        type: "POST",
        cache:false,
        dataType: "text",
        url: "<?php echo site_url();?>template/updateStatusTemplate",
        data:{
            'data': {'campaign_id': <?php echo $campaign_id ;?>, 'edm_id': <?php echo $emd_id ;?>, 'status':  status}
        },
        success: function (data) {
            window.location.href = "<?php echo site_url().'template/index/'.$campaign_id.'/'.$emd_id ; ?>" ;
        },
        error: function () {
            alert('Error');
        }
    });
}

$(document).ready(function() {


    $("#editTemplates").click(function() {
        ajax_updateStatusTemplate(0);
    });

    $(".delete_li, .addvariation").hide();
});



</script>