<script type="text/javascript">
    $(document).ready(function() {   
    });


    $('#btn_confirm_folder_sync').click(function(e){
    	 $('#model_folder_sync').appendTo("body").modal();
    });
    $('#model_folder_sync').on('shown.bs.modal', function () {
 		
 		$('#folder_sync_api_spinner').hide();
 		$('#folder_sync_confirm_text').show();
 		$('#folder_sync_confirm_text').text('Please Confirm.');
 		$('#btn_folder_sync').show();
    });
    $('#btn_folder_sync').click(function(e){
		 $('#btn_folder_sync').hide();
		 $('#folder_sync_api_spinner').show();
 		 $('#folder_sync_confirm_text').hide();

 		 $.ajax({
		        type: "POST",
		        cache:false,
		        dataType: "text",
		        url: "<?php echo site_url().'sfmc/ajax_folder_hierarchy/'.$campaign_id?>",
		        success: function (data) {
		            	 $('#btn_folder_sync').hide();
						 $('#folder_sync_api_spinner').hide();
				 		 $('#folder_sync_confirm_text').show();
				 		 $('#folder_sync_confirm_text').text('Sync Successfully.');
		            
		        },
		        error: function () {
		            alert('Error');
		        }
		    });
    });


    $('#btn_confirm_create_campaign').click(function(e){
    	 $('#model_create_campaign').appendTo("body").modal();
    });
	$('#model_create_campaign').on('shown.bs.modal', function () {
 		$('#create_campaign_api_spinner').hide();
 		$('#create_campaign_confirm_text').show();
 		$('#create_campaign_confirm_text').text('Please Confirm.');
 		$('#btn_create_campaign').show();
    });
	$('#btn_create_campaign').click(function(e){
		 $('#btn_create_campaign').hide();
		 $('#create_campaign_api_spinner').show();
 		 $('#create_campaign_confirm_text').hide();

 		 $.ajax({
		        type: "POST",
		        cache:false,
		        dataType: "text",
		        url: "<?php echo site_url().'sfmc/ajax_create_campaign/'.$campaign_id?>",
		        success: function (data) {
		         
		            	 $('#btn_create_campaign').hide();
						 $('#create_campaign_api_spinner').hide();
				 		 $('#create_campaign_confirm_text').show();
				 		 $('#create_campaign_confirm_text').text('Created Successfully.');
		            
		        },
		        error: function () {
		            alert('Error');
		        }
		    });
    });


    $('#btn_confirm_transfer').click(function(e){
    	 $('#model_api_upload_de').appendTo("body").modal();
    });

    
    $('#btn_api_sfmc_campaign_setting').click(function(e){
    	 $('#model_api_sfmc_campaign_setting').appendTo("body").modal();
    });

    $('#model_api_upload_de').on('shown.bs.modal', function () {
 		$('#upload_api_spinner').hide();
 		$('#confirm_text').show();
 		$('#confirm_text').text('Please Confirm.');
 		$('#btn_api_de_confirm_upload').show();
    });

    $('#btn_api_de_confirm_upload').click(function(e){
		 $('#btn_api_de_confirm_upload').hide();
		 $('#upload_api_spinner').show();
 		 $('#confirm_text').hide();

 		 $.ajax({
		        type: "POST",
		        cache:false,
		        dataType: "text",
		        url: "<?php echo site_url().'sfmc/upload_de_to_sfmc/'.$campaign_id. '/'.$edm_id ?>",
		        success: function (data) {
		         
		            	 $('#btn_api_de_confirm_upload').hide();
						 $('#upload_api_spinner').hide();
				 		 $('#confirm_text').show();
				 		 $('#confirm_text').text('Uploaded Successfully.');
		            
		        },
		        error: function () {
		            alert('Error');
		        }
		    });
    });

    
    $('#btn__image_confirm_transfer').click(function(e){
    	 $('#model_api_upload_image').appendTo("body").modal();
    });

    $('#model_api_upload_image').on('shown.bs.modal', function () {
 		$('#image_upload_api_spinner').hide();
 		$('#image_confirm_text').show();
 		$('#image_confirm_text').text('Please Confirm.');
 		$('#image_btn_api_de_confirm_upload').show();
    });

    $('#image_btn_api_de_confirm_upload').click(function(e){
		 $('#image_btn_api_de_confirm_upload').hide();
		 $('#image_upload_api_spinner').show();
 		 $('#image_confirm_text').hide();

 		 $.ajax({
		        type: "POST",
		        cache:false,
		        dataType: "text",
		        url: "<?php echo site_url().'sfmc/ajax_upload_image/'.$campaign_id. '/'.$edm_id ?>",
		        success: function (data) {
		            
		            	 $('#image_btn_api_de_confirm_upload').hide();
						 $('#image_upload_api_spinner').hide();
				 		 $('#image_confirm_text').show();
				 		 $('#image_confirm_text').text('Uploaded Successfully.');
				 		 $('#image_count').text(data);
		            
		        },
		        error: function () {
		            alert('Error');
		        }
		    });
    });

</script>