<script type="text/javascript">

    var language_code = $('#hidden_language').val();
    var country_code = $('#hidden_country').val();
    var campaign_id = $('#hidden_campaign_id').val();
    var edm_id =  $('#hidden_emd_id').val();
    var edm_status_id = $("#edm_status_id").val();

    function ajax_updateStatusLocalizedEDM(status) {

        $.ajax({
            type: "POST",
            cache:false,
            dataType: "text",
            url: "<?php echo site_url();?>email/ajax_updateStatusLocalizedEDM ",
            data:{
                'data': {'id': <?php echo $edm_status_id ;?>, 'status':  status }
            },
            success: function (data) {
                window.location.href = "<?php echo site_url().'email/edit/'.$campaign_id.'/'.$edm_id.'/'.$country_code.'/'.$language_code ; ?>" ;
            },
            error: function () {
                alert('Error');
            }
        });
    }

    $('#edm_unlock').click(function() {
        ajax_updateStatusLocalizedEDM(0);  
        $('#newEmail').modal();
    })

</script>