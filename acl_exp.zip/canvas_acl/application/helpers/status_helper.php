<?php

function edm_status($value='')
{
	if ($value==0)
	{
		return 'Template Pending';
	}
	elseif ($value==1) {
		return 'Template Created';
	}
	elseif ($value==2) {
		return 'Template Implemented';
	}
}

function edm_status_class($value='')
{
	if ($value==0)
	{
		return 'warning';
	}
	elseif ($value==1) {
		return 'info';
	}
	elseif ($value==2) {
		return 'success';
	}
}

function edm_input_status($value='')
{
	if ($value==0)
	{
		return 'Input Pending';
	}
	elseif ($value==1) {
		return 'Input Completed';
	}
}

function edm_input_col_name($value='')
{
	if ($value=="title")
	{
		return $value;
	}
	elseif ($value=="href") {
		return $value;
	}
	elseif ($value=="alias") {
		return $value;
	}
	elseif ($value=="link") {
		return $value;
	}
	elseif ($value=="alt") {
		return "alias";
	}
	elseif ($value=="src") {
		return "href";
	}
}

function api_folder_type($value='')
{
	switch ($value) {
		case '0':
			return "asset";
			break;
		case '1':
			return "dataextension";
			break;
		default:
			# code...
			break;
	}
}

?>