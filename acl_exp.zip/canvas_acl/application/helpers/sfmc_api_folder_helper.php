<?php

global $a;
function index1($folder_id)
 {  
 	$CI = get_instance();
 	$a = array();
	//$a[] = array("parent_id"=> $folder_id );

	$CI->load->model('Api_credentials_model');
	$CI->load->model("Folders_model");
    $api_folder = $CI->Api_credentials_model->get_appfolders_api_by_fid($folder_id);
    if ($api_folder[0]["fid"] != $api_folder[0]["parent_id"] )
    	$a[] = array($api_folder[0]["fid"] => $api_folder[0]["parent_id"]  );
	if ($api_folder[0]["folder_id"] != "" ) {
		return $a;
	}
	else{
		$parent_id = $api_folder[0]["parent_id"];
		$parent_id = $CI->Api_credentials_model->get_appfolders_api_by_fid($parent_id)[0]["parent_id"];
		if ($api_folder[0]["fid"] != $api_folder[0]["parent_id"] )
    		$a[] = array($api_folder[0]["fid"] => $api_folder[0]["parent_id"]  );
		$a =array_merge($a, index1($parent_id));
	}
    return $a;
}

function getFoldersNotInSFMC($folder_id)
{
	
	$f_array = array();
	$a= index1($folder_id);
	foreach ($a as $key => $value) {
		foreach ($value as $key1 => $value1) {
			$f_array[] = $key1;
			$f_array[] = $value1;
		}
		
	}
	return array_reverse( array_unique( $f_array));
}
?>