<?php 

function apply_master_css($html='')
{
	$CI = get_instance();
	$CI->load->model("Master_css_model");
	$css = $CI->Master_css_model->getAll();

	foreach ($css as $key => $value) {
		  $css_name ="%%=TreatAsContent(v(@". $value["css_name"]."))=%%";
		  $html = str_replace($css_name, $value["inline_css"], $html);
	}
	return $html;
}


?>