<?php
function create_conditions($condition,$conditional_key,$values)
{

	$str = "";
	$str.= "if (" ;
	switch ($condition ) {
		case '==':
			$str.= 'AttributeValue("'.$conditional_key .'")' ;
			$str.= $condition;
			$str.= '"'.$values .'"';
			break;		
		case '>':
			$str.= 'AttributeValue("'.$conditional_key .'")' ;
			$str.= $condition;
			$str.= $values;
			break;
		case '<':
			$str.= 'AttributeValue("'.$conditional_key .'")' ;
			$str.= $condition;
			$str.= $values;
			break;
		case '>=':
			$str.= 'AttributeValue("'.$conditional_key .'")' ;
			$str.= $condition;
			$str.= $values;
			break;
		case 'and':
			$i = 1;
			$values = explode("|",$values);
			foreach ($values as $key => $value) {
				if ($value != "") {
					$str.= 'AttributeValue("'.$conditional_key .'")' ;
					$str.= ' == ';
					$str.= '"'.$value .'"';
					if (sizeof($values) != $i  ) {
						$str.= "  and ";
					}
				}			
				$i++;
			}
			$str = rtrim($str, "  and ");
			break;
		case 'or':
			$i = 1;
			$values = explode("|",$values);
			foreach ($values as $key => $value) {
				$str.= 'AttributeValue("'.$conditional_key .'")' ;
				$str.= '==';
				$str.= '"'.$value .'"';
				if (sizeof($values) != $i ) {
					$str.= "  or ";
				}
				$i++;
			}
			$str = rtrim($str, "  or ");
			break;
	}

	$str.= ") then " ;
	return $str;
}

?>