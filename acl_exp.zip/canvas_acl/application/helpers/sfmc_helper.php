<?php 
use FuelSdk\ET_Client;
use FuelSdk\ET_Folder;
use FuelSdk\ET_DataExtension;


function get_dataextension_custom_key($campaign_id,$edm_id)
{
    $CI = get_instance();
    $CI->load->model('Edms_saved_inputs_model');
    $CI->load->model('Edm_model');
    $CI->load->model('Modules_model');

    $edm =  $CI->Edm_model->getEmailByID($campaign_id, $edm_id);
    $edm_name = $edm[0]['email_name'];
   // echo $edm_name; die;
    $subject =$CI->Edm_model-> getSubjectEDMDCountByID($campaign_id,$edm_id );
    $data =  $CI->Edms_saved_inputs_model->getSavedInputValuesCustomKey($campaign_id,$edm_id );
    $aaa = array();
    foreach ($data as $key => $value) {
        $item = [];
        $items["country_code"] = strtoupper($value['country_code']);
        $items["language_code"] = strtolower( $value['language_code']);
        $items["city_id"] = "all";
        $module_name = $value['module_name'];
        $module_type = $value['editable_type'];

        
        $key_name = substr($value['key_name'], strpos($value['key_name'],"_") + 1, strlen($value['key_name'])  - strpos($value['key_name'],"_"));
        $key_prefix = $edm_name.'_'.$value['variation_name'].'_'.$key_name.'_';
        if ($module_type == "cta") {
            $new_key = $CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'alias');
            $items["key_name"] =$key_prefix. $CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'alias');
            $items["value"] = $value['alias']; $aaa[] =  $items;
            $items["key_name"] =$key_prefix. $CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'href');
            $items["value"] = $value['href']; $aaa[] =  $items;
            $items["key_name"] = $key_prefix.$CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'title');
            $items["value"] = $value['title']; $aaa[] =  $items;
        }
        elseif ($module_type == "image_withoutlink") {
            $items["key_name"] =$key_prefix. $CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'alias');
            $items["value"] = $value['alias']; $aaa[] =  $items;
            $items["key_name"] = $key_prefix.$CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'href');
            $items["value"] = $value['href']; $aaa[] =  $items;
            $items["key_name"] =$key_prefix. $CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'title');
            $items["value"] = $value['title']; $aaa[] =  $items;
        }
        elseif ($module_type == "image_withlink") {
            $items["key_name"] = $key_prefix.$CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'link');
            $items["value"] = $value['link']; $aaa[] =  $items;
            $items["key_name"] =$key_prefix. $CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'alias');
            $items["value"] = $value['alias']; $aaa[] =  $items;
            $items["key_name"] =$key_prefix. $CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'href');
            $items["value"] = $value['href']; $aaa[] =  $items;
            $items["key_name"] = $key_prefix.$CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'title');
            $items["value"] = $value['title']; $aaa[] =  $items;
        }
        elseif ($module_type == "paragraph") {
            $items["key_name"] =$key_prefix. $CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'title');
            $items["value"] = $value['title']; $aaa[] =  $items;
        }
        elseif ($module_type == "heading") {
            $items["key_name"] =$key_prefix. $CI->Modules_model->get_custom_keys($value['module_id'],$key_name, 'title');
            $items["value"] = $value['title']; $aaa[] =  $items;
        }
    }

    foreach ($subject as $key => $value) {
        $item = [];
        $items["country_code"] = $value['country_code'];
        $items["language_code"] = $value['language_code'];
       // //$items["variation_id"] = '0';
        //$items["edm_id"] = $edm_id;
        //$items["campaign_id"] = $campaign_id;
        $items["key_name"] = "subject";
        $items["value"] = $value['subject']; $aaa[] =  $items;
        $items["key_name"] = "preheader";
        $items["value"] = $value['preheader']; $aaa[] =  $items;
    }
    return $aaa;

}
function get_dataextension_key($campaign_id,$edm_id)
{
		$CI = get_instance();
        $CI->load->model('Edms_saved_inputs_model');
        $CI->load->model('Edm_model');
        $data = $CI->Edms_saved_inputs_model->getSavedInputValues($campaign_id,$edm_id );
        $subject =$CI->Edm_model-> getSubjectEDMDCountByID($campaign_id,$edm_id );;
        $aaa = array();
        foreach ($data as $key => $value) {
            $item = [];
            $items["country_code"] = $value['country_code'];
            $items["language_code"] = $value['language_code'];
            $items["variation_id"] = $value['variation_id'];
            $items["edm_id"] = $value['edm_id'];
            $items["campaign_id"] = $value['campaign_id'];
            $module_type = $value['editable_type'];
            $key_prefix = $value['module_key'] ."_". $value['key_name'];
            if ($module_type == "cta") {
                $items["key_name"] = $key_prefix."_alias";
                $items["value"] = $value['alias']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_href";
                $items["value"] = $value['href']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_title";
                $items["value"] = $value['title']; $aaa[] =  $items;
            }
            elseif ($module_type == "image_withoutlink") {
                $items["key_name"] = $key_prefix."_alias";
                $items["value"] = $value['alias']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_href";
                $items["value"] = $value['href']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_title";
                $items["value"] = $value['title']; $aaa[] =  $items;
            }
            elseif ($module_type == "image_withlink") {
                $items["key_name"] = $key_prefix."_links";
                $items["value"] = $value['link']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_alias";
                $items["value"] = $value['alias']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_href";
                $items["value"] = $value['href']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_title";
                $items["value"] = $value['title']; $aaa[] =  $items;
            }
            elseif ($module_type == "paragraph") {
                $items["key_name"] = $key_prefix."_title";
                $items["value"] = $value['title']; $aaa[] =  $items;
            }
            elseif ($module_type == "heading") {
                $items["key_name"] = $key_prefix."_title";
                $items["value"] = $value['title']; $aaa[] =  $items;
            }
        }
        foreach ($subject as $key => $value) {
        	$item = [];
            $items["country_code"] = $value['country_code'];
            $items["language_code"] = $value['language_code'];
            $items["variation_id"] = '0';
            $items["edm_id"] = $edm_id;
            $items["campaign_id"] = $campaign_id;
            $items["key_name"] = "subject";
            $items["value"] = $value['subject']; $aaa[] =  $items;
            $items["key_name"] = "preheader";
            $items["value"] = $value['preheader']; $aaa[] =  $items;
        }
        return $aaa;
}

function SFMC_API_Exe($url_append, $fields_string, $flg, $token, $method)
{
	$token = getToken();

	$data_result =SFMC_API($url_append, $fields_string, $flg, $token, $method);
    
	if (isset(json_decode($data_result)->errorcode) && json_decode($data_result)->errorcode = "401") {
		$token = getToken("refresh");
        $data_result = SFMC_API($url_append, $fields_string, $flg, $token, $method);
        if (isset(json_decode($data_result)->errorcode) )
        {
        	return false;
        }
        else
        {
        	return $data_result;
        }
	}
	return $data_result;
}

function SFMC_API($url_append, $fields_string, $flg, $token, $method) {
        $ch = curl_init();
        $CI = get_instance();
        $credentials = $CI->Api_credentials_model->get_default();
        $url = "";
        if ($flg == 1) {
        	$url = $credentials['rest_url']. $url_append;
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: Bearer ' . $token));
            curl_setopt($ch, CURLOPT_HEADER, 0);
        }
        else
        {
        	$url = $credentials['auth_url'].'/v2/token' ;
        }
        curl_setopt($ch, CURLOPT_URL, $url);
        //curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $result = curl_exec($ch);
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);
        return $result;
}

function getToken($refresh='')
{		$CI = get_instance();
		$CI->load->model('Api_credentials_model');
		$credentials = $CI->Api_credentials_model->get_default();
        if (empty($credentials['last_token']) || $refresh =="refresh")
        {
        	$url = $credentials['auth_url'].'/v2/token';

	        $post = [
	            "grant_type" => "client_credentials",
	            "client_id" => $credentials['client_id'],
	            "client_secret" => $credentials['client_secret']
	        ];
            $result = SFMC_API($url, $post, 0, 1, 'POST');
	        $decode_result = json_decode($result);
	        $token = $decode_result->access_token;
	        $expire = $decode_result->expires_in;
	        $CI->Api_credentials_model->set_token($credentials['id'], $token);
        }
        else
        {
            $token = $credentials['last_token'];
        }
        return $token;
}

function et_ap_crendentials()
{
    $CI = get_instance();
    $CI->load->model('Api_credentials_model');
    $credentials = $CI->Api_credentials_model->get_default();
    return array(
                'appsignature' => 'none',
                'clientid' => $credentials['client_id'],
                'clientsecret' =>$credentials['client_secret'],
                'baseAuthUrl' => $credentials['auth_url'],
                'baseSoapUrl' =>$credentials['soap_url'],
                'baseUrl' => $credentials['rest_url'],
                 'accountId' => $credentials['account_id'],// 110006394,
                 'defaultwsdl' => 'https://webservice.exacttarget.com/etframework.wsdl',
                 'xmlloc' => FCPATH . '/ExactTargetWSDL.xml',
                 'useOAuth2Authentication' => true,
                 'applicationType' => 'server'
                );

}

function create_folder($ContentType, $CustomerKeyOfFolder, $NameOfFolder, $NameOfFolderDiscription,  $ParentIDForEmail, $app_folder_id)
{
    $CI = get_instance();
            $CI->load->model('Api_credentials_model');
            $credentials = $CI->Api_credentials_model->get_default();
            $myclient = new ET_Client(
            true,
            true, 
            et_ap_crendentials()
            );
    $postFolder = new ET_Folder();
    $postFolder->authStub = $myclient;
    $postFolder->props = array("CustomerKey" => $CustomerKeyOfFolder, "Name" => $NameOfFolder, "Description" => $NameOfFolderDiscription, "ContentType"=> $ContentType, "ParentFolder" => array("ID" => $ParentIDForEmail), "AllowChildren"=>"1","IsEditable"=>"1","IsActive"=>"1");
    $postResult = $postFolder->post();
    
    $folder_id = $postResult->results[0]->NewID;
    $CI->Api_credentials_model->set_api_one_time_folder($ContentType, $CustomerKeyOfFolder,$NameOfFolder,$folder_id,$credentials['id'], $ParentIDForEmail,$app_folder_id); 
    //var_dump($postResult);
}

function delete($ID)
{
    $CI = get_instance();
            $CI->load->model('Api_credentials_model');
            $credentials = $CI->Api_credentials_model->get_default();
            $myclient = new ET_Client(
            true,
            true, 
            et_ap_crendentials()
            );
    $deleteFolder = new ET_Folder();
    $deleteFolder->authStub = $myclient;
    $deleteFolder->props = array("ID" => $ID);
    echo "<pre>";
    var_dump( $deleteFolder->delete()); # code...
}
function sfmc_api_setting($api_id)
{

            $CI = get_instance();
            $CI->load->model('Api_credentials_model');
            $credentials = $CI->Api_credentials_model->get_default();
              
            $myclient = new ET_Client(
            true,
            false, 
            et_ap_crendentials()
            );

            
            $getFolder = new ET_Folder();
            $getFolder->authStub = $myclient;
            $getFolder->props = array("ID");
            $getFolder->filter = array('LeftOperand' => array('Property' => 'ParentFolder.ID','SimpleOperator' => 'equals','Value' => '0'), 'LogicalOperator' => 'AND', 'RightOperand' => array('Property' => 'ContentType','SimpleOperator' => 'equals','Value' => 'asset'));
            $getResponse = $getFolder->get();
            $ParentIDForEmail = $getResponse->results[0]->ID;

            $CustomerKeyOfFolder = "canvas_app_folder";
            $NameOfFolder = "Canvas App Folder";
            $NameOfFolderDiscription = "This folder is used by canvas app";
            $postFolder = new ET_Folder();
            $postFolder->authStub = $myclient;
            $postFolder->props = array("CustomerKey" => $CustomerKeyOfFolder, "Name" => $NameOfFolder, "Description" => $NameOfFolderDiscription, "ContentType"=> "asset", "ParentFolder" => array("ID" => $ParentIDForEmail) , "AllowChildren"=>"1","IsEditable"=>"1","IsActive"=>"1");

            $postResult = $postFolder->post();
            //print_r( $postResult);
            if ($postResult->results[0]->StatusCode == "OK") {
                 $folder_id = $postResult->results[0]->NewID;
                 $CI->Api_credentials_model->set_api_one_time_folder("asset", $CustomerKeyOfFolder,$NameOfFolder,$folder_id,$api_id, $ParentIDForEmail);
             }
             else
             {
                echo "Folder already exists.";
             } 
             
            
            
            $getFolder = new ET_Folder();
            $getFolder->authStub = $myclient;
            $getFolder->props = array("ID");
            $getFolder->filter = array('LeftOperand' => array('Property' => 'ParentFolder.ID','SimpleOperator' => 'equals','Value' => '0'), 'LogicalOperator' => 'AND', 'RightOperand' => array('Property' => 'ContentType','SimpleOperator' => 'equals','Value' => 'dataextension'));
            $getResponse = $getFolder->get();
            $ParentIDForDE = $getResponse->results[0]->ID;

            $CustomerKeyOfFolder = "canvas_app_folder";
            $NameOfFolder = "Canvas App Folder";
            $NameOfFolderDiscription = "This folder is used by canvas app";
            $postFolder = new ET_Folder();
            $postFolder->authStub = $myclient;
            $postFolder->props = array("CustomerKey" => $CustomerKeyOfFolder, "Name" => $NameOfFolder, "Description" => $NameOfFolderDiscription, "ContentType"=> "dataextension", "ParentFolder" => array("ID" => $ParentIDForDE), "AllowChildren"=>"1","IsEditable"=>"1","IsActive"=>"1");

            $postResult = $postFolder->post();
            print_r( $postResult);
            
            if ($postResult->results[0]->StatusCode == "OK") {
                 $folder_id = $postResult->results[0]->NewID;
                 $CI->Api_credentials_model->set_api_one_time_folder("dataextension", $CustomerKeyOfFolder,$NameOfFolder,$folder_id,$api_id, $ParentIDForDE);  
             }
             else
             {
                echo "DE Folder already exists.";
             }
}

function create_data_extension($name,$CustomerKey,$CategoryID)
{
    $deOne = array("Name" => $name,"CustomerKey" => $CustomerKey, "CategoryID" => $CategoryID);
    $deOne['columns'] = array(
                            //array("Name" => "campaign_id", "FieldType" => "Number", "IsPrimaryKey" => "true", "IsRequired" => "true"),
                            //array("Name" => "edm_id", "FieldType" => "Number", "IsPrimaryKey" => "true", "IsRequired" => "true"),
                            array("Name" => "key_name", "FieldType" => "Text", "IsPrimaryKey" => "true", "MaxLength" => "250", "IsRequired" => "true"),
                            array("Name" => "country_code", "FieldType" => "Text", "IsPrimaryKey" => "true", "MaxLength" => "2", "IsRequired" => "true"),
                            array("Name" => "language_code", "FieldType" => "Text", "IsPrimaryKey" => "true", "MaxLength" => "2", "IsRequired" => "true"),
                            //array("Name" => "variation_id", "FieldType" => "Number", "IsPrimaryKey" => "true", "IsRequired" => "true"),
                            array("Name" => "value", "FieldType" => "Text", "IsPrimaryKey" => "true", "MaxLength" => "2500", "IsRequired" => "true"),
                        );
    
    $CI = get_instance();
    $CI->load->model('Api_credentials_model');
    $credentials = $CI->Api_credentials_model->get_default();
    $myclient = new ET_Client(
    true,
    false, 
    et_ap_crendentials()
    );

    $response = $myclient->CreateDataExtensions(array($deOne));
    //print_r($response);
    if ($response->results[0]->StatusCode == "OK") {
         $de_id = $response->results[0]->NewID;
         return $de_id;
     }
     else
     {
        return false;
     }
    //print_r($response);
}

function create_email($campaign_id,$edm_id)
{   
    $CI = get_instance();
    $CI->load->helper('preview_helper');
    $ampscript =  get_ampscript2($campaign_id,$edm_id);
    $now = DateTime::createFromFormat('U.u', microtime(true));
    $asset_type_name = "htmlemail";
    $asset_type_id = 208;
    $asset_name =  "html_api_file_".$now->format("isu").rand(10,10000);
    $customerKey = "html_api_file_".$now->format("isu").rand(10,10000);
    $category_id = 6079;

    $items = [];
    $items["Name"] = $asset_name;
    $items["CustomerKey"] = $customerKey;
    //$items["channels"] = array("email"=>true, "web"=>false);
    $items["assetType"] = array("name"=>$asset_type_name, "id"=> $asset_type_id);
    $items["category"] = array("id" => $category_id);
    $items["views"] =  array(
                            "subjectline" => array("content" =>  "api subject"),
                            "preheader" => array("content" =>  "api pre subject"),
                            "text" =>  array("content" => $ampscript ),
                             "html" =>  array("content" => $ampscript ),
                            
                             );
    return $items;
}

function getAllFolder()
{
    $CI = get_instance();
            $CI->load->model('Api_credentials_model');
            $credentials = $CI->Api_credentials_model->get_default();
              
            $myclient = new ET_Client(
            true,
            false, 
            et_ap_crendentials()
            );

   $getFolder = new ET_Folder();
    $getFolder->authStub = $myclient;
    $getFolder->props = array("ID", "Client.ID", "ParentFolder.ID", "ParentFolder.CustomerKey", "ParentFolder.ObjectID", "ParentFolder.Name", "ParentFolder.Description", "ParentFolder.ContentType", "ParentFolder.IsActive", "ParentFolder.IsEditable", "ParentFolder.AllowChildren", "Name", "Description", "ContentType", "IsActive", "IsEditable", "AllowChildren", "CreatedDate", "ModifiedDate", "Client.ModifiedBy", "ObjectID", "CustomerKey", "Client.EnterpriseID", "Client.CreatedBy");
    $getResponse = $getFolder->get();
    echo "<pre>";
    var_dump($getResponse);
    
    
    while ($getResponse->moreResults) {
        echo  "Continue Retrieve All Folder with GetMoreResults <\br>";
        $getResponse = $getFolder->GetMoreResults();
        echo('Get Status: '.($getResponse->status ? 'true' : 'false')."<\br>");
        echo 'Code: '.$getResponse->code."<\br>";
        echo 'Message: '.$getResponse->message."<\br>";
        echo('More Results: '.($getResponse->moreResults ? 'true' : 'false')."<\br>");
        echo 'Results Length: '. count($getResponse->results)."<\br>";
        echo "<\br>---------------<\br>";
    }   
    echo "</pre>";
}

function updateeditable($value='')
{
    $CustomerKeyOfFolder = "canvas_app_folder";
    $NameOfTestFolder = "Canvas App Folder";

    $CI = get_instance();
            $CI->load->model('Api_credentials_model');
            $credentials = $CI->Api_credentials_model->get_default();
              
            $myclient = new ET_Client(
            true,
            false, 
            et_ap_crendentials()
            );
    $getFolder = new ET_Folder();
    $getFolder->authStub = $myclient;
    $getFolder->filter = array('Property' => 'CustomerKey','SimpleOperator' => 'equals','Value' => $CustomerKeyOfFolder);
    $getFolder->props = array("ID", "Client.ID", "ParentFolder.ID", "ParentFolder.CustomerKey", "ParentFolder.ObjectID", "ParentFolder.Name", "ParentFolder.Description", "ParentFolder.ContentType", "ParentFolder.IsActive", "ParentFolder.IsEditable", "ParentFolder.AllowChildren", "Name", "Description", "ContentType", "IsActive", "IsEditable", "AllowChildren", "CreatedDate", "ModifiedDate", "Client.ModifiedBy", "ObjectID", "CustomerKey", "Client.EnterpriseID", "Client.CreatedBy");
    $getResponse = $getFolder->get();
     echo "<pre>";
            var_dump($getResponse);
}

function getFolder()
{

    $CustomerKeyOfFolder = "keshav";
    $NameOfTestFolder = "Canvas App Folder";

    $CI = get_instance();
            $CI->load->model('Api_credentials_model');
            $credentials = $CI->Api_credentials_model->get_default();
              
            $myclient = new ET_Client(
            true,
            false, 
            et_ap_crendentials()
            );

            $getFolder = new ET_Folder();
            $getFolder->authStub = $myclient;
            $getFolder->filter = array('Property' => 'CustomerKey','SimpleOperator' => 'equals','Value' => $CustomerKeyOfFolder);
            $getFolder->props = array("ID", "Client.ID", "ParentFolder.ID", "ParentFolder.CustomerKey", "ParentFolder.ObjectID", "ParentFolder.Name", "ParentFolder.Description", "ParentFolder.ContentType", "ParentFolder.IsActive", "ParentFolder.IsEditable", "ParentFolder.AllowChildren", "Name", "Description", "ContentType", "IsActive", "IsEditable", "AllowChildren", "CreatedDate", "ModifiedDate", "Client.ModifiedBy", "ObjectID", "CustomerKey", "Client.EnterpriseID", "Client.CreatedBy");
            $getResponse = $getFolder->get();
            
            echo "<pre>";
            var_dump($getResponse);
}

function create_campaign($campaign_id)
{
    
    $CI = get_instance();
    $CI->load->model('Sfmc_campaign_de_folder_model');
    $CI->load->model('Campaign_model');
    $CI->load->model('Api_credentials_model');

    $sfmc_folder_n_de = $CI->Sfmc_campaign_de_folder_model->getByCampaignID($campaign_id);
    if (sizeof($sfmc_folder_n_de ) > 0) {
       return false;
    }
    ///////////////////////////////Campaign folder////////////////////////////////////////////////////////
    
    $campaign_details =  $CI->Campaign_model->getCampaignsByID($campaign_id);
    $api_parents = $CI->Api_credentials_model->get_canvas_app_folder($campaign_details[0]["folder_id"], "asset");
    $ParentIDForEmail = $api_parents["folder_id"];
    $now = DateTime::createFromFormat('U.u', microtime(true));
    $CustomerKeyOfFolder = "CA__campaign_" .$now->format("isu").rand(10,10000);
    $NameOfFolder = $campaign_details[0]["campaign_name"];
    $NameOfFolderDiscription = "CA_ creative folder.";
    $ContentType = "asset";

    
    //echo $ParentIDForEmail; die;
    $credentials = $CI->Api_credentials_model->get_default();
    $myclient = new ET_Client(
        true,
        true, 
        et_ap_crendentials()
    );
   
    $postFolder = new ET_Folder();
    $postFolder->authStub = $myclient;
   
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $postFolder->props = array("CustomerKey" => $CustomerKeyOfFolder, "Name" => $NameOfFolder, "Description" => $NameOfFolderDiscription, "ContentType"=> $ContentType, "ParentFolder" => array("ID" => $ParentIDForEmail), "AllowChildren"=>"1","IsEditable"=>"1","IsActive"=>"1");
    $postResult = $postFolder->post();
    if ($postResult->results[0]->StatusCode == "OK") {
        $ParentIDForEmail = $postResult->results[0]->NewID;
        $CI->Sfmc_campaign_de_folder_model->insert("Asset folder", $CustomerKeyOfFolder,$NameOfFolder,$campaign_id, $ParentIDForEmail);
        $CustomerKeyOfFolder = "CA__campaign_" .$now->format("isu").rand(10,10000);
        $NameOfFolder = "Creative";
        $postFolder->props = array("CustomerKey" => $CustomerKeyOfFolder, "Name" => $NameOfFolder, "Description" => $NameOfFolderDiscription, "ContentType"=> $ContentType, "ParentFolder" => array("ID" => $ParentIDForEmail), "AllowChildren"=>"1","IsEditable"=>"1","IsActive"=>"1");
        $postResult = $postFolder->post();
        if ($postResult->results[0]->StatusCode == "OK") {
            $sfmc_id = $postResult->results[0]->NewID;
            $CI->Sfmc_campaign_de_folder_model->insert("creative", $CustomerKeyOfFolder,$NameOfFolder,$campaign_id, $sfmc_id);
        }
    }    

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $api_parents = $CI->Api_credentials_model->get_canvas_app_folder($campaign_details[0]["folder_id"], "dataextension");
    $ParentIDForEmail = $api_parents["folder_id"];
    //$CustomerKeyOfFolder = "CA__campaign_" .$now->format("isu").rand(10,10000);
    $NameOfFolder = $campaign_details[0]["campaign_name"];
    $NameOfFolderDiscription = "CA_ creative folder.";
    $ContentType = "dataextension";

    $postFolder->props = array("CustomerKey" => $CustomerKeyOfFolder, "Name" => $NameOfFolder, "Description" => $NameOfFolderDiscription, "ContentType"=> $ContentType, "ParentFolder" => array("ID" => $ParentIDForEmail), "AllowChildren"=>"1","IsEditable"=>"1","IsActive"=>"1");
    $postResult = $postFolder->post();
    //var_dump($postResult);
    if ($postResult->results[0]->StatusCode == "OK") {
        $ParentIDForEmail = $postResult->results[0]->NewID;
        $CI->Sfmc_campaign_de_folder_model->insert("DE Folder", $CustomerKeyOfFolder,$NameOfFolder,$campaign_id, $ParentIDForEmail);
        ///////////////////////////////Translation DE////////////////////////////////////////////////////////
        $CustomerKeyOfFolder = "CA__de_" .$now->format("isu").rand(10,10000);
        $NameOfFolder = $campaign_details[0]["campaign_name"]."_".$now->format("isu").rand(10,10000);;
        $sfmc_id = create_data_extension($NameOfFolder,$CustomerKeyOfFolder,$ParentIDForEmail);
        if (!$sfmc_id) {
           $CI->Sfmc_campaign_de_folder_model->insert("TDE", $CustomerKeyOfFolder,$NameOfFolder,$campaign_id, $sfmc_id);
        }
        
    }
    echo true;
}

?>