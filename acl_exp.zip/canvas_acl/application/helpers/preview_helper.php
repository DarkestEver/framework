 <?php 
function get_ampscript2($campaign_id,$edm_id)
    {
        $CI = get_instance();
        $CI->load->helper('conditional_helper');
        $ampscript_str = "";
        
        $CI->load->model('Edm_model');
        $CI->load->model('Html_email_template_model');
        $CI->load->model('Template_model');

        $campaign_id = $CI->db->escape(strip_tags($campaign_id));
        $edm_id = $CI->db->escape(strip_tags($edm_id));
        $edm_details = $CI->Edm_model->getEDMDByID($campaign_id,$edm_id);
        $email_template = $CI->Html_email_template_model->getByName('grab_nba');
        
        $ampscript_str = $ampscript_str . '%%[';
        $ampscript_str = $ampscript_str . PHP_EOL ;
        $ampscript_str = $ampscript_str . 'SET @sending_de = "sending_de";';
        $ampscript_str = $ampscript_str . PHP_EOL ;
        $ampscript_str = $ampscript_str . 'SET @translation_de = "automation_translation_de2";';
        $ampscript_str = $ampscript_str . PHP_EOL ;
        $ampscript_str = $ampscript_str . 'SET @config_de = "config_de";';
        $ampscript_str = $ampscript_str . PHP_EOL ;
        $ampscript_str = $ampscript_str . 'SET @edm_id = '.$edm_id.';';
        $ampscript_str = $ampscript_str . PHP_EOL ;
        $ampscript_str = $ampscript_str . 'SET @campaign_id = '.$campaign_id.';';
        $ampscript_str = $ampscript_str . PHP_EOL ;
        $ampscript_str = $ampscript_str . 'SET @country_code = Uppercase(AttributeValue("country_code"));';
        $ampscript_str = $ampscript_str . PHP_EOL ;
        $ampscript_str = $ampscript_str . 'SET @language_code = AttributeValue("language_code");';
        $ampscript_str = $ampscript_str . PHP_EOL ;
        $ampscript_str = $ampscript_str . ']%%';
        $ampscript_str = $ampscript_str . PHP_EOL ;
        $ampscript_str = $ampscript_str . PHP_EOL ;
        $ampscript_str = $ampscript_str . PHP_EOL ;

        
        $ampscript_str = $ampscript_str . $email_template['head_tag'];
        $ampscript_str = $ampscript_str . $email_template['body_start_tag'];
        

        $key_prefix = "";
        $module_variation = "";
        $CI->load->model('Edms_module_elements_model');
        $CI->load->model('Template_variations_model');
        $modules = $CI->Template_model->getTemlateByID($campaign_id,$edm_id);
        $module_counter = 1;
        foreach ($modules as $key => $value) {
           //$text =  $value['content_block'] ;
           //$ampscript_str = $ampscript_str . $value['start_ampscript'];
           $t_id =  $value['id'] ;
           $module_id = $value['module_id'];
           $key_name = $value['module_key'];
           if ($key_name == "code_block") {
                $text = "";
           }
           else
           {
              // $code_block_bool = $key_name=="code_block"?true:false;
               #$ampscript_str = $ampscript_str . '%%[ </br> SET @t_id = "'. $t_id . '"';
               $ampscript_str = $ampscript_str . PHP_EOL ;
               $ampscript_str = $ampscript_str .('<!-- start '.$key_name. '  : module number - '. $module_counter.' -->');
               $module_counter ++;
               $ampscript_str = $ampscript_str . PHP_EOL ;
               $ampscript_str = $ampscript_str . '%%[';
               $varations = $CI->Template_variations_model->getByTemplate_id($campaign_id,$edm_id,$t_id);
               foreach ($varations as $v_key => $v_value) {
                    
                    $ampscript_str = $ampscript_str . 'SET @module_visibility = "true";';
                    $ampscript_str = $ampscript_str . PHP_EOL ;
                    if (strtolower($v_value['name']) == 'default' ) {
                        #$ampscript_str = $ampscript_str . 'SET @module_visibility = "true";';
                        $ampscript_str = $ampscript_str . 'SET @module_variation = "'. $v_value['id'] . '" ';
                        $ampscript_str = $ampscript_str . PHP_EOL ;
                    }
                    else
                    {
                       $ampscript_str = $ampscript_str .create_conditions($v_value['conditions'],$v_value['variable_name'],$v_value['hide_show_value'] );
                        
                        //$ampscript_str = $ampscript_str . $v_value['conditions'] . ' "' . $v_value['hide_show_value'] . '" then ' ;
                        $ampscript_str = $ampscript_str . PHP_EOL ;
                        #$ampscript_str = $ampscript_str . 'SET @module_visibility = "true";';
                        $ampscript_str = $ampscript_str . 'SET @module_variation = "'. $v_value['id'] . '" ';
                        $ampscript_str = $ampscript_str .  'Endif ';
                        $ampscript_str = $ampscript_str . PHP_EOL ;
                        
                    }
                }
                $ampscript_str = $ampscript_str . "]%%";
               $ampscript_str = $ampscript_str . PHP_EOL ;
               $ampscript_str = $ampscript_str . PHP_EOL ;
                $ampscript_str = $ampscript_str . '%%[if  @module_visibility == "true" then ';
                $ampscript_str = $ampscript_str . PHP_EOL ;
                //$ampscript_str = $ampscript_str .  '%%=ContentBlockbyKey("'.$text.'")=%%' ;
                $text =  $value['module_html'] ;
                $text = str_replace("__dynamicid__", $key_name."_".$t_id."_", $text); 
                // key_name = campaign_id + edm_id + template_id + variation_id + suffix
                $module_keys = $CI->Edms_module_elements_model->getModuleElementsById($module_id);
                foreach ($module_keys as $mkey => $mvalue) {
                    $module_type = $mvalue['editable_type'];
                    
                    $module_key_name = $key_name."_".$t_id."_".$mvalue["elements"];
                    $module_key_name_title =   "SET @".$module_key_name."_title = LOOKUP(@translation_de, 'value', 'key_name','".$module_key_name."_title','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)";
                    $module_key_name_alias =  "SET @".$module_key_name."_alias = LOOKUP(@translation_de, 'value', 'key_name','".$module_key_name."_alias','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)";
                    $module_key_name_link =  "SET @".$module_key_name."_link = LOOKUP(@translation_de, 'value', 'key_name','".$module_key_name."_link','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)";    
                    $module_key_name_href =  "SET @".$module_key_name."_href = LOOKUP(@translation_de, 'value', 'key_name','".$module_key_name."_href','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)";
                    $text = str_replace($module_key_name. "_" ."alias","%%=v(@".$module_key_name. "_" ."alias".")=%%", $text);
                    $text = str_replace($module_key_name. "_" ."title","%%=v(@".$module_key_name. "_" ."title".")=%%", $text);
                    $text = str_replace($module_key_name. "_" ."link","%%=v(@".$module_key_name. "_" ."link".")=%%", $text);
                    $text = str_replace($module_key_name. "_" ."href","%%=v(@".$module_key_name. "_" ."href".")=%%", $text);
                    
                        if ($module_type == "cta") {
                            $ampscript_str = $ampscript_str . $module_key_name_title;$ampscript_str = $ampscript_str . PHP_EOL ;
                            $ampscript_str = $ampscript_str . $module_key_name_alias;$ampscript_str = $ampscript_str . PHP_EOL ;
                            $ampscript_str = $ampscript_str . $module_key_name_href;$ampscript_str = $ampscript_str . PHP_EOL ;
                            
                        }
                        elseif ($module_type == "image_withoutlink") {
                            $ampscript_str = $ampscript_str . $module_key_name_title;$ampscript_str = $ampscript_str . PHP_EOL ;
                           # $ampscript_str = $ampscript_str . $module_key_name_alias;$ampscript_str = $ampscript_str . PHP_EOL ;
                            $ampscript_str = $ampscript_str . $module_key_name_href;$ampscript_str = $ampscript_str . PHP_EOL ;
                        }
                        elseif ($module_type == "image_withlink") {
                            $ampscript_str = $ampscript_str . $module_key_name_title;$ampscript_str = $ampscript_str . PHP_EOL ;
                            $ampscript_str = $ampscript_str . $module_key_name_alias;$ampscript_str = $ampscript_str . PHP_EOL ;
                            $ampscript_str = $ampscript_str . $module_key_name_href;$ampscript_str = $ampscript_str . PHP_EOL ;
                            $ampscript_str = $ampscript_str . $module_key_name_link;$ampscript_str = $ampscript_str . PHP_EOL ;
                        }
                        elseif ($module_type == "paragraph") {
                           $ampscript_str = $ampscript_str . $module_key_name_title;$ampscript_str = $ampscript_str . PHP_EOL ;
                        }
                        elseif ($module_type == "heading") {
                            $ampscript_str = $ampscript_str . $module_key_name_title;$ampscript_str = $ampscript_str . PHP_EOL ;
                        }
                        else
                        {
                            $text = "";
                        }
                    
                }

                preg_match('#\%%(.*?)\%%#', $text, $match);
                for ($dynamic_variables=0; $dynamic_variables < sizeof($match); $dynamic_variables++) { 
                    str_replace("%%".$match[$dynamic_variables]."%%",'%%=v(AttributeValue("'.$match[$dynamic_variables].'")=%%',$text);
                }
                $ampscript_str = $ampscript_str . ']%%';
               
                $ampscript_str = $ampscript_str . '<tr><td>'; 
                $ampscript_str = $ampscript_str . $text;
                $ampscript_str = $ampscript_str . '</td></tr>';
                   
                $ampscript_str = $ampscript_str . PHP_EOL ;
                $ampscript_str = $ampscript_str . '%%[ Endif ]%%';
               $ampscript_str = $ampscript_str . PHP_EOL ;
                //$ampscript_str = $ampscript_str . $value['end_ampscript'];
                $ampscript_str = $ampscript_str .('<!-- end '.$key_name.' -->');
                $ampscript_str = $ampscript_str . PHP_EOL ;
            }
        }
        
        $ampscript_str = $ampscript_str . '<custom name="opencounter" type="tracking">';
        $ampscript_str = $ampscript_str .('%%[ if 1==0 then]%%<table cellpadding="2" cellspacing="0" width="600" ID="Table5" Border=0><tr><td><font face="verdana" size="1" color="#444444">%%emailaddr%% </br>This email was sent by: <b>%%Member_Busname%%</b><br>%%Member_Addr%% %%Member_City%%, %%Member_State%%, %%Member_PostalCode%%, %%Member_Country%%<br><br></font><a href="%%profile_center_url%%" alias="Update Profile">Update Profile</a></td></tr></table>%%[ Endif ]%%');
        $ampscript_str = $ampscript_str . $email_template['body_end_tag'];
        return $ampscript_str;
    }

?>