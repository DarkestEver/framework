<?php 

function folder_tree()
{
		$CI = get_instance();
        $CI->load->model('Folders_model');
        $tree_data = $CI->Folders_model->all();
        echo '<ul id="tree" data-folder_id = "0"  ><li class="icon-home"> <a class="create_new_folder" href="#">Campaign</a> <ul>';
        buildTree($tree_data);
        echo "</li></ul></ul>"; 
}

function buildTree(array $elements, $parentId = 0) {
    $CI = get_instance();
    $branch = array();
    $CI->load->model('Campaign_model');
    foreach ($elements as $element) {
        if ($element['parent_id'] == $parentId) {
            echo "<li><a data-folder_name ='".$element['f_name']."'  data-folder_id = '".$element['id']."'  class='icon-folder create_new_folder' href='#'>".$element['f_name']." </a>";
            echo "<ul>";
            $children = buildTree($elements, $element['id']);
            if ($children) {
                $element['children'] = $children;
            }
            else
            {
                $campaigns = $CI->Campaign_model->getCampaignsByFolderID(  $element['id']);
                foreach ($campaigns as $key => $campaign) {
                    echo "<li><a class='icon-text vertical-nav-menu metismenu campaign_folder' data-campaign_id = '".$campaign['id']."' href='#' > ".$campaign['campaign_name']." </a></li>";
                }
            }
            echo "</ul>";
            echo "</li>";
           // $branch[] = $element;
        }
    }
    //return $branch;
}

?>	


