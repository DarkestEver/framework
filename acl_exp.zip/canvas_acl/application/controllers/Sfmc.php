<?php

defined('BASEPATH') OR exit('No direct script access allowed');
use FuelSdk\ET_Client;
use FuelSdk\ET_Folder;

class Sfmc extends CI_Controller {

     public function __construct() {
        parent::__construct();
        $this->Admin_model->verifyUser("OPS");
        $this->load->model('Api_credentials_model');     
        $this->load->model('Sfmc_campaign_de_folder_model');
        $this->load->helper('sfmc');   
        $this->load->model("Campaign_model");
        $this->load->model("Folders_model");
        
    }


    public function index($campaign_id, $edm_id)
    {
        $this->load->model('Edm_model');
        
        $data['campaign_id'] = $campaign_id;
        $data['edm_id'] = $edm_id;
        $campaign_id = $this->db->escape(strip_tags($campaign_id));
        $edm_id = $this->db->escape(strip_tags($edm_id));
        $sfmc_folder_n_de = $this->Sfmc_campaign_de_folder_model->getByCampaignID($campaign_id);
        $campaign_parent_folder = $this->Campaign_model->getCampaignsByID($campaign_id);
        $campaign_parent_folder_id = $campaign_parent_folder[0]["folder_id"];
        
        $folder_sync = $this->Api_credentials_model->get_apifolder_appfid($campaign_parent_folder_id);
       
        $data["folder_sync"] = $folder_sync;
        $data["de_details"] = $sfmc_folder_n_de;
        $data['edm_details'] = $this->Edm_model->getEmailByID($campaign_id, $edm_id);
        if ($data['edm_details'] == false)  {
            $error_message['error'] = "Email not found";
            $this->load->view('header' );
            $this->load->view('error',$error_message);
            $this->load->view('footer');
        }
        $data['rows'] = $this->Edm_model->getLocalizedEDMDByID($campaign_id, $edm_id);
        $data['v_count'] = $this->Edm_model->getLocalizedEDMDCountByID($campaign_id, $edm_id); 
        $data['img_count'] = $this->Edm_model->getImageEDMDCountByID($campaign_id, $edm_id); 
        $data['key_count'] = sizeof(get_dataextension_key($campaign_id,$edm_id)) - $data['v_count']*2 ;
        $settings['js'] = "sfmc_index";
        $this->load->view('header', $settings);
        $this->load->view('sfmc/index',$data);
        $this->load->view('footer');
    }

    public function export_de($campaign_id, $edm_id)
    {
        $this->load->helper('sfmc');
        $rows = get_dataextension_custom_key($campaign_id,$edm_id);
        $file_name = 'Translation_DE_'.date('Ymd').'.csv';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$file_name");
        header("Content-Type: application/csv;");
        $file = fopen('php://output', 'w');
        $header = array("country_code","language_code","key_name","value");
        fputcsv($file, $header);
        foreach ($rows as $key => $row) {
            $arr = [];
            //$arr[] = $row['campaign_id'];
            //$arr[] = $row['edm_id'];
            $arr[] = $row['country_code'];
            $arr[] = $row['language_code'];
            //$arr[] = $row['variation_id'];
            $arr[] = $row['key_name'];
            $arr[] = $row['value'];
            fputcsv($file, $arr);
        }
        fclose($file);
    }

    public function upload_de_to_sfmc($campaign_id,$edm_id)
    {   
        $sfmc_folder_n_de = $this->Sfmc_campaign_de_folder_model->get_TDE_folder($campaign_id);
        if ($sfmc_folder_n_de["type"] == "") {
            echo "DE folder does not exist."; return;
        }
        $tde_customer_key = $sfmc_folder_n_de["customerkey"];
        $rows = get_dataextension_custom_key($campaign_id,$edm_id);
        $marks = array( 'items'=> $rows);
        $json_input_data =  json_encode($marks);        
        $token = getToken();
        $data_url =  'data/v1/async/dataextensions/key:'.$tde_customer_key.'/rows';
        $data_result =SFMC_API_Exe($data_url, $json_input_data, 1, $token, 'PUT');
        if ($data_result != false ) {
           $this->load->model('Edms_saved_inputs_model');
           $this->Edms_saved_inputs_model->set_API_key_uploadeded($campaign_id, $edm_id);
           $this->load->model('Edm_model');
           $this->Edm_model->update_api_stus($campaign_id, $edm_id);
        }
        else 
        {   
           echo 'Unable to upload DE; Please connect support team.';
        }
    }


    public function upload_image_to_sfmc($id,$image_folder_id) 
    {

        $this->load->model('Edms_saved_inputs_model');
        $image_data = $this->Edms_saved_inputs_model->getById($id);
        $now = DateTime::createFromFormat('U.u', microtime(true));
        if ($image_data != false) {
            $image_url = $image_data[0]['href'];
            $ext = explode ('.',(parse_url($image_url)['path'])) ;
            $file_ext = $ext[1];
            $image_name = explode ('/',$ext[0]) ;
            $image_name = $image_name[sizeof($image_name)-1];//ltrim($image_name, '/');//."_".uniqid (rand (),false);
            $this->load->model('Asset_model');
            $asset_type_id = $this->Asset_model->getAssestIDByFileExt($file_ext);
            $image_base64 = base64_encode(file_get_contents($image_url));

            $data_url = 'asset/v1/content/assets';
            $items = [];
            
            $items["Name"] = $image_name."_".$now->format("mdYHisu");;
            $items["CustomerKey"] = "ca_asset_".$now->format("mdYHisu");;
            $items["assetType"] = array("name"=>$file_ext, "id"=> $asset_type_id);
            $items["category"] = array("id" => $image_folder_id);
            $items["file"] = $image_base64;
            $json_input_data = json_encode($items);

            $json_data = SFMC_API_Exe($data_url, $json_input_data, 1, '', 'POST');
            
            if ($json_data != false) {
                $json_data = json_decode($json_data);
                $published_url = $json_data->fileProperties->publishedURL;
                $this->load->model('Edms_saved_inputs_model');
                $this->Edms_saved_inputs_model->set_API_image_key_uploadeded($id,$published_url);
                return $published_url;
            }
        }
    }

    public function ajax_upload_image($campaign_id, $edm_id)
    {    
        $sfmc_folder_n_de = $this->Sfmc_campaign_de_folder_model->get_creative_folder($campaign_id);
        if ($sfmc_folder_n_de["type"] == "") {
            echo "Creative folder does not exist."; return;
        }
        $creative_folder = $sfmc_folder_n_de["sfmc_id"];
        $this->load->model('Edms_saved_inputs_model');
        $images_to_upload =  $this->Edms_saved_inputs_model->getImageEDMDByID($campaign_id, $edm_id);
        foreach ($images_to_upload as $key => $value) {
            $published_url = $this->upload_image_to_sfmc($value['id'],$creative_folder);
        }
        $this->load->model('Edm_model');
        echo $this->Edm_model->getImageEDMDCountByID($campaign_id, $edm_id); 
        $this->Edm_model->update_api_stus($campaign_id, $edm_id);
    }



    public function new_html_eamil($campaign_id,$edm_id)
     {
        /*
        $this->load->model('Folders_model');
        $app_folder_id = 2;
        $ParentIDForEmail  =  $this->Api_credentials_model->get_canvas_app_folder($app_folder_id,3);
        $ParentIDForEmail = $ParentIDForEmail['folder_id'];

        echo create_folder('asset', "text_campaign", "Text Campagin", "text campaign folder",  $ParentIDForEmail, $app_folder_id);
        */

        $items = create_email();

        $data_url = 'asset/v1/content/assets';
        $json_input_data = json_encode($items);
       // print_r($json_input_data); die;
        $json_data = SFMC_API_Exe($data_url, $json_input_data, 1, '', 'POST');
        print_r(json_decode($json_data)->objectID);
        
     }



    public function ajax_folder_hierarchy($campaign_id) {
        $this->load->helper("sfmc_api_folder_helper");
        // check if campaign folder is available in SFMC 
        $folder_id =  $this->Campaign_model->getCampaignsByID($campaign_id);
        $folder_id =  $folder_id[0]["folder_id"];
        $check = $this->Api_credentials_model->get_apifolder_appfid($folder_id);
        if ($check["folder_id"] != "") {
           echo false;
        }

        $folders = getFoldersNotInSFMC($folder_id);
        $folders_count = sizeof($folders);
        
        for ($i=1; $i < sizeof($folders); $i++) { 
            $NameOfFolderDiscription = "Canvas api folder.";
            $app_folder_id = $folders[$i];
            $now = DateTime::createFromFormat('U.u', microtime(true));
            
            $folder_details =  $this->Folders_model->get_by_id($app_folder_id);
            $NameOfFolder = $folder_details["f_name"];
            $parent_folder_id = $folder_details["parent_id"];
            $api_parents = $this->Api_credentials_model->get_apifolder_appfid($parent_folder_id);
            foreach ($api_parents as $key => $value) {
                $ContentType = $value["type"];
                $ParentIDForEmail = $value["folder_id"];
                $CustomerKeyOfFolder =  "CAP_".$ContentType."_".$now->format("isu").rand(10,10000);
                create_folder($ContentType, $CustomerKeyOfFolder, $NameOfFolder, $NameOfFolderDiscription,  $ParentIDForEmail, $app_folder_id);
            }
        }  

        echo true;
    }

    public function ajax_create_campaign($campaign_id)
    {
       echo create_campaign($campaign_id);
    }
}
