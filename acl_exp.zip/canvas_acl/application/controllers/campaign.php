<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class campaign extends CI_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('Log_model');
       $this->Admin_model->verifyUser("All");
    }

    public function index($campaign_id_url = "") {

        $this->load->helper('folderstructure');
        $this->load->model('Campaign_model');
        

        $data['countries'] = $this->Campaign_model->getCountries();

        $settings['css'] = "campaign_index";
        $settings['js'] = "campaign_index";
        $settings['title'] = "Campaign List";
        $settings['sidebar_panel'] = "sidebar";
        
        if (!empty($campaign_id_url)) {
            $settings['campaign_id_url'] = $campaign_id_url;
            $settings['campaign_name'] = $this->Campaign_model->getCampaignsByID($campaign_id_url)[0]['campaign_name'];
        }
        

        $this->load->model('Campaign_model');
        $data['countries'] = $this->Campaign_model->getCountries();

        $this->load->view('header', $settings);
        $this->load->view('campaign/index', $data);
        $this->load->view('footer');
    }

  function in_parent($in_parent,$campaign_id,$store_all_id) {
        // this variable to save all concatenated html
        $html = "";
        // build hierarchy  html structure based on ul li (parent-child) nodes
        if (in_array($in_parent,$store_all_id)) {
            $result = $this->comment_model->tree_by_parent($campaign_id,$in_parent);
            $html .=  $in_parent == 0 ? "<div id='reader'><ol>" : "<ol>";
            foreach ($result as $re) {
                $acronym="";
                foreach(explode(' ', $re['name']) as $word) {$acronym .= mb_substr($word, 0, 1, 'utf-8');}
                $html .= " <li class='comment_box' id='comment_id_". $re['comment_id']."'>
                <div class='row'><div class='col-sm-12'><div class='aut'>". $acronym . " : ".$re['comment_name']."</div>
         
            <div class='comment-body'>".$re['comment_body']."</div>
            <div class='timestamp'>".date("F j, Y", $re['comment_created'])."</div>
            <a  href='#comment_form' class='reply' id='" . $re['comment_id'] . "'>Reply</a>";
            $html .= "</div></div></li>";
                $html .=$this->in_parent($re['comment_id'],$campaign_id, $store_all_id);
                
            }
            $html .=  "</ol>";
        }

        return $html;
    }

    function add_comment($campaign_id)
    {

        // get a post id based on news id
        //$data['news'] = $this->news_model->get_one($campaign_id);

        //set validation rules
        $this->form_validation->set_rules('comment_name', 'Name', 'required|trim|htmlspecialchars');
        //$this->form_validation->set_rules('comment_email', 'Email', 'required|valid_email|trim|htmlspecialchars');
        $this->form_validation->set_rules('comment_body', 'comment_body', 'required|trim|htmlspecialchars');
        if ($this->form_validation->run() == FALSE) {
            // if not valid load comments
            $this->session->set_flashdata('error_msg', validation_errors());
            redirect("comments/index/$campaign_id");
        } else {
            //if valid send comment to admin to tak approve
            $this->comment_model->add_new_comment();
            $this->session->set_flashdata('error_msg', 'Your comment is awaiting moderation.');
            redirect("comments/index/$campaign_id");
        }
    }
	

    public function ajax_searchCamaign() {
        if ($this->input->post()) {
            $postData = $this->input->post();
            $draw = $postData['draw'];
            $start = $postData['start'];
            $length = $postData['length'];

            if (!isset($postData["emailname"]) || empty($postData["emailname"])) {
                $emailname = "";
            } else {
                $emailname = strip_tags($postData["emailname"]);
            }

            if (!isset($postData["categoryName"]) || empty($postData["categoryName"])) {
                $categoryName = "";
            } else {
                $categoryName = $this->db->escape(strip_tags($postData["categoryName"]));
            }

            if (!isset($postData["vertical"]) || empty($postData["vertical"])) {
                $vertical = "";
            } else {
                $vertical = $this->db->escape(strip_tags($postData["vertical"]));
            }

            if (!isset($postData["wheel"]) || empty($postData["wheel"])) {
                $wheel = "";
            } else {
                $wheel = $this->db->escape(strip_tags($postData["wheel"]));
            }

            $this->load->model('Campaign_model');
            //echo $wheel . $vertical . $categoryName; die;
            $getCampaignCount = $this->Campaign_model->getCampaignCount();
            $result = $this->Campaign_model->searchCampaign($emailname,$categoryName,$vertical,$wheel,$start,$length );
            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" => $getCampaignCount,
                "iTotalDisplayRecords" =>  $result['count'],
                "aaData" => $result['data']
            );
            echo json_encode($response);
        }
    }


    public function ajax_campaign_selected($campaign_id="") {
        if ($this->input->post()) {
            $postData = $this->input->post();
            $draw = $postData['draw'];
            $start = $postData['start'];
            $length = $postData['length'];
            $campaign_id = strip_tags($campaign_id);
            $this->load->model('Campaign_model');
            $result = $this->Campaign_model->getAllEMDByCampaignID($campaign_id,$start,$length );
            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" =>  $result['count'],
                "iTotalDisplayRecords" =>  $result['count'],
                "aaData" => $result['data']
            );
            echo json_encode($response);
        }
    }

    public function newfoder()
    {
        if ($this->input->post()) {
            $postData = $this->input->post("data");   
            $parent_id = $this->db->escape(strip_tags($postData["parent_id"]));
            $f_name = $this->db->escape(strip_tags($postData["f_name"]));
            $this->load->model('Folders_model');
            echo $this->Folders_model->insert_by_name_id($parent_id,$f_name );
        }
        
    }

    public function ajax_update_folder()
    {
        if ($this->input->post()) {
            $postData = $this->input->post("data");   
            $id = $this->db->escape(strip_tags($postData["id"]));
            $f_name = $this->db->escape(strip_tags($postData["f_name"]));
            $this->load->model('Folders_model');
            echo $this->Folders_model->update_by_name_id($id,$f_name );
        }
    }
    
    public function ajax_createCampaignwithinfolder($value='')
    {
        if ($this->input->post()) {
            $postData = $this->input->post("data");   
            $folder_id = $this->db->escape(strip_tags($postData["folder_id"]));
            $campaing_name_new = $this->db->escape(strip_tags($postData["campaing_name"]));
            $this->load->model('Campaign_model');
            echo $this->Campaign_model->createCampaignFolderId($folder_id,$campaing_name_new );
        }
    }

    public function ajax_add_new_email($value='')
    {
        if ($this->input->post()) {
            $postData = $this->input->post('data');
            if ( isset($postData["campaign_id"])) {
                $market = $postData["countries_code"];
                if (!isset($postData["emailname"]) || empty($postData["emailname"])) {
                    $emailname = "";
                    return "1";
                } else {
                    $emailname = $this->db->escape(strip_tags($postData["emailname"]));
                }
                $campaign_id = $this->db->escape(strip_tags($postData["campaign_id"]));
                $this->load->model('Edm_model');
                $chk = $this->Edm_model->createEDM($campaign_id, $emailname, $market);
                echo $chk;
            }
        }
    }
}
