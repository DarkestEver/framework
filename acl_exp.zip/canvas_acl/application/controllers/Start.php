<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Start extends CI_Controller {

	public function index()
	{
		if ($this->Admin_model->verifyUser("All")) {
            $this->load->helper('status_helper');
            $settings['sidebar_panel'] = 'sidebar';

            $this->load->model('Dashboard_model');
            $data['getTotalCampaign'] = $this->Dashboard_model->getTotalCampaign();
            
            $data['getTotalEDMs'] =  $this->Dashboard_model->getTotalEDMs();
            $total_Local_edm = $this->Dashboard_model->getTotalLocalEDMs();
            $data['getTotalUser'] = $this->Dashboard_model->getTotalUser();
            $data['getTop5Emails']= $this->Dashboard_model->getTop5Emails();
            $data['total_Local_edm']= $total_Local_edm;
            $data['totalPusblishedEDM']= round(($this->Dashboard_model->gettotalEDMByStatus(2)/$total_Local_edm)*100,0);
            $data['totalPendingEDM']= round(($this->Dashboard_model->gettotalEDMByStatus(0)/$total_Local_edm)*100,0);
            $data['totalCreatedEDM']= round(($this->Dashboard_model->gettotalEDMByStatus(1)/$total_Local_edm)*100,0);

             $settings["js"]= "start_dashboard";
            $this->load->view('header', $settings);
            $this->load->view('welcome_message',$data);
            $this->load->view('footer', $settings);		}
	}
}
