<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {

function index($value='')
{
	$str = "%%[
SET @section='ICO4_7c'
SET @sub_vert = 'all'
SET @city_id = 'all'
SET @key_name=CONCAT(@creative, '_', @sub_vert, '_', @section, '_')
SET @ICO4_7c_hl=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'hl'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon1=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon1'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon1_url=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon1-url'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon1_alt=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon1-alt'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon1_hl=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon1-hl'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon1_bc=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon1-bc'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon1_lnk_txt=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon1-lnk-txt'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon1_lnk_url=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon1-lnk-url'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon2=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon2'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon2_url=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon2-url'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon2_alt=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon2-alt'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon2_hl=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon2-hl'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon2_bc=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon2-bc'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon2_lnk_txt=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon2-lnk-txt'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
SET @ICO4_7c_icon2_lnk_url=LOOKUP(@content, 'value', 'key', CONCAT(@key_name, 'icon2-lnk-url'), 'country_code', @country_code, 'language_code', @language_code, 'city_id', @city_id)
]%%
%%==%%
%%[sdsdsdsdsds]%%
";



    $start ='%%[';
    $end = ']%%';

    $element_count = preg_match_all(preg_quote('/'.$start.'/'), $str, $array);
    /// 1st %%[]%% contains keys
    $keys_str =  $this->getBetween($str, $start, $end );
    /// split by set
    $keys_arr = explode("SET",$str);

    $elements = [];

    echo("<pre>");
    foreach ($keys_arr as $key => $value) {
      
       $value = strtolower($value);
       if (strpos($value, "lookup")) {
            $key = explode("=",$value);
            if (sizeof($key) > 0) {
                echo "<br>";
                echo $key[0];
                echo " : ";
                $key_name = $this->getBetween($key[1], "concat(@key_name, '" , "')," ); 
                echo $key_name;
                $key_name_replace = str_replace("-", "_", $key_name);
                $element = str_replace("_".$key_name_replace, "", $key[0]);
                $element = str_replace("@", "", $element);
                $elements[] =  $element;
            }
       }
    }
    

    print_r(array_unique($elements));



    $str = $this->replace_content_inside_delimiters("%%[", "]%%", "", $str);
    $str = str_replace("%%[]%%", "", $str);
    print_r($str);

}

function replace_content_inside_delimiters($start, $end, $new, $source) {
return preg_replace('#('.preg_quote($start).')(.*?)('.preg_quote($end).')#si', '$1'.$new.'$3', $source);
}

function getBetween($string, $start = "", $end = ""){
        if (strpos($string, $start)) { // required if $start not exist in $string
            $startCharCount = strpos($string, $start) + strlen($start);
            $firstSubStr = substr($string, $startCharCount, strlen($string));
            $endCharCount = strpos($firstSubStr, $end);
            if ($endCharCount == 0) {
                $endCharCount = strlen($firstSubStr);
            }
            return substr($firstSubStr, 0, $endCharCount);
        } else {
            return '';
        }
    }


}
