<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AppController extends CI_Controller {

    public $user;
    public $apis;
    public $users;
    public $countries;
    public $edms;
    public $campaigns;

    public function __construct()
    {
       parent::__construct();
       $this->load->model('Log_model');

        // Init
        $this->user = 'admin';
        $this->apis = 3;
        $this->users = 1;
        $this->countries = 3;
        $this->edms = 18;
        $this->campaigns = 2;
    }
}

