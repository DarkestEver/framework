<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller {

	public function __construct()
    {
       parent::__construct();
	   $this->load->model('Log_model');
	   $this->Admin_model->verifyUser();

    }
	

	public function admins($page=null, $adminid=0) {
		$setting['top_title_panel'] = "settings/top_title_panel";
		$setting['page_title'] = "User";
		$setting['page_sub_title'] = "Add / Delete/ Edit";
		if ($this->input->post()) {
			$postData = $this->input->post();
			$this->Admin_model->updateAdmins($postData, $postData["action"]);
		}
		if ($page == "add") {
			$data["result"] = $this->Admin_model->getAdminInfo($adminid);
			$data["admin_groups"] = $this->Admin_model->getAdminGroups();
			$this->load->view('header',$setting );
			$this->load->view('settings/admins_add', $data);
			$this->load->view('footer');
		} elseif ($page == "edit") {
			if ($adminid == null) { redirect(base_url(), 'auto'); }
			$data["admin_groups"] = $this->Admin_model->getAdminGroups();
			$data["result"] = $this->Admin_model->getAdminInfo($adminid);
			$this->load->view('header',$setting );
			$this->load->view('settings/admins_edit', $data);
			$this->load->view('footer');
		} else {
			$data["admins"] = $this->Admin_model->getAdmins();
			$this->load->view('header',$setting );
			$this->load->view('settings/admins', $data);
			$this->load->view('footer');
		}
		
	}

	public function groups($page=null, $groupid=0) {
		$setting['top_title_panel'] = "settings/top_title_panel";
		$setting['page_title'] = "User Group";
		$setting['page_sub_title'] = "Add / Delete/ Edit";
			if ($this->input->post()) {
				$postData = $this->input->post();
				$this->Admin_model->updateGroups($postData, $postData["action"]);
			}
			if ($page == "add") {
				
				$this->load->view('header',$setting );
				$this->load->view('settings/admingroups_add');
				$this->load->view('footer');
			} elseif ($page == "edit") {
				$data["result"] = $this->Admin_model->getAdminGroups($groupid);
				
				$this->load->view('header',$setting );
				$this->load->view('settings/admingroups_edit', $data);
				$this->load->view('footer');
			} else {
				$data["groups"] = $this->Admin_model->getAdminGroups();
				
				$this->load->view('header',$setting );
				$this->load->view('settings/groups', $data);
				$this->load->view('footer');
			}
		
	}

	public function apis($page=null, $groupid=0) {
		$this->load->helper('sfmc_helper');
		$setting['page_title'] = "SFMC API";
		$setting['page_sub_title'] = "Add / Delete/ Edit";
		$this->load->model('Api_credentials_model');
		$setting['top_title_panel'] = "settings/top_title_panel";
			if ($this->input->post()) {
				$postData = $this->input->post();
				$api_id =  $this->Api_credentials_model->updateApi($postData, $postData["action"]);
				sfmc_api_setting($api_id);
			}
			if ($page == "add") {
				
				$this->load->view('header',$setting );
				$this->load->view('settings/api_add');
				$this->load->view('footer');
			} elseif ($page == "edit") {
				if ($groupid == null) { redirect(base_url(), 'auto'); }
				$data["result"] = $this->Api_credentials_model->getAllAPIsById($groupid);
				if (empty($data["result"])) { redirect(base_url(), 'auto'); }
				$data["post_type"] = 'edit';
				
				$this->load->view('header',$setting );
				$this->load->view('settings/api_add', $data);
				$this->load->view('footer');
			} else {
				$data["groups"] = $this->Api_credentials_model->getAllAPIs();
				
				$this->load->view('header',$setting );
				$this->load->view('settings/api_list', $data);
				$this->load->view('footer');
			}
	}

	public function countries($page=null, $groupid=0) {
		$setting['top_title_panel'] = "settings/top_title_panel";
		$setting['page_title'] = "Country";
		$setting['page_sub_title'] = "Add / Delete/ Edit";
			$this->load->model('Country_model');
			if ($this->input->post()) {
				$postData = $this->input->post();
				$this->Country_model->updateCountry($postData, $postData["action"]);
			}
			if ($page == "add") {
				
				$this->load->view('header',$setting );
				$this->load->view('settings/country_add');
				$this->load->view('footer');
			} elseif ($page == "edit") {
				if ($groupid == null) { redirect(base_url(), 'auto'); }
				$groupid = $this->db->escape(strip_tags($groupid));
				$data["result"] = $this->Country_model->getCountriesByID($groupid);
				if (empty($data["result"])) { redirect(base_url(), 'auto'); }
				$data["post_type"] = 'edit';
				
				$this->load->view('header',$setting );
				$this->load->view('settings/country_add', $data);
				$this->load->view('footer');
			} else {
				$data["groups"] = $this->Country_model->getCountries();
				
				$this->load->view('header',$setting );
				$this->load->view('settings/country_list', $data);
				$this->load->view('footer');
			}
		
	}

	public function Vertical($page=null, $groupid=0) {
			$this->load->model('Vertical_model');
			if ($this->input->post()) {
				$postData = $this->input->post();
				$this->Vertical_model->update($postData, $postData["action"]);
			}
			if ($page == "add") {
				
				$this->load->view('header',$setting );
				$this->load->view('settings/vertical_add');
				$this->load->view('footer');
			} elseif ($page == "edit") {
				if ($groupid == null) { redirect(base_url(), 'auto'); }
				$groupid = $this->db->escape(strip_tags($groupid));
				$data["result"] = $this->Vertical_model->getByID($groupid);
				if (empty($data["result"])) { redirect(base_url(), 'auto'); }
				$data["post_type"] = 'edit';
				
				$this->load->view('header',$setting );
				$this->load->view('settings/vertical_add', $data);
				$this->load->view('footer');
			} else {
				$data["groups"] = $this->Vertical_model->getAll();
				
				$this->load->view('header',$setting );
				$this->load->view('settings/vertical_list', $data);
				$this->load->view('footer');
			}
		}
	
	public function delete_module($id='')
	{
		$this->load->model('Modules_model');
		$this->Modules_model->delete_module($id);
	}
	
	public function component($page=null, $groupid=0) {
		
		$setting['page_title'] = "Component";
		$setting['page_sub_title'] = "Add / Delete/ Edit";
		$this->load->model('Modules_model');
		$setting['top_title_panel'] = "settings/top_title_panel";
			if ($this->input->post()) {
				$postData = $this->input->post();
				$html = $postData["module_html"];

				// remove ampscript
				$html = $this->replace_content_inside_delimiters("%%[", "]%%", "", $html);
		    	$html = str_replace("%%[]%%", "", $html);
		    	$postData["module_html"] = $html;
		    	//echo $html; die;
				if(! $this->check_html_validation($html))
				{
					die;
				}

				if ($postData["action"] == "save") {
					unset($postData["action"]);
					unset($postData["submit"]);
					$postData["is_active"] = 1; 
					$this->db->insert('modules', $postData);
					$id = $this->db->insert_id();
					$this->add_keys($id, $html);
					redirect(base_url().'settings/component/edit/'.$id, 'auto');
				}
				elseif ($postData["action"] == "edit" ) {
					unset($postData["action"]);
					unset($postData["submit"]);
					unset($postData["module_name"]);
					$id = $groupid;
					
					$this->db->where('id', $id);
					$this->db->update('modules', $postData);
					//redirect(base_url().'settings/component/edit/'.$groupid, 'auto');
				}
				elseif ($postData["submit"] == "delete") {
					unset($postData["submit"]);
				}
				//$api_id =  $this->Api_credentials_model->updateApi($postData, $postData["action"]);
				//sfmc_api_setting($api_id);
			}
			if ($page == "add") {
				$data["groups"] = $this->Modules_model->getModulesCategory();
				$this->load->view('header',$setting );
				$this->load->view('settings/components',$data);
				$this->load->view('footer');
			} elseif ($page == "edit") {
				if ($groupid == null) { redirect(base_url(), 'auto'); }
				$data["result"] = $this->Modules_model->getById($groupid);
				$data["groups"] = $this->Modules_model->getModulesCategory();
				if (empty($data["result"])) { redirect(base_url(), 'auto'); }
				$data["post_type"] = 'edit';
				$this->load->view('header',$setting );
				$this->load->view('settings/components', $data);
				$this->load->view('footer');
			} else {
				$data["list"] = $this->Modules_model->getAll();
				$this->load->view('header',$setting );
				$this->load->view('settings/component_list', $data);
				$this->load->view('footer');
			}
	}

	function check_html_validation($str)
	{
		 if ($str == "") {		 	
		 	return false;
		 }

		 $start	='id="__dynamicid__';
		 $end = '"';
		 $editable_type = 'data-editable="';

		 $element_count = preg_match_all(preg_quote('/'.$start.'/'), $str, $array);
		 $editable_type_count = preg_match_all(preg_quote('/'.$editable_type.'/'), $str, $array);
		 if ($element_count == $editable_type_count) {
		 	return true;
		 }else
		 { return false;
		 }


	}

	function replace_content_inside_delimiters($start, $end, $new, $source) {
	return preg_replace('#('.preg_quote($start).')(.*?)('.preg_quote($end).')#si', '$1'.$new.'$3', $source);
	}
	
	public function add_keys($module_id, $str)
	{
		 		
		 $start	='id="__dynamicid__';
		 $end = '"';
		 $editable_type = 'data-editable="';
		 

		 $element_count = preg_match_all(preg_quote('/'.$start.'/'), $str, $array);
		 $editable_type_count = preg_match_all(preg_quote('/'.$editable_type.'/'), $str, $array);
			 if ($element_count == $editable_type_count) {
				 while ( strpos($str, $start) != 0) {
				 	  $items = [];
				 	  $custom_keys_data = [];
				 	  $custom_keys = [];
				 	  $items["elements"] =  	  $this->getBetween($str, $start, $end);
					  $str = preg_replace(preg_quote('/'.$start.'/'), '', $str, 1);
					  $items["editable_type"] =  	  $this->getBetween($str, $editable_type, $end);
					  $str = preg_replace(preg_quote('/'.$editable_type.'/'), '', $str, 1);
					  $items["module_id"] = $module_id;
					  $custom_keys["module_id"] = $module_id;
					  $module_type = $items["editable_type"];
					  $custom_keys['elements'] = $items["elements"];
					  if ($module_type == "cta") {
			                $items["alias"] = "Platea dictumst";
			                $items["href"] = "https://via.placeholder.com/600x300.png?text=Image+600+x+300";
			                $items["title"] = "Platea dictumst quisque sagittis purus sit";
			                $custom_keys['old_key'] = "alias"; $this->insert_custom_keys($custom_keys);
			                $custom_keys['old_key'] = "href";  $this->insert_custom_keys($custom_keys);
			                $custom_keys['old_key'] = "title";  $this->insert_custom_keys($custom_keys);
			            }
			            elseif ($module_type == "image_withoutlink") {
			                $items["alias"] = "Platea dictumst";
			                $items["href"] = "https://via.placeholder.com/600x300.png?text=Image+600+x+300";
			                $items["title"] = "Platea dictumst quisque sagittis purus sit";
			                $custom_keys['old_key'] = "alias";  $this->insert_custom_keys($custom_keys);
			                $custom_keys['old_key'] = "href";  $this->insert_custom_keys($custom_keys);
			                $custom_keys['old_key'] = "title";  $this->insert_custom_keys($custom_keys);
			            }
			            elseif ($module_type == "image_withlink") {
			                $items["link"] = "https://www.google.com";
			                $items["alias"] = "Platea dictumst";
			                $items["href"] = "https://via.placeholder.com/600x300.png?text=Image+600+x+300";
			                $items["title"] = "Platea dictumst quisque sagittis purus sit";
			                $custom_keys['old_key'] = "alias";  $this->insert_custom_keys($custom_keys);
			                $custom_keys['old_key'] = "href";  $this->insert_custom_keys($custom_keys);
			                $custom_keys['old_key'] = "title";  $this->insert_custom_keys($custom_keys);
			                $custom_keys['old_key'] = "link";  $this->insert_custom_keys($custom_keys);
			            }
			            elseif ($module_type == "paragraph") {
			                $items["title"] = "Platea dictumst quisque sagittis purus sit";
			                $custom_keys['old_key'] = "title";  $this->insert_custom_keys($custom_keys);
			            }
			            elseif ($module_type == "heading") {
			                $items["title"] = "Platea dictumst quisque sagittis purus sit";
			                $custom_keys['old_key'] = "title";  $this->insert_custom_keys($custom_keys);
			            }
			            $this->db->insert('edms_module_elements', $items);     
				 }
			}
			else
			{
				return false;
			}
	}

	function insert_custom_keys($data)
	{	
		$this->db->insert('custom_key_mapping', $data);
	}

	function getBetween($string, $start = "", $end = ""){
	    if (strpos($string, $start)) { // required if $start not exist in $string
	        $startCharCount = strpos($string, $start) + strlen($start);
	        $firstSubStr = substr($string, $startCharCount, strlen($string));
	        $endCharCount = strpos($firstSubStr, $end);
	        if ($endCharCount == 0) {
	            $endCharCount = strlen($firstSubStr);
	        }
	        return substr($firstSubStr, 0, $endCharCount);
	    } else {
	        return '';
	    }
	}

	public function customkeymapping($module_id='')
	{
		$setting['page_title'] = "Component Key Mapping";
		$setting['page_sub_title'] = "Add / Delete/ Edit";
		$this->load->model('Modules_model');
		$setting['top_title_panel'] = "settings/top_title_panel";
		$setting['js'] = "setting_custom_key_mapping";
		$data["list"] = $this->Modules_model->getCustomKeys($module_id);
		$this->load->view('header',$setting );
		$this->load->view('settings/custom_key_mapping', $data);
		$this->load->view('footer');
	}

	public function ajax_custom_key_update()
	{
		if ($this->input->post()) {
            $input = $this->input->post();
            $id = $input['id'];
            $value = $input['value'];
            $this->load->model('Modules_model');
            echo $this->Modules_model->update_custom_keys($id,$value);
            //echo $input['value'];
        }
        else
        {
            echo '';
        }
	}

	public function ajax_master_css()
	{
		if ($this->input->post()) {
            $input = $this->input->post();
            $id = $input['id'];
            $value = $input['value'];
            $this->load->model('Master_css_model');
            echo $this->Master_css_model->update_keys($id,$value);
            //echo $input['value'];
        }
        else
        {
            echo 'error';
        }
	}

	public function ajax_master_css_add()
	{
		if ($this->input->post()) {
            $input = $this->input->post()["data"];

            $this->load->model('Master_css_model');
            echo $this->Master_css_model->insert($input);
            //echo $input['value'];
        }
        else
        {
            echo 'error';
        }
	}

	public function master_css($id='')
	{
		$setting['page_title'] = "Master CSS";
		$setting['page_sub_title'] = "Add / Delete/ Edit";
		$this->load->model('Master_css_model');
		$setting['top_title_panel'] = "settings/top_title_panel";
		$setting['js'] = "setting_master_css";
		$data["list"] = $this->Master_css_model->getAll();
		$this->load->view('header',$setting );
		$this->load->view('settings/master_css', $data);
		$this->load->view('footer');
	}
}
