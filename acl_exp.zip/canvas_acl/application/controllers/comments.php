<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class comments extends CI_Controller {
     public function __construct() {
        parent::__construct();
        $this->load->model('comment_model');
        $this->load->library('form_validation');
        $this->Admin_model->verifyUser("All");
    }

    function index($campaign_id)
    {
        $settings['css'] = "comments_index";
        $settings['js'] = "comments_index";
        $settings['title'] = "comments List";
        // create array to store all comments ids
        $store_all_id = array();
        // get all parent comments ids by using news id
        $id_result = $this->comment_model->tree_all($campaign_id);
        // loop through all comments to save parent ids $store_all_id array
        foreach ($id_result as $comment_id) {
            array_push($store_all_id, $comment_id['parent_id']);
        }
        // return all hierarchical tree data from in_parent by sending
        //  initiate parameters 0 is the main parent,news id, all parent ids
        $this->load->model('Campaign_model');
        $settings['campaign_name'] = $this->Campaign_model->getCampaignsByID($campaign_id)[0]['campaign_name'];
        $data['comments']  =   $this->in_parent(0,$campaign_id, $store_all_id);
        $data['campaign_id'] = $campaign_id;

        $this->load->view('header', $settings);
        $this->load->view('comments/index', $data);
        $this->load->view('footer');
    }


    /* recursive function to loop
       through all comments and retrieve it
    */
    function in_parent($in_parent,$campaign_id,$store_all_id) {
        // this variable to save all concatenated html
        $html = "";
        // build hierarchy  html structure based on ul li (parent-child) nodes
        if (in_array($in_parent,$store_all_id)) {
            $result = $this->comment_model->tree_by_parent($campaign_id,$in_parent);
            $html .=  $in_parent == 0 ? "<div id='reader'><ol>" : "<ol>";
            foreach ($result as $re) {
                $acronym="";
                foreach(explode(' ', $re['name']) as $word) {$acronym .= mb_substr($word, 0, 1, 'utf-8');}
                $html .= " <li class='comment_box' id='comment_id_". $re['comment_id']."'>
                <div class='row'><div class='col-sm-1'><div class='round_circle'>".$acronym."</div></div>
            <div class='col-sm-9 ml-2'><div class='aut'>".$re['comment_name']."</div>
         
            <div class='comment-body'>".$re['comment_body']."</div>
            <div class='timestamp'>".date("F j, Y", $re['comment_created'])."</div>
            <a  href='#comment_form' class='reply' id='" . $re['comment_id'] . "'>Reply</a>";
            $html .= "</div></div></li>";
                $html .=$this->in_parent($re['comment_id'],$campaign_id, $store_all_id);
                
            }
            $html .=  "</ol>";
        }

        return $html;
    }

    function add_comment($campaign_id)
    {

        // get a post id based on news id
        //$data['news'] = $this->news_model->get_one($campaign_id);

        //set validation rules
        $this->form_validation->set_rules('comment_name', 'Name', 'required|trim|htmlspecialchars');
        //$this->form_validation->set_rules('comment_email', 'Email', 'required|valid_email|trim|htmlspecialchars');
        $this->form_validation->set_rules('comment_body', 'comment_body', 'required|trim|htmlspecialchars');
        if ($this->form_validation->run() == FALSE) {
            // if not valid load comments
            $this->session->set_flashdata('error_msg', validation_errors());
            redirect("comments/index/$campaign_id");
        } else {
            //if valid send comment to admin to tak approve
            $this->comment_model->add_new_comment();
            $this->session->set_flashdata('error_msg', 'Your comment is awaiting moderation.');
            redirect("comments/index/$campaign_id");
        }
    }
    
    public function t($value='')
    {
        print_r( $this->session->userdata("admin_id"))  ;
    }
}
