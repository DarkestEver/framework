<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class comp extends CI_Controller {
    public function __construct() {
       parent::__construct();
       $this->Admin_model->verifyUser("LCM");
    }

    public function index() {
        
        $this->load->model('Modules_model');
        $data["modules"] = $this->Modules_model->getDraggableModules();
        $data["modules_category"] = $this->Modules_model->getModulesCategory();
        $this->load->model('Template_model');
        
        $settings['css'] = "template";
        $settings['js'] = "comp_save";
        
        $this->load->view('header', $settings);
        $this->load->view('comp/index', $data);
        $this->load->view('footer', $settings);
    }

 
}