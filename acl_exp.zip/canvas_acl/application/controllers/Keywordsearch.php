<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keywordsearch extends CI_Controller {

	public function index()
	{
		if ($this->Admin_model->verifyUser("All")) {
            // Breadcrumb
            $crumb = new crumb();
            $crumb->label = 'Search Keyword';
            $crumb->classname = 'title active';
            $crumb->url = '';
            $bc = new Breadcrumb();
            $bc->setCrumbs(array($crumb));
            $settings['breadcrumb'] = $bc; // $this->load->view('view_breadcrumb', NULL, TRUE);
		    $settings['sidebar'] = 'keywordsearch';
            $settings['js'] = 'keywordsearch_index';
            

            $this->load->view('header', $settings);
		$this->load->view('keywordsearch/index');
		$this->load->view('footer');
		}
	}


      

    // Functions
    public function search() {
        if ($this->input->post()) {
            $postData = $this->input->post();
            $draw = $postData['draw'];
            $start = $postData['start'];
            $length = $postData['length'];
            if (!isset($postData["keyword"]) || empty($postData["keyword"])) {
                $keyword = "";
            } else {
                $keyword = strip_tags($postData["keyword"]);
            }
             
            $this->load->model('Edms_saved_inputs_model');
            $result = $this->Edms_saved_inputs_model->search_keyword($keyword,$start,$length);
            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" => $result['totalcount'],
                "iTotalDisplayRecords" =>  $result['total_searched_count'],
                "aaData" => $result['data']
            );
            echo json_encode($response);
        }
    }

    public function search_promo() {
        if ($this->input->post()) {
            $postData = $this->input->post();
            $draw = $postData['draw'];
            $start = $postData['start'];
            $length = $postData['length'];
            if (!isset($postData["keyword"]) || empty($postData["keyword"])) {
                $keyword = "";
            } else {
                $keyword = strip_tags($postData["keyword"]);
            }
             
            $this->load->model('Edms_saved_inputs_model');
            $result = $this->Edms_saved_inputs_model->search_prmocode($keyword,$start,$length);
            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" => $result['totalcount'],
                "iTotalDisplayRecords" =>  $result['total_searched_count'],
                "aaData" => $result['data']
            );
            echo json_encode($response);
        }
    }

}
