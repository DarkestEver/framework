<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class template extends CI_Controller {
    public function __construct() {
       parent::__construct();
       $this->Admin_model->verifyUser("LCM");
    }

    public function index($campaign_id, $emd_id) {
        if ($emd_id=="") {
            return false;
        }
        $data['emd_id'] = $emd_id;
        $data['campaign_id'] = $campaign_id;
        $campaign_id = $this->db->escape(strip_tags($campaign_id));
        $emd_id = $this->db->escape(strip_tags($emd_id));
        $this->load->model('Edm_model');
        $edm_details = $this->Edm_model->getEmailByID($campaign_id, $emd_id);
        $data['edm_details'] = $edm_details;
        $this->load->model('Modules_model');
        $data["modules"] = $this->Modules_model->getDraggableModules();
        $data["modules_category"] = $this->Modules_model->getModulesCategory();
        $this->load->model('Template_model');
        $data['existing_modules']= $this->Template_model->getTemlateByID($campaign_id, $emd_id);
        $settings['title'] = $edm_details[0]['campaign_name'] . " : " . $edm_details[0]['email_name'] ;

        $settings['css'] = "template";
        $campaign_name= $edm_details[0]['campaign_name'];
          ;

        $edm_status =  $edm_details[0]['status'];
        $data['edm_status'] = $edm_status;
        if ( $edm_status  == 0 || $edm_status  == 1)
        {
            $settings['js'] = "template_save";
        }else
        {
            $settings['js'] = "template_published";
        }
        
        $this->load->view('header', $settings);
        $this->load->view('template/index', $data);
        $this->load->view('footer', $settings);
    }

    public function updateStatusTemplate($value='')
    {
        
        $data = $this->input->post('data');
        $edm_id =  $this->db->escape(strip_tags($data["edm_id"]));
        $campaign_id = $this->db->escape(strip_tags($data["campaign_id"]));
        $status = $this->db->escape(($data["status"]));
        $this->load->model('Edm_model');
        $this->Edm_model->updateStatus2($campaign_id,$edm_id, $status);
        if ($data["status"] = 2) {
            $this->edm_create_thumnail($data["edm_id"]);
        }
        return true;
    }

    public function delete_variation($id='', $t_id='') {
        $id = str_replace('remove_variation_', "", $id);
        $this->load->model('Template_variations_model');
        $rows = $this->Template_variations_model->deleteifnotone($id, $t_id);
        echo $rows;
    }
     public function saveTemplateVariation() {
        $this->load->model('Template_variations_model');
        $input = $this->input->post('data');
        $template_mods = $input['condition'];
        foreach($template_mods as $item) {
            if (!empty($item["t_condition_name"])) {
                $name = $this->db->escape(strip_tags($item["t_condition_name"]));
            } else {
                $name = "";
            }

            if (!empty($item["t_hide_or_show"])) {
                $show_or_hide = $this->db->escape(strip_tags($item["t_hide_or_show"]));
            } else {
                $show_or_hide = "''";
            }

            if (!empty($item["t_sending_de_variable"])) {
                $variable_name = $this->db->escape(strip_tags($item["t_sending_de_variable"]));
            } else {
                $variable_name = "''";
            }

            if (!empty($item["t_condition"])) {
                $conditions = $this->db->escape(strip_tags($item["t_condition"]));
            } else {
                $conditions = "''";
            }

            if (!empty($item["t_id"])) {
                $t_id = $this->db->escape(strip_tags($item["t_id"]));
            } else {
                $t_id = "''";
            }

            if (!empty($item["t_hide_show_value"])) {
                $t_hide_show_value = $this->db->escape(strip_tags($item["t_hide_show_value"]));
            } else {
                $t_hide_show_value = "''";
            }

            if (!empty($item["edm_id"])) {
                $edm_id = $this->db->escape(strip_tags($item["edm_id"]));
            } else {
                $edm_id = "''";
            }

            if (!empty($item["campaign_id"])) {
                $campaign_id = $this->db->escape(strip_tags($item["campaign_id"]));
            } else {
                $campaign_id = "''";
            }

            $id = $this->Template_variations_model->save($name, $show_or_hide, $variable_name, $conditions, $t_id, $t_hide_show_value, $edm_id, $campaign_id);
            if ($id==false) {
                echo false;
            }
            else
            echo $id;
            
        }
    }

    public function getTemplateVariationByTemplateId($campaign_id, $edm_id, $id) {
        $this->load->model('Template_variations_model');
        $data = $this->Template_variations_model->getByTemplate_id($campaign_id, $edm_id, $id);
        echo json_encode($data);
    }

    public function getDraggedModuleTemplateId() {
        if ($this->input->post()) {
            $input = $this->input->post('data');
            $item = json_decode($input, TRUE);
            $this->load->model('Template_model');
            $edm_id = $this->db->escape(strip_tags($item[0]["emd_id"]));
            $mod = $this->db->escape(strip_tags($item[0]["mod"]));
            $campaign_id = $this->db->escape(strip_tags($item[0]["campaign_id"]));
            $data['t_id'] =  $this->Template_model->saveTempate($campaign_id, $edm_id, $mod, '0', '0');
            echo json_encode([$data]);
        }
    }

     public function saveTemplates() {
        $this->load->model('Template_model');
        $input = $this->input->post('data');
        $template_mods = json_decode($input, TRUE);
        $emd_id = "";
        foreach($template_mods as $item) {
            $mods = [];
            $position = $this->db->escape(strip_tags($item["position"]));
            $emd_id =  $this->db->escape(strip_tags($item["emd_id"]));
            $mod = $this->db->escape(strip_tags($item["mod"]));
            $t_id = $this->db->escape(strip_tags($item["t_id"]));
            $campaign_id = $this->db->escape(strip_tags($item["campaign_id"]));
            $this->Template_model->updateTempate($campaign_id, $emd_id, $mod, $position, $t_id);
        }
        //$this->Template_model->edms_saved_inputs($emd_id);
        $this->load->model('Edm_model');
        $this->Edm_model->updateStatus($emd_id, '1'); # 1 saved template #null for blank
    }

      public function edm_create_thumnail($edm='')
    {
        
            $this->load->model('Template_model');
            $data = $this->Template_model->getByID($edm);
            $height = 0;
            $img_array = [];
            foreach ($data as $key => $value) {
                $a_img = site_url().'resources/img/module_icon/'. $value['module_key'] .'.png';
                list($a_width, $a_height, $a_type, $a_attr) = getimagesize($a_img); 
                $img_array[] =  array('url' => $a_img, 'y-axis' => $height, 'w' =>$a_width, 'h' =>  $a_height);
                $height = $a_height + $height;
            }
           // print_r($img_array);  die;
    
            $dest_image = imagecreatetruecolor(600, $height);
            imagesavealpha($dest_image, true);
            $trans_background = imagecolorallocatealpha($dest_image, 0, 0, 0, 127);
            
            imagefill($dest_image, 0, 0, $trans_background);

            foreach ($img_array as $key => $value) {
                 $a = imagecreatefrompng(  $value['url'] );
                 imagecopy($dest_image, $a, 0, $value['y-axis'], 0, 0,$value['w'],$value['h']);
                 imagedestroy($a);
            }
           //send the appropriate headers and output the image in the browser
            //header('Content-Type: image/png');
            $edm_thum_path = FCPATH . "resources\img\\edm_thumnail\\". $edm .".png";
            imagepng($dest_image,$edm_thum_path);
            //destroy all the image resources to free up memory
            imagedestroy($dest_image);

    }

    public function deleteById($id) {
        //echo $id;
        $this->load->model('Template_model');
        $this->Template_model->deleteById($id);
        $this->load->model('Template_variations_model');
        $this->Template_variations_model->deleteById($id);
        return 1;
    }

}