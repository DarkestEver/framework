<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class email extends CI_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('Log_model');
       $this->load->helper('alert_message');
       $this->Admin_model->verifyUser("CT,LCM");
    }

    // Views
    public function index($campaign_id, $edm_id, $country, $language, $template="default") {
        $this->load->model('Html_email_template_model');
        $email_template = $this->Html_email_template_model->getByName($template);
        $email_template['js'] = "email_edit";
        $html_str =  $this->getEDMHTML($campaign_id, $edm_id, $country, $language) ;
        $email_template['html_str'] = $html_str;
        $this->load->view('email/index', $email_template);
    }

    // Functions
    public function search_email() {
        if ($this->input->post()) {
            $postData = $this->input->post();
            $draw = $postData['draw'];
            $start = $postData['start'];
            $length = $postData['length'];

            if (!isset($postData["emailname"]) || empty($postData["emailname"])) {
                $emailname = "";
            } else {
                $emailname = strip_tags($postData["emailname"]);
            }

            if (!isset($postData["categoryName"]) || empty($postData["categoryName"])) {
                $categoryName = "";
            } else {
                $categoryName = $this->db->escape(strip_tags($postData["categoryName"]));
            }

            if (!isset($postData["vertical"]) || empty($postData["vertical"])) {
                $vertical = "";
            } else {
                $vertical = $this->db->escape(strip_tags($postData["vertical"]));
            }

            if (!isset($postData["wheel"]) || empty($postData["wheel"])) {
                $wheel = "";
            } else {
                $wheel = $this->db->escape(strip_tags($postData["wheel"]));
            }

            $this->load->model('Edm_model');
            $totalEmails = $this->Edm_model->getTotalCount();
            $result = $this->Edm_model->searchAllEmail(); //$emailname, $categoryName, $vertical, $wheel, $start, $length);

            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" => $totalEmails,
                "iTotalDisplayRecords" => count($result),
                "aaData" => $result
            );
            echo json_encode($response);
        }
    }

    public function getDraggableModulesbyKey($value='') {
        $this->load->model('Modules_model');
        $data["modules"] = $this->Modules_model->getDraggableModulesbyKey($value);
    }

    public function ajax_updateStatusLocalizedEDM($value='')
    {
        $data = $this->input->post('data');
        $id = $this->db->escape(strip_tags($data["id"]));
        $status = $this->db->escape(($data["status"]));
        $this->load->model('Edm_model');
        $this->Edm_model->updateStatusLocalizedEDM($id, $status);
    }

    

    public function edit($campaign_id, $edm_id, $country, $language) {


        $this->load->model('Edm_model');
        $edm_details = $this->Edm_model->getEmailByID($campaign_id, $edm_id);
        $edm_status = $this->Edm_model->getLocalizedEmailStausByID($campaign_id, $edm_id, $country, $language);
        $view_data['campaign_id'] = $campaign_id;
        $view_data['edm_id'] = $edm_id;
        $view_data['country'] = $country;
        $view_data['language'] = $language;
        $view_data['subject_line'] = $this->Edm_model->getSubject($campaign_id, $edm_id, $country, $language, 'subject');
        $view_data['preheader'] = $this->Edm_model->getSubject($campaign_id, $edm_id, $country, $language,'preheader');
        //$view_data['preview_url'] = 'email/desktopPreview/'.$campaign_id."/".$edm_id."/".$country."/".$language;
  

        if ( sizeof($edm_status) == 0 ) {
            $error_message['error'] = "Localized Email Does Not Exits" . sizeof($edm_status);
            $this->load->view('header',$settings);
            $this->load->view('error', $error_message);
            $this->load->view('footer');
            return;
        }
        else
        {
            $view_data['edm_status'] = $edm_status[0]["status"];
            $view_data['edm_status_id'] = $edm_status[0]["id"];
            $view_data['update_version'] = $edm_status[0]["update_version"];
        }

        $status = $this->Edm_model->getEDMDByIDStatus($edm_id, $campaign_id);

        if ($status != "2") {
            $error_message['error'] = "Template is not create or in edit mode.";
            $settings['title'] = 'Template is not create or in edit mode.';
            $this->load->view('header',$settings);
            $this->load->view('error', $error_message);
            $this->load->view('footer');
            return;
        }

        if (!empty($_FILES['csv_file']['name']) && $this->input->post()) {
            $postData = $this->input->post();

            if (isset($postData["modal_country_code"]) && isset($postData["modal_edm_id"]) && isset($postData["modal_campaign_id"]) && isset($postData["modal_language_code"])) {
                if (!empty($postData["modal_country_code"])) {
                    $modal_country_code = $this->db->escape(strip_tags($postData["modal_country_code"]));
                } else {
                    $modal_country_code = "''";
                }

                if (!empty($postData["modal_edm_id"])) {
                    $modal_edm_id = $this->db->escape(strip_tags($postData["modal_edm_id"]));
                } else {
                    $modal_edm_id = "''";
                }

                if (!empty($postData["modal_campaign_id"])) {
                    $modal_campaign_id = $this->db->escape(strip_tags($postData["modal_campaign_id"]));
                } else {
                    $modal_campaign_id ="NULL";
                }

                if (!empty($postData["modal_language_code"])) {
                    $modal_language_code = $this->db->escape(strip_tags($postData["modal_language_code"]));
                } else {
                    $modal_language_code = "''";
                }

                $this->do_csv_de_upload($modal_campaign_id, $modal_edm_id, $modal_country_code, $modal_language_code);
            } else {
                echo 'error';
            }
        }

       

        $view_data['language_code'] = $language;
        $view_data['country_code'] = $country;
        $view_data['edm_details'] =$edm_details;
        $this->load->model('Edms_saved_inputs_model');
        $this->load->model('Edms_module_elements_model');
        $this->load->model('Template_model');
        $html_str = "";
        $modules = $this->Template_model->getTemlateByID($campaign_id, $edm_id);
        //var_dump($modules); die;

        foreach ($modules as $key => $value) {
            $section_module_key = $value['t_id'];
            $text =  $value['module_html'];
            $text = str_replace("__dynamicid__", $section_module_key. "_", $text);
            $elements = $this->Edms_module_elements_model->getModuleElementsById($value['module_id']);
            foreach ($elements as $ele => $ele_value) {
               $section_module = $section_module_key. "_" .$ele_value['elements'];
               $data = $this->Edms_saved_inputs_model->getSavedInputValuesByKey($section_module, $country, $language, $edm_id, $campaign_id);
               if (count($data) > 0) {
                   $title = $data[0]['title'];
                   $alias = $data[0]['alias'];
                   $link = $data[0]['link'];
                   $href = $data[0]['href'];

                   $text = str_replace($section_module. "_" ."alias", $alias, $text);
                   $text = str_replace($section_module. "_" ."title", $title, $text);
                   $text = str_replace($section_module. "_" ."link", $link, $text);
                   $text = str_replace($section_module. "_" ."href", $href, $text);
                }
            }
            $html_str = $html_str .$text;
        }

        $this->load->helper("master_css_helper");
        $html_str = apply_master_css($html_str);
        $view_data['html_str'] =$html_str;
        $settings['title'] = $edm_details[0]['campaign_name'] . " : " . $edm_details[0]['email_name'] ;

        if ($edm_status[0]["status"] == 0)
        {
            $settings['js'] = "email_edit";
        }
        else
        {
            $settings['js'] = "email_edit_locked";
        }
   
        
        $this->load->view('header', $settings);
        $this->load->view('email/edit', $view_data);
        $this->load->view('footer');
    }

    public function getSavedInputValuesByKey($section_module, $country, $language, $edm_id, $campaign_id) {
        $view_data = [];
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getSavedInputValuesByKey($section_module, $country, $language, $edm_id, $campaign_id);
        $template_id  = $data[0]['template_id'];
        $this->load->model('Template_variations_model');
        $variation = $this->Template_variations_model->getByTemplate_id($campaign_id, $edm_id, $template_id);
        $view_data['data'] = $data;
        $view_data['variation'] = $variation;
        echo json_encode($view_data);
    }

    public function getTemplateVariationByVariationId($value, $country_code, $language_code, $edm_id) {
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getByVaration_id($value, $country_code, $language_code, $edm_id);
        echo json_encode($data);
    }


    public function getVariationById($id) {
        $this->load->model('Template_variations_model');
        $data = $this->Template_variations_model->getById($id);
    }

    public function do_upload($country_code, $language_code, $section_key, $variation_id, $edm_id, $campaign_id) {
        $is_upload_sfmc = True;
        if (!empty($_FILES["file"]['name'])) {
            $config['upload_path']="./resources/uploads/";
            $config['allowed_types']='gif|jpg|png|jpeg';
            $this->load->library('upload', $config);

            if ($this->upload->do_upload("file")) {
                $data_save = array();
                $data =  $this->upload->data();
                return "'". site_url().'resources/uploads/'.$data['raw_name'].$data['file_ext']."'";
            } else {
                $this->upload->display_errors();
                return False;
            }
        } else {
            return False;
        }
    }

    function get_string_between($string, $start, $end) {
        $string = ' ' . $string;
        $ini = strpos($string, $start);
        if ($ini == 0) return '';
        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;
        return substr($string, $ini, $len);
    }

    public function edmsSavedInputValues() {
        $postData = $this->input->post();

        if (!isset($postData["section_key"]) || empty($postData["section_key"])) {
            $section_key = "''";
        } else {
            $section_key = $this->db->escape(strip_tags($postData["section_key"]));
        }

        if (!isset($postData["section_module_type"]) || empty($postData["section_module_type"])) {
            $module_type = "''";
        } else {
            $module_type = $this->db->escape(strip_tags($postData["section_module_type"]));
        }

        if (!isset($postData["hidden_country"]) || empty($postData["hidden_country"])) {
            $country_code = "''";
        } else {
            $country_code = $this->db->escape(strip_tags($postData["hidden_country"]));
        }

        if (!isset($postData["hidden_language"]) || empty($postData["hidden_language"])) {
            $language_code = "''";
        } else {
            $language_code = $this->db->escape(strip_tags($postData["hidden_language"]));
        }

        if (!isset($postData["variation_id"]) || empty($postData["variation_id"])) {
            $variation_id = "''";
        } else {
            $variation_id = $this->db->escape(strip_tags($postData["variation_id"]));
        }

        $variation_id = str_replace("tab_", "", $variation_id);
        if (!isset($postData["editable_section_start_ampscript"]) || empty($postData["editable_section_start_ampscript"])) {
            $start_ampscript = "''";
        } else {
            $start_ampscript = $this->db->escape(strip_tags($postData["editable_section_start_ampscript"]));
        }

        if (!isset($postData["editable_section_title"]) || empty($postData["editable_section_title"])) {
            $title = "''";
        } else {
            $title = $this->db->escape($postData["editable_section_title"]);
        }

        if (!isset($postData["editable_section_redirect_link"]) || empty($postData["editable_section_redirect_link"])) {
            $link = "''";
        } else {
            $link = $this->db->escape($postData["editable_section_redirect_link"]);
        }

        if (!isset($postData["editable_section_alias"]) || empty($postData["editable_section_alias"])) {
            $alias = "''";
        } else {
            $alias = $this->db->escape($postData["editable_section_alias"]);
        }

        if (!isset($postData["editable_section_end_ampscript"]) || empty($postData["editable_section_end_ampscript"])) {
            $end_ampscript = "''";
        } else {
            $end_ampscript = $this->db->escape($postData["editable_section_end_ampscript"]);
        }

        if (!isset($postData["hidden_emd_id"]) || empty($postData["hidden_emd_id"])) {
            $edm_id = "''";
        } else {
            $edm_id = $this->db->escape(strip_tags($postData["hidden_emd_id"]));
        }

        if (!isset($postData["hidden_campaign_id"]) || empty($postData["hidden_campaign_id"])) {
            $campaign_id = "''";
        } else {
            $campaign_id = $this->db->escape(strip_tags($postData["hidden_campaign_id"]));
        }

        $this->load->model('Edms_saved_inputs_model');

        if (! empty($_FILES["file"]['name'])) {
            $imagesrc = $this->do_upload($country_code, $language_code, $section_key, $variation_id, $edm_id, $campaign_id);
        } elseif (isset($postData["editable_section_imagesrc"]) && !empty($postData["editable_section_imagesrc"]))  {
            $imagesrc = $this->db->escape(strip_tags($postData["editable_section_imagesrc"]));
            $key_id = $this->Edms_saved_inputs_model->get_id($country_code, $language_code, $section_key, $variation_id, $edm_id, $campaign_id);
            $this->load->model('Asset_model');
            $this->Asset_model->updateNotUse($key_id, $imagesrc);
            //echo $imagesrc; die;
        } else {
            $imagesrc = "''";
        }
        //$this->load->model('Edms_saved_inputs_model');
        $this->Edms_saved_inputs_model->setSavedInputValuesByKey($start_ampscript, $imagesrc, $title, $link, $alias, $end_ampscript, $country_code, $language_code, $section_key, $variation_id, $edm_id, $campaign_id);

        $data["key_name"] =  str_replace("'", "", $section_key);
        $data["editable_type"] = str_replace("'", "", $module_type);
        $data["title"] = str_replace("'", "", $title);
        $data["href"] = str_replace("'", "", $imagesrc);
        $data["editable_type"] = str_replace("'", "", $module_type);
        echo json_encode([$data]);
    }

   

    public function getEDMHTML($campaign_id, $edm_id, $country, $language)
    {
        $this->load->model('Edm_model');
        $this->load->model('Edms_saved_inputs_model');
        $this->load->model('Edms_module_elements_model');
        $this->load->model('Template_model');
        $html_str = "";
        $modules = $this->Template_model->getTemlateByID($campaign_id, $edm_id);
        //var_dump($modules); die;
        foreach ($modules as $key => $value) {
            $section_module_key =  $value['t_id'];
            $text =  $value['module_html'];
            $text = str_replace("__dynamicid__", $section_module_key. "_", $text);
            $elements = $this->Edms_module_elements_model->getModuleElementsById($value['module_id']);
            foreach ($elements as $ele => $ele_value) {
                $section_module = $section_module_key. "_" .$ele_value['elements'];
                $data = $this->Edms_saved_inputs_model->getSavedInputValuesByKey($section_module, $country, $language, $edm_id, $campaign_id);
                if (count($data) > 0) {
                    $title = $data[0]['title'];
                    $alias = $data[0]['alias'];
                    $link = $data[0]['link'];
                    $href = $data[0]['href'];
                    if ($ele_value['elements'] != "code_block") {
                        $text = str_replace($section_module. "_" ."alias", $alias, $text);
                        $text = str_replace($section_module. "_" ."title", $title, $text);
                        $text = str_replace($section_module. "_" ."link", $link, $text);
                        $text = str_replace($section_module. "_" ."href", $href, $text);
                    } else {
                        $text = "<p>".$data[0]['title']."</p>";
                    }
                }
            }

            $html_str = $html_str .$text;
        }
        return $html_str;
    }

    public function desktopPreview($campaign_id, $edm_id, $country, $language,$template="default" ) {
        $this->load->model('Edm_model');
        $this->load->helper('master_css_helper');
        $status = $this->Edm_model->getEDMDByIDStatus($edm_id, $campaign_id);
        if ($status == "0") {
            return false;
        }    
        $html_str = $this->getEDMHTML($campaign_id, $edm_id, $country, $language);
        $this->load->model('Html_email_template_model');
        $email_template = $this->Html_email_template_model->getByName($template);
        echo $email_template['head_tag'];
        echo "<style>.highlight_selected { font-weight: bold; -webkit-box-shadow: 0 0 0 99999px rgba(0, 0, 0, .8); box-shadow: 0 0 0 99999px rgba(0, 0, 0, .8); position: relative; z-index: 9999; transition: all 0.5s ease; }</style>";
        echo $email_template['body_start_tag'];
        echo $email_template['body_content'];
        echo apply_master_css($html_str);
        echo $email_template['body_end_tag'];
    }

    public function preview($campaign_id, $edm_id, $country, $language) {
        $view_data['language'] = $language;
        $view_data['country'] = $country;
        $view_data['campaign_id'] = $campaign_id;
        $view_data['edm_id'] = $edm_id;
        $this->load->model('Edm_model');
        $edm_details = $this->Edm_model->getEmailByID($campaign_id, $edm_id);
        $view_data['edm_details'] = $edm_details;
        $setting['title'] = 'Preview - '. $edm_details[0]['campaign_name'] . " : " . $edm_details[0]['email_name'] . '('.$country.'-'.$language.')';
        $setting['js'] = "generatePreview";
        $view_data['preview_url'] = 'email/desktopPreview/'.$campaign_id."/".$edm_id."/".$country."/".$language;

        $this->load->view('header', $setting);
        $this->load->view('email/preview', $view_data);
        $this->load->view('footer', $setting);
    }

    public function preview_download($campaign_id, $edm_id, $country, $language) {
        $file_name = 'preview_'.$country.$language.date('Ymd').'.html';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$file_name");
        header('Content-type: text/html');
        $this->desktopPreview($campaign_id, $edm_id, $country, $language);
    }



    public function export_input_file($campaign_id,$edm_id,$country,$language)
    {
        $file_name = 'Translation_DE_Import_File'.date('Ymd').'.csv';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$file_name");
        header("Content-Type: application/csv;");
        $file = fopen('php://output', 'w');
        
        $header = array("ID", "Module - Variation - Input",  "Value");
        fputcsv($file, $header);
        
        $this->load->model('Template_model');
        $this->load->model('Edms_saved_inputs_model');
        $this->load->model('Edms_module_elements_model');
        $modules = $this->Template_model->getTemlatewithvariation($campaign_id,$edm_id);
        //var_dump($modules); die;
        foreach ($modules as $key => $value) {
                   $variation_id = $value['variation_id'];
                   $section_module_key =  $value['t_id'];
                   $text =  $value['module_html'] ;
                   $text = str_replace("__dynamicid__", $section_module_key. "_", $text);
                   $elements = $this->Edms_module_elements_model->getModuleElementsById($value['module_id']);
                   foreach ($elements as $ele => $ele_value)
                   {
                       $section_module = $section_module_key. "_" .$ele_value['elements'];
                       $data = $this->Edms_saved_inputs_model->getSavedInputValuesByVariation($variation_id,$section_module,$country, $language,$edm_id,$campaign_id);
                       if (count($data) > 0)
                       {
                          // $csv_array = array();
                           $title = $data[0]['title'];
                           $alias = $data[0]['alias'];
                           $link = $data[0]['link'];
                           $href = $data[0]['href'];
                           $key_id = $data[0]['id'];
                           
                           $module_name = $value['module_name'] ." - ". $value['variation_name']." - ". $ele_value['elements'];
                           $editable_type = $data[0]['editable_type'];
                           if ($editable_type == "paragraph")
                           {    fputcsv($file, array($key_id."_".'title', $module_name,$title));
                           }elseif ( $editable_type == 'image_withoutlink' ) {
                            fputcsv($file, array($key_id."_".'href',$module_name,$href));
                            fputcsv($file, array($key_id."_".'title',$module_name,$title));
                            fputcsv($file, array($key_id."_".'alias',$module_name,$alias));
                           }elseif ($editable_type == 'heading' ) {
                            fputcsv($file, array($key_id."_".'title',$module_name,$title));
                           }elseif ($editable_type == "cta" ) {
                            fputcsv($file, array($key_id."_".'href',$module_name,$href));
                            fputcsv($file, array($key_id."_".'title',$module_name,$title));
                            fputcsv($file, array($key_id."_".'alias',$module_name,$alias));
                           }
                           elseif ($editable_type == 'image_withlink' ) {
                            fputcsv($file, array($key_id."_".'href',$module_name,$href));
                            fputcsv($file, array($key_id."_".'title',$module_name,$title));
                            fputcsv($file, array($key_id."_".'alias',$module_name,$alias));
                            fputcsv($file, array($key_id."_".'link',$module_name,$link));
                           }
                        }
                    }
                }
           
        fclose($file);
    }

   public function do_csv_de_upload($campaign_id,$edm_id,$country_code,$language_code) {
        $this->load->helper('status');
        $config['upload_path'] = "./resources/uploads/de_upload";
        $config['allowed_types'] = 'csv';
        $this->load->library('upload',$config);
        if($this->upload->do_upload('csv_file')) {
            $this->load->model('Edms_saved_inputs_model');
            $data = $this->upload->data();
            $file_path = $data['full_path'];
            $file = fopen($file_path, 'r');
            $loop_count = 0;
            while (($line = fgetcsv($file)) !== FALSE) {
                if ($loop_count !=0)
                {
                     $key_value = $line[2];
                     
                     $key_str = $line[0];
                     $key_str = explode("_", $key_str);
                     $key_id = $key_str[0];
                     $col_name = $key_str[1];
                     //$col_name = edm_input_col_name($col_name);
                     if (!empty($key_value)) {$key_value = $this->db->escape(strip_tags($key_value));}else{$key_value = "''";};
                    $error = $this->Edms_saved_inputs_model->file_upload_update($campaign_id,$edm_id,$country_code,$language_code, $key_id, $col_name, $key_value);
                     echo $error;
                 }
                 $loop_count ++;
            }
            fclose($file);
            
        }
        else
        {
             echo $this->upload->display_errors();
             
        }
        
    }

    public function get_ampscript_with_content_block($campaign_id, $edm_id) {
        $this->load->model('Template_model');
        echo '%%[';
        echo '</br>';
        echo 'SET @sending_de = "sending_de";';
        echo '</br>';
        echo 'SET @translation_de = "automation_translation_de";';
        echo '</br>';
        echo 'SET @config_de = "config_de";';
        echo '</br>';
        echo 'SET @edm_id = "'.$edm_id.'";';
        echo '</br>';
        echo 'SET @country_code = AttributeValue("country_id");';
        echo '</br>';
        echo 'SET @language_code = AttributeValue("langauage_id");';
        echo '</br>';
        echo ']%%';
        echo '</br>';
        echo '</br>';
        echo '</br>';
        $key_prefix = "";
        $module_variation = "";
        $this->load->model('Template_variations_model');
        $modules = $this->Template_model->getTemlateByID($campaign_id, $edm_id);
        foreach ($modules as $key => $value) {
           $text =  $value['content_block'];
           echo $value['start_ampscript'];
           $t_id =  $value['id'];
           echo '%%[ </br> SET @t_id = "'. $t_id . '"';
           echo '</br>';
           $varations = $this->Template_variations_model->getByTemplate_id($campaign_id, $edm_id, $t_id);
           foreach ($varations as $v_key => $v_value) {
                if (strtolower($v_value['name']) == 'default') {
                    echo 'SET @module_variation = "'. $v_value['id'] . '" ';
                    echo '</br>';
                } else {
                    echo 'if AttributeValue("'.  $v_value['variable_name']. '") ' . $v_value['conditions'] . ' "' . $v_value['hide_show_value'] . '" then ';
                    echo 'SET @module_variation = "'. $v_value['id'] . '" ';
                    echo  'Endif ';
                    echo '</br>';
                }
            }
            echo "]%%";
            echo('</br>');
            echo  '%%=ContentBlockbyKey("'.$text.'")=%%';

            echo $value['end_ampscript'];
            echo('</br> </br>');
        }
    }

   
    public function get_ampscript2($campaign_id,$edm_id)
    {
        $file_name = 'ampscript_'.$campaign_id.$edm_id.date('Ymd').'.html';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$file_name");
        header('Content-type: text/html');
        
        $this->load->helper('preview_helper');
        echo get_ampscript2($campaign_id,$edm_id);
    }

    public function getTaggedPromocode($value, $country_code, $language_code, $edm_id) {
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getTaggedPromocode($value, $country_code, $language_code, $edm_id);
        echo json_encode($data);
    }

    public function getListOfTaggedPromocode ($country_code, $language_code, $edm_id)
    {
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getListOfTaggedPromocode( $country_code, $language_code, $edm_id);
        $json_array["data"] = $data;
        echo json_encode($json_array);
    }
    public function setTaggedPromocode()
    {
        $json = json_decode(file_get_contents("php://input"));

        if (!isset($json->promocode) || empty($json->promocode)) {
            $promocode = "''";
        } else {
        $promocode = $this->db->escape(strip_tags($json->promocode));
        }
        if (!isset($json->promocode_startdate) || empty($json->promocode_startdate)) {
            $promocode_startdate = "''";
        } else {
            $promocode_startdate = $this->db->escape(strip_tags($json->promocode_startdate));
          //  $promocode_startdate = date('Y-m-d',strtotime($json->$promocode_startdate));
        }
       
        if (!isset($json->promocode_enddate) || empty($json->promocode_enddate)) {
            $promocode_enddate = "''";
        } else {
        $promocode_enddate = $this->db->escape(strip_tags($json->promocode_enddate));
        //$promocode_enddate = date('Y-m-d',strtotime($json->$promocode_enddate));
        }

        if (!isset($json->tab_id) || empty($json->tab_id)) {
            $tab_id = "''";
        } else {
        $tab_id = $this->db->escape(strip_tags($json->tab_id));
        }

        if (!isset($json->country_code) || empty($json->country_code)) {
            $country_code = "''";
        } else {
        $country_code = $this->db->escape(strip_tags($json->country_code));
        }

        if (!isset($json->language_code) || empty($json->language_code)) {
            $language_code = "''";
        } else {
        $language_code = $this->db->escape(strip_tags($json->language_code));
        }
            
        if (!isset($json->edm_id) || empty($json->edm_id)) {
            $edm_id = "''";
        } else {
        $edm_id = $this->db->escape(strip_tags($json->edm_id));
        }
            
        if (!isset($json->campaign_id) || empty($json->campaign_id)) {
            $campaign_id = "''";
        } else {
        $campaign_id = $this->db->escape(strip_tags($json->campaign_id));
        }

        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->setTaggedPromocode($tab_id,$country_code,$language_code,$edm_id,$promocode,$promocode_startdate,$promocode_enddate);
        return 1;
    }            

    public function getModuleVersionContentHistory($campaign_id,$edm_id,$country,$language, $tab_id,$key_name)
    {
        if (!isset($campaign_id) || empty($campaign_id)) { return 0; } else {
            $campaign_id = $this->db->escape(strip_tags($campaign_id)); }
         if (!isset($edm_id) || empty($edm_id)) { return 0; } else {
            $edm_id = $this->db->escape(strip_tags($edm_id)); }
         if (!isset($country) || empty($country)) { return 0; } else {
            $country = $this->db->escape(strip_tags($country)); }
         if (!isset($language) || empty($language)) { return 0; } else {
            $language = $this->db->escape(strip_tags($language)); }
         if (!isset($tab_id) || empty($tab_id)) { return 0; } else {
            $tab_id = $this->db->escape(strip_tags($tab_id)); }
        if (!isset($key_name) || empty($key_name)) { return 0; } else {
            $key_name = $this->db->escape(strip_tags($key_name)); }
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getModuleVersionContentHistory($campaign_id,$edm_id,$country,$language, $tab_id,$key_name);
        $json_array["data"] = $data;
        echo json_encode($json_array);
    }

  

    public function ajax_save($key_name,$campaign_id,$edm_id,$country,$language)
    {
        if ($this->input->post()) {
            $input = $this->input->post();
            //$key_name = $this->db->escape(strip_tags($key_name));
            $campaign_id = $this->db->escape(strip_tags($campaign_id));
            $edm_id = $this->db->escape(strip_tags($edm_id));
            $country = $this->db->escape(strip_tags($country));
            $language = $this->db->escape(strip_tags($language));
            $title = $this->db->escape(strip_tags($input['value']));
            $this->load->model('Edms_saved_inputs_model');
            $this->Edms_saved_inputs_model->updateSubject($title, $key_name,$campaign_id,$edm_id,$country,$language);
            echo $input['value'];
        }
        else
        {
            echo '';
        }
    }

    public function create_email_copy()
    {
        if ($this->input->post()) {
            $postData = $this->input->post("data");   
            $campaign_id = $this->db->escape(strip_tags($postData["campaign_id"]));
            $new_campaign_id = $campaign_id;
            $edm_id = $this->db->escape(strip_tags($postData["edm_id"]));
            $email_name = $this->db->escape(strip_tags($postData["new_email_mail"]));
            $this->load->model('Edm_copy_model');
            $new_edm_id = $this->Edm_copy_model->create( $campaign_id,$edm_id,$email_name,$new_campaign_id);
            echo $new_edm_id;
            

        }
        else
        {
            echo 'Something went wrong. Please try again.';
        }
    }
}
