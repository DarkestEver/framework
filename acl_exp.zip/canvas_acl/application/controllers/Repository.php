<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Repository extends CI_Controller {

	public function index( $campaign_id_url="")
	{
		if ($this->Admin_model->verifyUser("All")) {
                  $this->load->model("repository_email_preview_html_model");
                  $data = array();
                  $settings['js'] = "repository_index";
                  $settings['title'] = "Repository";
                  $settings['sidebar_panel'] = "sidebar";
                  
                  

                  $this->load->model("Campaign_model");
                  
                  if (!empty($campaign_id_url)) {
                        if ($this->input->post()) {
                              $postData = $this->input->post();
                              if (isset($postData["delete_action"]) || !empty($postData["delete_action"])) {
                                  $delete_id =  $this->db->escape(strip_tags($postData["delete_id"]));
                                  $this->repository_email_preview_html_model->deleteById($delete_id);
                              }
                              
                              if (isset($postData["add"]) || !empty($postData["add"])) {
                                   
                                    
                                    $html = "";
                                    if (!isset($postData["text"]) || empty($postData["text"])) {
                                        return false;
                                    } else {
                                        $text = $this->db->escape(($postData["text"]));
                                    }
                                    if (!isset($postData["email_id"]) || empty($postData["email_id"])) {
                                       return false;
                                    } else {
                                        $email_id = $this->db->escape(strip_tags($postData["email_id"]));
                                    }
                                    if (!isset($postData["country_code"]) || empty($postData["country_code"])) {
                                       return false;
                                    } else {
                                        $country_code = $this->db->escape(strip_tags($postData["country_code"]));
                                    }
                                    if (!isset($postData["notes"]) || empty($postData["notes"])) {
                                       $notes = "";
                                    } else {
                                        $notes = $this->db->escape(strip_tags($postData["notes"]));
                                    }
                                    if (isset($postData["type1"]) || !empty($postData["type1"])) {
                                          if ($postData["type1"] == "link")
                                          {
                                                try {
                                                      $c = curl_init($postData["text"]); 
                                                      curl_setopt($c, CURLOPT_RETURNTRANSFER, 1); 
                                                      $html  = curl_exec($c); curl_close($c); 
                                                      $html =  $this->db->escape($html);
                                                } catch (Exception $e) {
                                                      return false;
                                                }
                                                
                                          }
                                          if ($postData["type1"] == "html")
                                          {
                                                $html = $text;
                                          }
                                           $this->repository_email_preview_html_model->insert($campaign_id_url,$email_id,$country_code, $notes, $html);
                                    }
                              }
                        }
                        $settings['campaign_id_url'] = $campaign_id_url;
                        $campaign_name = $this->Campaign_model->getCampaignsByID($campaign_id_url);
                        if (sizeof($campaign_name) > 0) {
                              $settings['campaign_name'] = $campaign_name[0]['campaign_name'];
                              $data = $this->repository_email_preview_html_model->getByCampaignId($campaign_id_url);
                              
                        }else {
                              $data["heading"] = "Campaign does not exits";
                              $data["message"] = "Select campagin from folder";
                              $this->load->view('header');
                              $this->load->view('errors/html/error_404',$data);
                              $this->load->view('footer', $settings);     
                        }

                        
                        $this->load->model('Edm_model');
                        $data['edms'] = $this->Edm_model->getEDMDByCampaignID($campaign_id_url);
                        $rec = $this->repository_email_preview_html_model->getByCampaignId($campaign_id_url);
                        if (sizeof( $rec) > 0) {
                              $data["data"] = $rec;
                        }
                  }
                  $this->load->model('Campaign_model');
                  $data['countries'] = $this->Campaign_model->getCountries();
                  
                  $this->load->view('header', $settings);
                  $this->load->view('Repository/index',$data);
                  $this->load->view('footer', $settings);
                      
            }
	}

      public function view( $id="")
      {
            $this->load->model("repository_email_preview_html_model");
            $data = $this->repository_email_preview_html_model->getById($id);
            echo $data["html"];
           

      }
}

