<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Html_email_template_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                
        }

        public function getByName($email_template_name='')
        {
            $sql = "SELECT * FROM  html_email_template where  name =  '".$email_template_name."';" ;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array()[0];
                    } else {
                        return array();
                    }
        }
}