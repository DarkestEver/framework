<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_credentials_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getAllAPIs()
        {
            $sql = "SELECT * FROM api_credentials ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function get_default()
        {
            $sql = "SELECT * FROM api_credentials where isdefault = 1;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array()[0];
                    } else {
                        return array();
                    }
        }
        public function set_token($id, $token_name)
        {
            $sql = "SELECT * FROM api_credentials where id = ".$id;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        $this->db->query("update api_credentials set last_token = '".$token_name."' where id = ".$id);
                        return true;
                    } else {
                        return False;
                    }
        }
        public function getAllAPIByName($api_name)
        {
            $sql = "SELECT * FROM api_credentials where api_name = ". $api_name .";";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }


        public function getAllAPIsById($api_id)
        {
            $sql = "SELECT * FROM api_credentials where id = ". $api_id .";";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function updateApi($postData=null, $action=null) {
            if ($action == "save") {
               // var_dump($postData); die;
                $error = 0;
                if (!isset($postData["api_name"]) || empty($postData["api_name"])) { $api_name = ""; } else { $api_name = $this->db->escape(strip_tags($postData["api_name"]));}
                if (!isset($postData["client_id"]) || empty($postData["client_id"])) { $client_id = ""; } else { $client_id = $this->db->escape(strip_tags($postData["client_id"]));}
                if (!isset($postData["client_secret"]) || empty($postData["client_secret"])) { $client_secret = ""; } else { $client_secret = $this->db->escape(strip_tags($postData["client_secret"]));}
                if (!isset($postData["auth_url"]) || empty($postData["auth_url"])) { $auth_url = ""; } else { $auth_url = $this->db->escape(strip_tags($postData["auth_url"]));}
                if (!isset($postData["rest_url"]) || empty($postData["rest_url"])) { $rest_url = ""; } else { $rest_url = $this->db->escape(strip_tags($postData["rest_url"]));}

                 $sql = "SELECT * FROM api_credentials WHERE api_name = ".$api_name; 
                        $query = $this->db->query($sql);
                        if ($query->num_rows() > 0) {
                            return False;
                        }
                        else {
                                $sql2 = "INSERT INTO api_credentials (api_name,client_id,client_secret,auth_url,rest_url) VALUES ($api_name,$client_id,$client_secret,$auth_url,$rest_url)";
                                $this->db->query($sql2);
                                $edm_id =  $this->db->insert_id();
                                return  $edm_id;
                        }
            }
            if ($action == "edit") {
                 $error = 0;
                if (!isset($postData["api_name"]) || empty($postData["api_name"])) { $api_name = ""; } else { $api_name = $this->db->escape(strip_tags($postData["api_name"]));}
                if (!isset($postData["client_id"]) || empty($postData["client_id"])) { $client_id = ""; } else { $client_id = $this->db->escape(strip_tags($postData["client_id"]));}
                if (!isset($postData["client_secret"]) || empty($postData["client_secret"])) { $client_secret = ""; } else { $client_secret = $this->db->escape(strip_tags($postData["client_secret"]));}
                if (!isset($postData["auth_url"]) || empty($postData["auth_url"])) { $auth_url = ""; } else { $auth_url = $this->db->escape(strip_tags($postData["auth_url"]));}
                if (!isset($postData["rest_url"]) || empty($postData["rest_url"])) { $rest_url = ""; } else { $rest_url = $this->db->escape(strip_tags($postData["rest_url"]));}

                 $sql = "SELECT * FROM api_credentials WHERE api_name = ".$api_name; 
                        $query = $this->db->query($sql);
                        if ($query->num_rows() > 0) {
                            $sql2 = "update api_credentials set client_id = $client_id,client_secret = $client_secret,auth_url = $auth_url ,rest_url = $rest_url where api_name =".$api_name." ;";
                            $this->db->query($sql2);
                            return TRUE;   
                        }
                        else
                        {
                            return False;
                        }
                        
            }
            if ($action == "delete") {
                $error = 0;
                if (!isset($postData["api_name"]) || empty($postData["api_name"])) { $api_name = ""; } else { $api_name = $this->db->escape(strip_tags($postData["api_name"]));}

                $sql = "delete FROM api_credentials WHERE api_name = ".$api_name;
                $query = $this->db->query($sql);
                return true;
            }


        }

    public function get_API_key_uploadeded($campaign_id, $emd_id)
    {
        $sql = " update edms_saved_inputs set api_key_uploadeded = 1, modifieddate = modifieddate where ec.edm_id = ". $emd_id ." and ec.campaign_id = ".$campaign_id ;
        $query = $this->db->query($sql);
    }

    public function get_API_image_uploadeded($id)
    {
        $sql = " update edms_saved_inputs set api_image_uploaded = 1, modifieddate = modifieddate where  id = ". $id ;
        $query = $this->db->query($sql);
    }

    public function set_api_one_time_folder($type, $folder_customer_key,$folder_name,$folder_id,$api_id, $parent_folder_id,$app_folder_id="")
    {
        $sql = "insert into api_folder (type, folder_customer_key,folder_name,folder_id,api_id, parent_folder_id, app_folder_id) values ('".$type ."','".$folder_customer_key ."','".$folder_name ."','".$folder_id ."','".$api_id ."','". $parent_folder_id . "','".$app_folder_id."')";
        $query = $this->db->query($sql);
    }

    public function get_default_canvas_app_folder_email()
    {
        $api_data = $this->get_default();
        $apo_id = $api_data['id'];
        $sql = "SELECT * FROM api_credentials where canvas_app_folder = 'canvas_app_folder' and type ='3';";
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0];
        } else {
            return array();
        }   
    }

    public function get_default_canvas_app_folder_data_extension()
    {
        $api_data = $this->get_default();
        $apo_id = $api_data['id'];
        $sql = "SELECT * FROM api_credentials where canvas_app_folder = 'canvas_app_folder' and type ='1';";
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0];
        } else {
            return array();
        }   
    }

    public function get_canvas_app_folder($app_folder_id,$type)
    {

        $sql = "SELECT * FROM api_folder where  type ='".$type."' and app_folder_id ='".$app_folder_id."';";
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            return $query->result_array()[0];
        } else {
            return false;
        }   
    }

    public function get_appfolders_api_by_fid($fid='')
    {
        
        $sql = "SELECT ap.*, f.parent_id, f.id as fid, f.f_name FROM  folders f  left JOIN `api_folder` ap on f.parent_id = ap.app_folder_id where f.id = " .$fid ;
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return false;
        }
    }

    public function get_apifolder_appfid($fid='')
    {
        
        $sql = "SELECT * FROM `api_folder`  where app_folder_id = " .$fid ;
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return false;
        }
    }


}