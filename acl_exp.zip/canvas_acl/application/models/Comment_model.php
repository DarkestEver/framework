<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class Comment_model extends CI_Model
{


    // get full tree comments based on news id
    function tree_all($campaign_id) {
        $result = $this->db->query("SELECT * FROM comment where campaign_id = $campaign_id");
        if ($result->num_rows() > 0) {
           $result = $result->result_array();
            foreach ($result as $row) {
                $data[] = $row;
            }
            return $data;
        }
        else {
            return array();
        }
    }

    // to get child comments by entry id and parent id and news id
    function tree_by_parent($campaign_id,$in_parent) {
        $result = $this->db->query("SELECT comment.*, admin.name FROM comment inner join admin on comment.created_by = admin.id where parent_id = $in_parent AND  campaign_id = $campaign_id");
        if ($result->num_rows() > 0) {
           $result = $result->result_array();
            foreach ($result as $row) {
                $data[] = $row;
            }
            return $data;
        }
        else {
            return array();
        }
    }

    // to insert comments
    function add_new_comment()
    {
        $this->db->set("campaign_id", $this->input->post('campaign_id'));
        $this->db->set("parent_id", $this->input->post('parent_id'));
        $this->db->set("comment_name", $this->input->post('comment_name'));
        $this->db->set("created_by", $this->session->userdata("admin_id"));
        $this->db->set("comment_body", $this->input->post('comment_body'));
        $this->db->set("comment_created", time());
        $this->db->insert('comment');
        return $this->input->post('parent_id');
    }


}

/* End of file comment_model.php */
