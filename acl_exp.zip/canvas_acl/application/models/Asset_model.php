<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Asset_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getAssestIDByFileExt($file_ext='')
        {
            $sql = "SELECT asset_type_id FROM  assest_type where   asset_name =  '".$file_ext."';" ;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array()[0]['asset_type_id'];
                    } else {
                        return array();
                    }
        }

        public function insert($data)
        {
            $this->db->where('key_id', $data['key_id']);
            $this->db->from('assest_upload');
            $num_rows=$this->db->count_all_results();
            if ($num_rows == 0) {
                $this->db->insert('assest_upload',$data);
            }
            else
            {
                $this->db->where('key_id', $data['key_id']);
                $this->db->update('assest_upload',$data);   
            }
            
        }


        public function updateNotUse($key_id,$local_url)
        {
            $this->db->where('key_id', $key_id);
            $this->db->where('local_url', $local_url);
            $this->db->update('assest_upload',array("sfmc_publishedURL"=>'NULL'));   
            
            
        }

}