<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Campaign_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function createCampaign($emailname="",$categoryName="",$vertical="",$market="",$wheel=""){
            $sql1 = "select * from campaigns where campaign_name =".$emailname;
            $query = $this->db->query($sql1);
            if ($query->num_rows() > 0) {
                return False;
            }
            else
            {
                $sql2 = "INSERT INTO campaigns (`campaign_name`,`category_name`,`vertical_name`,`market_name`,`wheels`) VALUES (".$emailname . "," . $categoryName . "," . $vertical . ",''," . $wheel.");";
                $this->db->query($sql2);
                $campaign_id =  $this->db->insert_id();
                /*foreach ($market as $key => $value) {
                    $sql = "insert into edm_countries (edm_id, country_id) values ('".$edm_id."','".$value."');";
                    $this->db->query($sql);
                }*/
                return $campaign_id;
            }
        }


        public function getCampaignsByFolderID($value)
        {
            $sql = "SELECT * FROM campaigns  where folder_id = ". $value;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getCampaignsByID($value)
        {
            $sql = "SELECT * FROM campaigns  where id = ". $value;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function getAllCampaigns()
        {
            $sql = "SELECT * FROM campaigns order by createddate desc";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getAllWheels()
        {
            $sql = "SELECT * FROM campaign_vertical_wheels";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getAllVertical()
        {
            $sql = "SELECT * FROM campaign_vertical";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getAllCategory()
        {
            $sql = "SELECT * FROM campaign_category";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function getCountries()
        {
            $sql = "SELECT * FROM countries ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

           public function getCampaignCount()
        {
            $sql = "SELECT count(1) as count FROM campaigns  ";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        $query =  $query->result_array();
                        return $query[0]['count'];
                    } else {
                        return array();
                    }
        }

        public function searchCampaign($email="",$category="", $vertical="",$wheels="",$offset=0,$limit =10)
        {
            $andchk =0;
            $sql = " from campaigns ";
            if ($category != '')
            {
                $where_chk = 1;
                $andchk = 1;
                $sql = $sql."  where  category_name =  ".$category;
            }

            if ($vertical != '')
            {
                $where_chk = 1;
                $andchk = 1;
                if ($andchk == 1)
                {
                    $sql = $sql. " and vertical_name =  ".$vertical;
                }
                else
                {
                   $sql = $sql. " where vertical_name =  ".$vertical;
                }
            }

            if ($wheels != '')
            {
                $where_chk = 1;
                $andchk = 1;

                if ($andchk == 1)
                {
                   $sql = $sql." and wheels =  ".$wheels;
                }
                else
                {
                   $sql = $sql. " where  wheels =  ".$wheels;
                }
            }

            if ($email != '')
            {
                $where_chk = 1;
                $email = " like '%".$email."%'";
               // $email = $this->db->escape($email);
                if ($andchk == 1)
                {

                     $sql = $sql. " and campaign_name ". $email;
                }
                else
                {
                     $sql = $sql. " where  campaign_name ".$email;
                }
            }

            $sql1 ="select count(1) as count ". $sql;
            $query_count = $this->db->query($sql1);
            $query_count =$query_count->result_array();
            $query_count = $query_count[0]['count'];
            $sql = "select * ". $sql . " order by createddate desc limit  ". $offset . " , ". $limit;
            $query = $this->db->query($sql);
            $result_array = [];
            $query =  $query->result_array();
            $result_array['data'] = $query;
            $result_array['count'] = $query_count;
            return $result_array;

        }

        public function getAllCampaignsByVNC($category_name  , $vertical_name  )
        {
            $sql = "SELECT * FROM campaigns where vertical_name = '" . $vertical_name . "' and  category_name = '" . $category_name. "' ;"  ;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getAllEMDByCampaignID($campaign_id ,$offset=0,$limit =10)
        {
            $sql = "SELECT edms.*, c.country_code, c.language_code,ec.localized_input_stutus as localized_status FROM edms inner join edm_countries ec on edms.id = ec.edm_id inner join countries c on c.id = ec.country_id where edms.campaign_id = " . $campaign_id  . " order by edms.id desc, modifieddate desc, createddate desc" ;
                    $query = $this->db->query($sql);

                        $query_count = $query->num_rows() ;
                        $query = $query->result_array();
                        $result_array['data'] = $query;
                        $result_array['count'] = $query_count;
                        return $result_array;

        }

        public function createCampaignFolderId($folder_id="",$categoryName=""){
            $sql1 = "select * from campaigns where campaign_name =".$categoryName." and folder_id = ". $folder_id;
            $query = $this->db->query($sql1);
            if ($query->num_rows() > 0) {
                return False;
            }
            else
            {
                $sql2 = "INSERT INTO campaigns (`campaign_name`,folder_id) VALUES (".$categoryName . "," . $folder_id .");";
                $this->db->query($sql2);
                $campaign_id =  $this->db->insert_id();
                return $campaign_id;
            }
        }
}