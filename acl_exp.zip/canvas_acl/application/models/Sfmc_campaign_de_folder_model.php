<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sfmc_campaign_de_folder_model extends CI_Model {

    public function __construct()
    {
            parent::__construct();
            // Your own constructor code
    }

    public function getByCampaignID($campaign_id='')
    {
        $sql = "SELECT * FROM  sfmc_campaign_de_folder where   campaign_id =  ".$campaign_id.";" ;
                $query = $this->db->query($sql);
                if ($query->num_rows() > 0) {
                    return $query->result_array();
                } else {
                    return array();
                }
    }

    public function insert($type, $customerkey,$name,$campaign_id, $sfmc_id)
    {
        $sql = "insert into sfmc_campaign_de_folder (type, customerkey,name,campaign_id, sfmc_id) values ('".$type ."','".$customerkey ."','".$name ."','".$campaign_id ."','".$sfmc_id ."')";
        $query = $this->db->query($sql);
        
    }

    public function get_creative_folder($campaign_id='')
    {
        $sql = "SELECT * FROM  sfmc_campaign_de_folder where  type='Creative' and campaign_id =  ".$campaign_id.";" ;
                $query = $this->db->query($sql);
                if ($query->num_rows() > 0) {
                    return $query->result_array()[0];
                } else {
                    return false;
                }
    }

    public function get_TDE_folder($campaign_id='')
    {
        $sql = "SELECT * FROM  sfmc_campaign_de_folder where  type='TDE' and campaign_id =  ".$campaign_id.";" ;
                $query = $this->db->query($sql);
                if ($query->num_rows() > 0) {
                    return $query->result_array()[0];
                } else {
                    return false;
                }
    }

}