<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edm_copy_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function create( $campaign_id='',$id='',$new_email_name="",$new_campaign_id="")
        {
            //$new_campaign_id = $campaign_id ;
            $sql = "SELECT * FROM edms  where campaign_id = ".$new_campaign_id ." and email_name = ". $new_email_name ; 
            $query = $this->db->query($sql);
            if ($query->num_rows() > 0) {
                return  false;
            }

            $sql2 = "INSERT INTO edms (`campaign_id`,`email_name`) VALUES (".$new_campaign_id.",".$new_email_name . ");";
            $this->db->query($sql2);
            $edm_id =  $this->db->insert_id();

            $sql_in_coun = "INSERT INTO `edm_countries` (`campaign_id`,`edm_id`,`country_id`,`subject`,`preheader`)  SELECT ".$new_campaign_id.", ".$edm_id.", `country_id`,`subject`,`preheader` FROM edm_countries  where edm_id = ".$id." and  campaign_id  = ".$campaign_id.";";
            $this->db->query($sql_in_coun);

            $sql_template = "SELECT * FROM templates  where edm_id = ".$id." and  campaign_id  = ".$campaign_id;
            $query = $this->db->query($sql_template);
            if ($query->num_rows() > 0) {
            $template =  $query->result_array();

            foreach ($template as $key => $tvalue) {
                $sql2_in_template = 'INSERT INTO templates (`campaign_id`,`edm_id` ,`module_key` ,`module_position` ,`createdby` ) VALUES ('.$new_campaign_id. ','.$edm_id. ',"' . $tvalue['module_key'] . '","' . $tvalue['module_position'] . '", NULL);';
                $this->db->query($sql2_in_template);
                $new_t_id = $this->db->insert_id();
                $old_t_id = $tvalue['id'];

                $sql_t_variation = "select * from template_variations where t_id = ". $old_t_id;
                $sql_t_variation_query = $this->db->query($sql_t_variation);
                $template_variation =  $sql_t_variation_query->result_array();

                foreach ($template_variation as $key => $tv_value) {
                    $sql_insert_variation = 'INSERT INTO Template_variations (`campaign_id`,`edm_id` ,`name` ,`show_or_hide` ,`variable_name` ,`conditions`, `t_id`, `hide_show_value` ) VALUES ('.$new_campaign_id. ','.$edm_id. ',"'.$tv_value['name'].'", "'.$tv_value['show_or_hide'].'" ,"'.$tv_value['variable_name'].'","'.$tv_value['conditions'].'",' . $new_t_id. ',"'.$tv_value['hide_show_value'].'");';
                    $q_query = $this->db->query($sql_insert_variation);//->result_array();
                    $new_v_id = $this->db->insert_id();
                    $old_v_id = $tv_value['id'];

                    $sql_esi =  "select * from edms_saved_inputs where template_id = ". $old_t_id ." and variation_id =  ".$old_v_id." and edm_id = ".$id." and  campaign_id  = ".$campaign_id;
                        $sql_esi_query = $this->db->query($sql_esi);
                        if ($sql_esi_query->num_rows() > 0) {
                            $sql_esi_query_data = $sql_esi_query->result_array();
                            $sql_insert_esi ="INSERT INTO edms_saved_inputs(campaign_id, edm_id ,module_position, module_id, element_id ,key_name , title ,alias, href ,editable_type,country_code ,language_code, link ,template_id,variation_id  ) select ".$new_campaign_id.", ".$edm_id." ,esi.module_position,esi.module_id, esi.element_id ,CONCAT('".$new_t_id."' ,'_',right(esi.key_name, LENGTH(esi.key_name) - LOCATE('_', esi.key_name)) ) , esi.title ,esi.alias, esi.href ,esi.editable_type,esi.country_code ,esi.language_code, esi.link ,'".$new_t_id."','".$new_v_id."' from edms_saved_inputs esi where template_id = ". $old_t_id ." and variation_id =  ".$old_v_id." and edm_id = ".$id." and  campaign_id  = ".$campaign_id.";";
                            $this->db->query($sql_insert_esi);
                    }
                }
            }
        }
        return true;


        }
}


