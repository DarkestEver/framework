<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master_css_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getAll()
        {
            $sql = "SELECT * FROM master_css ";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function update_keys($id,$value)
        {
            $this->db->set('inline_css', $value);
            $this->db->where('uuid', $id);
            $this->db->update('master_css');
            return $value;
        }

        public function insert($data)
        {
            $sql = "SELECT * FROM master_css where css_name ='".$data["css_name"]."'";;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return false;
                    }
                    
            $this->db->insert('master_css', $data);
            return $this->db->insert_id();
            
        }




}