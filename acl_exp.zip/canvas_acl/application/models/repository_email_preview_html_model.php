<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class repository_email_preview_html_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getAll()
        {
            $sql = "SELECT * FROM repository_email_preview_html;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getById($id)
        {
            $sql = "SELECT * FROM repository_email_preview_html where id = ".$id.";";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array()[0];
                    } else {
                        return array();
                    }
        }

        public function getByCampaignId($id)
        {
            $sql = "SELECT r.*,e.email_name, c.country_code, c.language_code FROM repository_email_preview_html r 
                    inner join  edms e on e.id = r.edm_id 
                    inner join  countries c on c.id = r.country_id 
                    where r.campaign_id = ".$id." order by r.createddate desc;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function insert($campaign_id="",$edm_id="",$country_id="", $notes="", $html="")
        {
            $sql = "insert into repository_email_preview_html(campaign_id,edm_id,country_id, note, html ) values ($campaign_id,$edm_id,$country_id, $notes, $html)";
            $query = $this->db->query($sql);
            return $this->db->insert_id();   
        }

        public function deleteById($id)
        {
            $sql = "delete FROM repository_email_preview_html where id = ".$id.";";
                    $query = $this->db->query($sql);
        }
}


