<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

    public function __construct()
    {
            parent::__construct();
            // Your own constructor code
    }

    public function getTotalCampaign() {
        $sql = "SELECT count(1) as count FROM campaigns";
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            $query =  $query->result_array();
            return $query[0]['count'];
        }
        return array();
    }

    public function getTotalEDMs() {
        $sql = "SELECT count(1) as count FROM edms";
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            $query =  $query->result_array();
            return $query[0]['count'];
        }
        return array();
    }

    public function getTotalLocalEDMs() {
        $sql = "SELECT count(1) as count FROM edm_countries";
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            $query =  $query->result_array();
            return $query[0]['count'];
        }
        return array();
    }

    public function gettotalEDMByStatus($status) {
        $sql = "SELECT count(1) as count FROM edms where status = ".$status;
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            $query =  $query->result_array();
            return $query[0]['count'];
        }
        return array();
    }

    public function getTotalUser() {
    $sql = "SELECT count(1) as count FROM admin";
    $query = $this->db->query($sql);
    if ($query->num_rows() > 0) {
        $query =  $query->result_array();
        return $query[0]['count'];
    }
    return array();
    }   

    public function getTop5Emails() {
        $sql = "SELECT e.id as edm_id, c.id as campaign_id, email_name,e.modifieddate, e.status , c.campaign_name, e.update_version as version FROM edms e inner join campaigns c on c.id = e.campaign_id order by e.modifieddate desc limit 5";
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return array();
    }
}