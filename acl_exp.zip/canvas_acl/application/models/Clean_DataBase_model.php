<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clean_DataBase_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function clean($value='')
        {

            $sql = "truncate table log_table ";
            $query = $this->db->query($sql);

            $sql = "truncate table assest_upload ";
            $query = $this->db->query($sql);

            $sql = "truncate table campaigns ";
            $query = $this->db->query($sql);

            $sql = "truncate table campaign_category ";
            $query = $this->db->query($sql);


            $sql = "truncate table campaign_vertical ";
            $query = $this->db->query($sql);

            $sql = "truncate table campaign_vertical_wheels ";
            $query = $this->db->query($sql);

            $sql = "truncate table edms ";
            $query = $this->db->query($sql);

            $sql = "truncate table edms_saved_inputs ";
            $query = $this->db->query($sql);


            $sql = "truncate table edm_countries ";
            $query = $this->db->query($sql);

            $sql = "truncate table folders ";
            $query = $this->db->query($sql);

            $sql = "truncate table tagged_promocode ";
            $query = $this->db->query($sql);

            $sql = "truncate table templates ";
            $query = $this->db->query($sql);

            $sql = "truncate table template_variations ";
            $query = $this->db->query($sql);

            $sql = "truncate table api_folder ";
            $query = $this->db->query($sql);

            $sql = "truncate table custom_key_mapping ";
            $query = $this->db->query($sql);
        }



}