<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Folders_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function all()
        {
            $sql = "SELECT * FROM  folders ;" ;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }


        public function get_by_id($id="")
        {
            $sql = "SELECT * FROM  folders where id = ".$id." ;" ;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array()[0];
                    } else {
                        return false;
                    }   
        }

        public function get_by_name_id($parent_id="",$f_name="")
        {
            $sql = "SELECT * FROM  folders where parent_id = ".$parent_id." and f_name = ".$f_name.";" ;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return true;
                    } else {
                        return false;
                    }   
        }

        public function insert_by_name_id($parent_id="",$f_name="")
        {
            if( $this->get_by_name_id($parent_id,$f_name) == false)
            {
                $sql = "insert into folders(parent_id, f_name ) values (".$parent_id.", ".$f_name.")";
                $query = $this->db->query($sql);
                return $this->db->insert_id();
            }
            else
            {
                return false;
            }
        }

        public function update_by_name_id($id="",$f_name="")
        {
            if($this->get_by_id($id) != false)
            {
                $sql = "update  folders set  f_name  = ".$f_name. " where id=" .$id. ";";
                $query = $this->db->query($sql);
                return true;
            }
            else
            {
                return false;
            }
        }
        
}