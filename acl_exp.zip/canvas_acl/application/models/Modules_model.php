<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modules_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getDraggableModules($value='')
        {
            $sql = "SELECT * FROM modules where is_active = 1 order by module_name asc;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function getDraggableModulesbyKey($value)
        {
            $sql = "SELECT * FROM modules where module_key='".$value."';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getModulesCategory($value='')
        {
            $sql = "SELECT * FROM modules_category where is_deleted = 0;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getAll($value='')
        {
            $sql = "SELECT m.*, mc.mc_name FROM modules m inner join modules_category mc on mc.id =m.module_category_id where mc.is_deleted = 0 and  m.is_active = 1 order by m.id asc;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getById($id='')
        {
            $sql = "SELECT m.*, mc.mc_name FROM modules m inner join modules_category mc on mc.id =m.module_category_id where m.id='".$id."'  ";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getCustomKeys($id='')
        {
            $sql = "SELECT * FROM custom_key_mapping where module_id='".$id."'  ";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function update_custom_keys($id,$value)
        {
            $this->db->set('new_key', $value);
            $this->db->where('uuid', $id);
            $this->db->update('custom_key_mapping');
            return $value;
        }

        public function get_custom_keys($module_id,$elements, $old_key)
        {

            $this->db->select('new_key');
            $this->db->where('module_id', $module_id);
            $this->db->where('elements', $elements);
            $this->db->where('old_key', $old_key);
            $this->db->from('custom_key_mapping');
            $query =$this->db->get();
            if($query->num_rows() > 0 ) {
                if ($query->result_array()[0]['new_key'] != "")
                {
                    return $query->result_array()[0]['new_key'];
                }
                else
                {
                     return $old_key;
                }
            }
            else
            {
                return $old_key;
            }
        }

    public function delete_module($id='')
    {
        $sql = "delete FROM custom_key_mapping where module_id='".$id."'  ";
        $query = $this->db->query($sql);
        $sql = "delete FROM modules where id='".$id."'  ";
        $query = $this->db->query($sql);
        $sql = "delete FROM edms_module_elements where module_id='".$id."'  ";
        $query = $this->db->query($sql);
            
    }

}