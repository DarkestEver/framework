<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edms_saved_inputs_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getSavedInputValuesByEdmID($value)
        {
            $sql = "SELECT * FROM edms_saved_inputs where edm_id = '" . $value . "';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getSavedInputValuesCountByEdmID($value)
        {
            $sql = "SELECT count(1) as count FROM edms_saved_inputs where edm_id = '" . $value . "';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function de_export($value)
        {
            $sql = "SELECT key_name,country_code,language_code,variation_id,title,alias,href,start_ampscript,end_ampscript,link FROM edms_saved_inputs where edm_id = '" . $value . "';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function getSavedInputValues($campaign_id,$edm_id )
        {
            $sql = "SELECT esi.*, m.module_key FROM edms_saved_inputs   esi inner join  modules m on m.id = esi.module_id where esi.edm_id = " . $edm_id . " and esi.campaign_id = ".$campaign_id." and api_key_uploadeded = 0;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function export_input($campaign_id,$edm_id,$country,$language)
        {
            $sql = "SELECT esi.id,m.module_name,m.module_name,esi.key_name,esi.country_code,esi.language_code,esi.variation_id,esi.title,esi.alias,esi.href,esi.start_ampscript,esi.end_ampscript,esi.link FROM edms_saved_inputs esi inner join  modules m on m.id = esi.module_id  where  country_code = '".$country."'and language_code = '".$language."'  and edm_id = '".$edm_id."' and campaign_id =".$campaign_id." ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function getSavedInputValuesByTemplateID($value)
        {
            $sql = "SELECT * FROM edms_saved_inputs where template_id = '" . $value . "';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getSavedInputValuesByKey($value, $country_code,$language_code, $edm_id,$campaign_id)
        {
            $campaign_id = $this->db->escape(strip_tags($campaign_id));
            $edm_id = $this->db->escape(strip_tags($edm_id));
            $country_code = $this->db->escape(strip_tags($country_code));
            $language_code = $this->db->escape(strip_tags($language_code)); 
            $sql = "SELECT esi.* FROM edms_saved_inputs esi  where  esi.country_code = ".$country_code." and esi.language_code = ".$language_code." and esi.key_name = '" . $value . "' and esi.edm_id = ".$edm_id." and esi.campaign_id =".$campaign_id." ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

       public function getSavedInputValuesByVariation($variation_id,$key_name, $country_code,$language_code, $edm_id,$campaign_id)
        {
            $sql = "SELECT esi.* FROM edms_saved_inputs esi  where  esi.country_code = '".$country_code."' and esi.language_code = '".$language_code."' and esi.key_name = '" . $key_name . "' and esi.variation_id = '" . $variation_id . "' and esi.edm_id = '".$edm_id."' and esi.campaign_id =".$campaign_id." ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        
        public function setSavedInputValuesByKey($start_ampscript ,$imagesrc,$title, $link , $alias ,$end_ampscript,$country_code,$language_code,$section_key,$variation_id,$edm_id, $campaign_id )
        {
            $sql2 = "update edms_saved_inputs set api_key_uploadeded = 0, `href` =".$imagesrc." , `title` = ". $title . " , `alias` =".$alias. " , `link` = ". $link . " , `start_ampscript` = ". $start_ampscript . ", `end_ampscript` = ". $end_ampscript. "   where variation_id = ". $variation_id ." and key_name = ". $section_key ." and `country_code` = ".$country_code." and `language_code` = ".$language_code." and edm_id = ".$edm_id." and campaign_id = ".$campaign_id.";";
            $this->db->query($sql2);
            return true;
        
        }
        

        public function getByVaration_id($id,$country_code,$language_code,$edm_id)
        {
            $sql = "SELECT * FROM edms_saved_inputs where variation_id ='".$id."' and country_code = '".$country_code."' and language_code = '".$language_code. "' and edm_id = '".$edm_id."';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function get_id($country_code,$language_code,$section_key,$variation_id, $edm_id, $campaign_id)
        {
            $sql2 = "SELECT * from edms_saved_inputs   where variation_id = ". $variation_id ." and key_name = ". $section_key ." and `country_code` = ".$country_code." and `language_code` = ".$language_code." and edm_id = ".$edm_id." and campaign_id = ".$campaign_id.";";
            $query =$this->db->query($sql2);
            if ($query->num_rows() > 0) {
                        return $query->result_array()[0]['id'];
                    } else {
                        return array();
                    }
        }

        public function file_upload_update($campaign_id,$edm_id,$country_code,$language_code, $id, $col, $value)
        {
            $sql2 = "SELECT * from edms_saved_inputs   where  id = ". $id ." and `country_code` = ".$country_code." and `language_code` = ".$language_code." and edm_id = ".$edm_id." and campaign_id = ".$campaign_id.";";
            $query =$this->db->query($sql2);
            if ($query->num_rows() > 0) {
                        $sql_update  = "update edms_saved_inputs set ".$col." = ". $value ." where id = ". $id." ;";
                        $this->db->query($sql_update);
                    } else {
                        return "no record found";
                    }
        }
        public function search_keyword($keyword,$offset=0,$limit =10)
        {
            $sql1 = "SELECT DISTINCT esi.`campaign_id`,esi.`edm_id`,esi.`country_code`,esi.`language_code`, c.campaign_name,c.category_name,c.vertical_name, edms.email_name FROM `edms_saved_inputs` esi INNER JOIN campaigns c on c.id = esi.`campaign_id` inner JOIN edms on edms.id = esi.`edm_id` WHERE `title` like '%".$keyword."%'";
            
            $query_count = $this->db->query($sql1);
            $total_searched_rows =  $query_count->num_rows();

            $sql = $sql1 . "  limit  ". $offset . " , ". $limit;
            $query = $this->db->query($sql);
            $total_searched_pagination_count =  $query->num_rows();
            $result_array = [];
            $query =  $query->result_array();
            $result_array['data'] = $query;
            $result_array['totalcount'] = $total_searched_pagination_count;
            $result_array['total_searched_count'] = $total_searched_rows;
            return $result_array;
        }

        public function search_prmocode($keyword,$offset=0,$limit =10)
        {
            $sql1 = "SELECT DISTINCT tp.promocode, tp.startdate, tp.enddate, edms.`campaign_id`,edms.`id` as edm_id,tp.`country_code`,tp.`language_code`, c.campaign_name,c.category_name,c.vertical_name, edms.email_name FROM tagged_promocode tp inner JOIN edms on edms.id = tp.edm_id INNER join campaigns c on c.id = edms.campaign_id WHERE tp.promocode like '%".$keyword."%'";
            
            $query_count = $this->db->query($sql1);
            $total_searched_rows =  $query_count->num_rows();

            $sql = $sql1 . "  limit  ". $offset . " , ". $limit;
            $query = $this->db->query($sql);
            $total_searched_pagination_count =  $query->num_rows();
            $result_array = [];
            $query =  $query->result_array();
            $result_array['data'] = $query;
            $result_array['totalcount'] = $total_searched_pagination_count;
            $result_array['total_searched_count'] = $total_searched_rows;
            return $result_array;
        }

        public function  getListOfTaggedPromocode($country_code,$language_code,$edm_id)
        {
            $sql = "SELECT promocode, startdate,enddate FROM  tagged_promocode where  country_code = '".$country_code."' and language_code = '".$language_code. "' and edm_id = '".$edm_id."';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getTaggedPromocode($variation_id,$country_code,$language_code,$edm_id)
        {
            $sql = "SELECT * FROM  tagged_promocode where variation_id ='".$variation_id."' and country_code = '".$country_code."' and language_code = '".$language_code. "' and edm_id = '".$edm_id."';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function setTaggedPromocode($variation_id,$country_code,$language_code,$edm_id,$promocode,$startdate,$enddate)
        {
            $sql = "SELECT * FROM  tagged_promocode where variation_id =".$variation_id." and country_code = ".$country_code." and language_code = ".$language_code. " and edm_id = ".$edm_id.";";
            $query = $this->db->query($sql);
            if ($query->num_rows() > 0) {
                $sql_update = "update tagged_promocode set promocode = $promocode , startdate = $startdate , enddate = $enddate where variation_id = $variation_id and country_code = $country_code and language_code = $language_code and edm_id = $edm_id;";
                $query = $this->db->query($sql_update);
                echo 2;
            } else {
                $sql_insert = "insert into tagged_promocode (promocode,startdate,enddate,variation_id,country_code,language_code,edm_id)  values ($promocode,$startdate,$enddate,$variation_id,$country_code,$language_code,$edm_id)  ;";
                $query = $this->db->query($sql_insert);
                echo 1;
            }
        }

        public function getModuleVersionContentHistory($campaign_id,$edm_id,$country,$language, $tab_id,$key_name)
        {
            $sql = "SELECT `key` , value , updated_date  FROM  edms_saved_inputs_versioning where key_name = ".$key_name." and variation_id =".$tab_id." and country_code = ".$country." and language_code = ".$language. " and edm_id = ".$edm_id." and campaign_id = ".$campaign_id." order by id desc;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function updateSubject($title,$key_name,$campaign_id,$edm_id,$country,$language)
        {
            if ($key_name == "subject") {
                $sql2 = "UPDATE edm_countries inner JOIN countries on countries.id = edm_countries.country_id set subject = ".$title." where countries.country_code = ".$country." and countries.language_code = ".$language." and edm_countries.edm_id = ".$edm_id." and edm_countries.campaign_id = ".$campaign_id.";";
                $this->db->query($sql2);
                return true;
            }
            elseif ($key_name == "preheader") {
                $sql2 = "UPDATE `edm_countries` inner JOIN countries on countries.id = edm_countries.country_id set `preheader` = ".$title." where countries.country_code = ".$country." and countries.language_code = ".$language." and edm_id = ".$edm_id." and campaign_id = ".$campaign_id.";";
                $this->db->query($sql2);
                return true;
            }
            else
            {
                return false;
            }
        }

        public function getByID($id)
        {
            $sql = "SELECT *  FROM  edms_saved_inputs where id = ". $id;
            $query = $this->db->query($sql);
            if ($query->num_rows() > 0) {
                return $query->result_array();
            } else {
                return false;
            }
        }

        public function set_API_image_key_uploadeded($id='',$published_url='')
        {
           $sql_update = "update edms_saved_inputs set api_image_uploaded = 1 , modifieddate = modifieddate, href='".$published_url."' where id = ".$id;
           $this->db->query($sql_update);
        }


        public function set_API_key_uploadeded($campaign_id, $edm_id)
        {
           $sql_update = "update edms_saved_inputs set api_key_uploadeded = 1 , modifieddate = modifieddate where campaign_id = ".$campaign_id . " and edm_id = " . $edm_id;
           $this->db->query($sql_update);
        }

        public function getImageEDMDByID($campaign_id, $emd_id)
        {
            $sql = "SELECT id, href FROM  edms_saved_inputs esi where editable_type like '%image%' and href like '%".site_url()."%' and esi.edm_id = ". $emd_id ." and esi.campaign_id = ".$campaign_id ;
            $query = $this->db->query($sql);
             if ($query->num_rows() > 0) {
                return $query->result_array();
            } else {
                return array();
            }
        }

        public function getImageEDMDCountByID($campaign_id, $emd_id)
        {
            $sql = "SELECT count(1) as count FROM  edms_saved_inputs esi where editable_type like '%image%' and href like '%".site_url()."%' and esi.edm_id = ". $emd_id ." and esi.campaign_id = ".$campaign_id ;
            $query = $this->db->query($sql);
            return $query->result_array()[0]['count'];  
         }

        public function getSavedInputValuesCustomKey($campaign_id,$edm_id )
        {
            $sql = "SELECT esi.*, m.module_key, m.module_name, v.name as variation_name FROM edms_saved_inputs   esi inner join  modules m on m.id = esi.module_id inner join template_variations v on v.t_id = esi.variation_id where esi.edm_id = " . $edm_id . " and esi.campaign_id = ".$campaign_id." ";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
}