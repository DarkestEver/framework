<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php
        //$sidebar_panel ="sidebar";
        if (isset($title) && !(empty($title))) {
           echo $title;
        }
        ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="Wide selection of modal dialogs styles and animations available.">
    <meta name="msapplication-tap-highlight" content="no">
    <!--
    =========================================================
    * ArchitectUI HTML Theme Dashboard - v1.0.0
    =========================================================
    * Product Page: https://dashboardpack.com
    * Copyright 2019 DashboardPack (https://dashboardpack.com)
    * Licensed under MIT (https://github.com/DashboardPack/architectui-html-theme-free/blob/master/LICENSE)
    =========================================================
    * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
    -->
<!-- Custom fonts for this template-->
        <link href="<?=base_url()?>resources/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
        <!-- Custom styles for this page 
        <link href="<?=base_url()?>resources/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">-->
                <!-- Tree Folder Structure -->
        <link href="<?=base_url()?>resources/vendor/folderstructure/css/jquery-explr-1.4.css" rel="stylesheet" type="text/css" />
        <!-- context menu -->
        <link href="<?=base_url()?>resources/vendor/contextMenu/dist/jquery.contextMenu.css" rel="stylesheet" type="text/css" />
        <!-- Custom styles for this template-->
        <link href="<?=base_url()?>resources/css/main.css" rel="stylesheet" type="text/css" />


        <script src="<?=base_url()?>resources/vendor/jquery/jquery.min.js"></script>
        <link href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/themes/south-street/jquery-ui.min.css" rel="stylesheet" type="text/css" />
   
        <style type="text/css">
            .nav-tabs .nav-link:not(.active) {
                border-color: transparent !important;
            }
        </style>
        <style>
            .closeparent{position:relative;overflow:hidden;}
            .close{position:absolute;right:0;}
        </style>
        <style type="text/css">
            /*.addvariation{display: none;}*/
            .ui-widget-content{background: #fff}
            
            .has_no_access<?php  if($this->session->userdata("user_gorup_name")=="Administrator")
                 {echo "{display: contents}"; }
                else
                {
                    echo "{display: none}";
                }
            ?>
            .<?php echo $this->session->userdata("user_gorup_name")?>{display: contents}
        </style>
       

</head>
<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
        <div class="app-header header-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                
            </div>
            <div class="app-header__mobile-menu">
              
            </div>
            <div class="app-header__menu">
                
            </div>
                <div class="app-header__content">
                <div class="app-header-left">
                    
                    <ul class="header-menu nav">
                        
                        <li class="nav-item">
                            <a href="<?php echo site_url();?>start/" class="nav-link">
                                <i class="nav-link-icon  fas fa-chart-line"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo site_url();?>campaign/" class="nav-link">
                                
                                 <i class="nav-link-icon fas fa-tv"></i> Campaign
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo site_url();?>repository/" class="nav-link">
                                
                                 <i class="nav-link-icon fas fa-tv"></i> Preview Repository
                            </a>
                        </li>
                        <li class="dropdown nav-item">
                            <a href="<?php echo site_url();?>keywordsearch/" class="nav-link">
                                <i class="nav-link-icon fab fa-searchengin"></i>
                                Promo Code
                            </a>
                        </li>
                         <li class="dropdown nav-item">
                            <a href="<?php echo site_url();?>settings/admins/" class="nav-link">
                                <i class="nav-link-icon fas fa-cogs"></i> Setting
                            </a>
                        </li>

                    </ul>        </div>
                <div class="app-header-right">
                    <div class="header-btn-lg pr-0">
                        <div class="widget-content p-0">
                            <div class="widget-content-wrapper">
                                <!--
                                <div class="widget-content-left">
                                    <div class="btn-group">
                                        <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="p-0 btn">
                                            <img width="42" class="rounded-circle" src="assets/images/avatars/1.jpg" alt="">
                                            <i class="fa fa-angle-down ml-2 opacity-8"></i>
                                        </a>
                                        <div tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu dropdown-menu-right">
                                            <button type="button" tabindex="0" class="dropdown-item">User Account</button>
                                            <button type="button" tabindex="0" class="dropdown-item">Settings</button>
                                            <h6 tabindex="-1" class="dropdown-header">Header</h6>
                                            <button type="button" tabindex="0" class="dropdown-item">Actions</button>
                                            <div tabindex="-1" class="dropdown-divider"></div>
                                            <button type="button" tabindex="0" class="dropdown-item">Dividers</button>
                                        </div>
                                    </div>
                                </div>
                            -->
                                <div class="widget-content-left  ml-3 header-user-info">
                                    <div class="widget-heading ajax_loader">
                                         <i class="fa fa-cog fa-w-16 fa-spin fa-2x"></i>
                                    </div>
                                </div>
                                 <div class="widget-content-left  ml-3 header-user-info">
                                    <div class="widget-heading">

                                        <?php 
                                            $ci = get_instance();
                                            $ci->load->library('session');
                                            $ci->load->library('session');
                                            $sdata = $ci->session->userdata('username');
                                            echo ($sdata);
                                        ?>
                                    </div>
                                    <div class="widget-subheading">
                                        
                                    </div>
                                </div>
                                <div class="widget-content-right header-user-info ml-3">
                                    <a href="<?php echo site_url().'logout'?>" class="btn-shadow p-1 btn btn-primary btn-sm show-toastr-example">
                                        <i class="fas fa-sign-out-alt"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>        </div>
            </div>
        </div>      
  
           <div class="app-main">
               
  <!-- HERE Comes Side Bar -->
<?php
//$sidebar_panel ="sidebar";
if (isset($sidebar_panel) && !(empty($sidebar_panel))) {
   $this->load->view($sidebar_panel);
}
?>
                   
                 <div class="app-main__outer">
                    <div class="app-main__inner">
<?php
//$sidebar_panel ="sidebar";
if (isset($top_title_panel) && !(empty($top_title_panel))) {
   $this->load->view($top_title_panel);
}
?>