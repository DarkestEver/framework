<?php 
$ci = get_instance();
$ci->load->library('session');
$ci->load->library('session');
$ci->session->userdata('item')
?>