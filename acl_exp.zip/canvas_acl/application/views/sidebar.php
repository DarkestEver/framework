 <div class="app-sidebar sidebar-shadow">
                    <div class="app-header__logo">
                        <div class="logo-src"></div>
                    </div>

<div class="app-sidebar sidebar-shadow">
                    <div class="app-header__logo">
                        <div class="logo-src"></div>
                        <div class="header__pane ml-auto">
                            <div>
                                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                    <span class="hamburger-box">
                                        <span class="hamburger-inner"></span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
  <!-- HERE Comes Side Bar -->
            <div class="scrollbar-sidebar">
                        <div class="app-sidebar__inner">
                            <?php get_instance()->load->helper('folderstructure_helper');
echo folder_tree(); ?>
                            
                        </div>
                    </div>                </div>
                    </div>
<script type="text/javascript">
   $(document).ready(function() {   
            jQuery.browser = {};
            (function () {
                jQuery.browser.msie = false;
                jQuery.browser.version = 0;
                if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
                    jQuery.browser.msie = true;
                    jQuery.browser.version = RegExp.$1;
                }
            })();
        $("#tree").explr({ startCollapsed : false});

       
        
    });
</script>