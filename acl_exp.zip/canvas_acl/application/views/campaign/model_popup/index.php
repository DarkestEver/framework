<!-- Add New Email -->
<div class="modal fade" id="newEmail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add New Email</h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                            <div>
                               
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="emailname" style="padding:.375rem .75rem">Email Name</label>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control error_message" name="emailname" id="emailname" placeholder="Email Name">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="male" style="padding:.375rem .75rem">Market Name</label>
                                    </div>
                                    <div class="col-sm-6">
                                        <select class="form-control" id="marketName" name="marketName[]" placeholder="marketName" multiple>
                                            <?php foreach ($countries as $key => $country) {
                                                echo '<option value="'.$country['id'].'">'.$country['country_code']."_".$country['language_code'].'</option>';
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Save" id="btn_save_new_email" />
            </div>

        </div>
    </div>
</div>

<!-- Add Folder Modal -->
<div class="modal fade" id="newFolder" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Folder</h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                            <div>

                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="emailname" style="padding:.375rem .75rem">Folder Name</label>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control error_message" name="input_folder_id" id="input_folder_id" placeholder="Folder Name">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Save" id="btn_new_folder" />
            </div>

        </div>
    </div>
</div>


<!-- edit fodler Modal -->
<div class="modal fade" id="editFolder" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Folder</h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                            <div>

                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="emailname" style="padding:.375rem .75rem">Folder Name</label>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control error_message" name="input_folder_id_edit" id="input_folder_id_edit" placeholder="Folder Name">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Save" id="btn_edit_folder" />
            </div>

        </div>
    </div>
</div>

<!-- Add New Campaign Modal -->
<div class="modal fade" id="newCampaing" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add New Campaign</h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                            <div>

                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control error_message" name="campaing_name_new" id="campaing_name_new" placeholder="Campaign Name">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Save" id="btn_campaing_name_new" />
            </div>
        </div>
    </div>
</div>

