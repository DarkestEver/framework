<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fas fa-bars"></i>
            </div>
            <div>Campaigns : <b><lebel id="campaing_name_selected_from_menu"><?php if(isset($campaign_name)) {echo $campaign_name;} ?></lebel></b>
                <div class="page-title-subheading">Right click on rows for more options
                </div>
            </div>
        </div>
        <div class="page-title-actions">
            <div class="d-inline-block dropdown">
             
             <!--   <a ><i id="comment_btn_toggle" class="far fa-comment-dots" style="font-size: xx-large;cursor: -webkit-grab; cursor: grab;"></i></a> -->
            </div>
        </div>    </div>
</div>
<div class="row">

    <div class="col-md-12">
                <div class='card panel-default'>
                    <div class='card-body filters'>
                        
                        <div class='row'>
                        </div>
                        <div class='row'>
                            &nbsp;
                        </div>
                        <table class='table table-bordered' id="dataTable">
        
                        </table>

                    </div>
                </div>
    </div>           

 <input type="hidden" name="hidden_folder_id" id="hidden_folder_id">
 <input type="hidden" name="campaign_id" id="campaign_id" value="<?php if (isset($campaign_id_url))  echo $campaign_id_url ;?>">
 <input type="hidden" name="selected_edm_id" id="selected_edm_id">

 <input type="hidden" name="selected_campaign_id" id="selected_campaign_id">
 <input type="hidden" name="selected_email_name" id="selected_email_name">

 <!-- Add New Email -->
<div class="modal fade" id="newEmail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add New Email</h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                            <div>
                               
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="emailname" style="padding:.375rem .75rem">Email Name</label>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control error_message" name="emailname" id="emailname" placeholder="Email Name">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="male" style="padding:.375rem .75rem">Market Name</label>
                                    </div>
                                    <div class="col-sm-6">
                                        <select class="form-control" id="marketName" name="marketName[]" placeholder="marketName" multiple>
                                            <?php foreach ($countries as $key => $country) {
                                                echo '<option value="'.$country['id'].'">'.$country['country_code']."_".$country['language_code'].'</option>';
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Save" id="btn_save_new_email" />
            </div>

        </div>
    </div>
</div>

<!-- Add Folder Modal -->
<div class="modal fade" id="newFolder" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Folder</h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                            <div>

                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="emailname" style="padding:.375rem .75rem">Folder Name</label>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control error_message" name="input_folder_id" id="input_folder_id" placeholder="Folder Name">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Save" id="btn_new_folder" />
            </div>

        </div>
    </div>
</div>


<!-- edit fodler Modal -->
<div class="modal fade" id="editFolder" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Folder</h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                            <div>

                                <div class="form-group row">
                                    <div class="col-sm-3">
                                        <label for="emailname" style="padding:.375rem .75rem">Folder Name</label>
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control error_message" name="input_folder_id_edit" id="input_folder_id_edit" placeholder="Folder Name">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Save" id="btn_edit_folder" />
            </div>

        </div>
    </div>
</div>

<!-- Add New Campaign Modal -->
<div class="modal fade" id="newCampaing" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add New Campaign</h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                            <div>

                                <div class="form-group row">
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control error_message" name="campaing_name_new" id="campaing_name_new" placeholder="Campaign Name">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Save" id="btn_campaing_name_new" />
            </div>
        </div>
    </div>
</div>

<!-- Copy Email -->
<div class="modal fade" id="copyemail_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Copy Email : <span id="copyemail_selected_to_copy"></span></h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                             <div class="form-group row">
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control error_message" name="input_copy_new_email_name" id="input_copy_new_email_name" placeholder="Email Name">
                                    </div>
                             </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Save" id="btn_copy_new_email_name" />
            </div>
        </div>
    </div>
</div>

