<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$edm_id = $edm_details[0]['id'] ;
 $campaign_id = $edm_details[0]['campaign_id'];
  ?>
<input type="hidden" id="emd_id"  value="<?php echo $emd_id; ?>">
<input id="campaign_id" name="campaign_id" type="hidden" value="<?php echo $campaign_id; ?>">

<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fas fa-bars"></i>
            </div>
            <div>EMAIL BUILDER : <b><lebel id="campaing_name_selected_from_menu"><a href="<?php echo site_url().'campaign/index/'.$campaign_id ;?>"> <?php  echo  $edm_details[0]['campaign_name'] ?> </a><i class='fas fa-arrow-right fa-sm'></i> <?php  echo  $edm_details[0]['email_name'] ?></lebel></b>
                <div class="page-title-subheading">Drag & Drop or click on right panel component to create email template.
                </div>
            </div>
        </div>
        <div class="page-title-actions">
            <div class="d-inline-block dropdown">

                <?php  if ($edm_status != 2 ) { ?>
                <button type="button" id="saveTemplates" aria-haspopup="true" aria-expanded="false" class="btn-shadow  btn btn-info"><i class="fas fa-download fa-sm text-white-50"></i> Save Template</button>
                <?php } if ($edm_status == 1 ) { ?>
                <button type="button" id="publishTemplates"  name="publishTemplates"  aria-haspopup="true" aria-expanded="false" class="btn-shadow  btn btn-success"><i class="fas fa-download fa-sm text-white-50"></i> Publish</button>
                <?php } if ($edm_status == 2 ) { ?>
                <button type="button" id="editTemplates"  name="editTemplates"  aria-haspopup="true" aria-expanded="false" class="btn-shadow  btn btn-warning" style="color: white"><i class="fas fa-download fa-sm text-white-50"></i> Edit</button>
                <?php } ?>

            </div>
        </div>    </div>
</div>



<div class="row"> 
    <!-- Draggable container --> 
    <?php  if ($edm_status == 0 || $edm_status == 1 ) { ?>
     <div class="col-md-5"> 
       <div class="row col-md-5" style="position: fixed;">
       <div class="card" style="width: 100%">
        <div class="card-header-tab card-header" style="height: auto;">
            <div class="card-header-title">
                <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                   <?php foreach ($modules_category as $key => $category) { ?>
                    <li class="nav-item">
                        <a role="tab" class="nav-link show" id="tab-<?php echo $category['id']; ?>" data-toggle="tab" href="#tab-content-<?php echo $category['id']; ?>" aria-selected="false">
                            <span><?php echo $category['mc_name']; ?></span>
                        </a>
                    </li>
                    <?php }    ?>   
                </ul>
            </div>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <?php foreach ($modules_category as $key => $category) { ?>
                <div class="tab-pane tabs-animation fade" id="tab-content-<?php echo $category['id']; ?>" role="tabpanel">
                    <div class="row">
                        <div class="col-md-12">
                            <?php foreach ($modules as $v) { if ($category['id'] == $v['module_category_id']) { 
                        echo ' <div data-toggle="tooltip" title="'.$v['description'].'"  class="draggable mb-2 mr-2 border-0 btn-transition btn btn-outline-info" id="' .$v['module_key'] .'" data-module="'.$v['module_key'] .'">' 
                        .$v['module_name'] 
                        .'</div>'; } } ?> 
                        </div>
                    </div>
                </div>
                <?php }    ?>
            </div>
        </div>
      </div> 
    </div>
    </div>
    <?php } ?>
    <div class="col-md-7"> 
        <div class="card shadow" style="min-height:100px;width:600px;padding: 0px;margin: auto;"> 
            <ul class="card-body" id="droppable" style="list-style: none;padding: 0px;margin:0px;" width="600">
                    <?php  foreach ($existing_modules as $key => $v) {
                        echo '<li class="'.$v['module_key'].' closeparent" id="'.strval($v['t_id']).'" style="padding: 0px 0 0px 0;">';
                        echo '<div style="right: 25px;position: absolute; color:#d43f3a" class="delete_li" data-deleteli="'.strval($v['t_id']).'"><i class="fas fa-times"></i></div>' ;
                        echo '<div class="addvariation" style="left: 0;right: auto;position: absolute;"><button type="button" class="btn btn-primary btn-sm"  data-toggle="modal" data-target="#veriationModal" data-variation="'.strval($v['t_id']).'"><i class="fab fa-buffer"></i></button></div>' ;
                        echo '<img  title="description" src="'.site_url().'resources/img/module_icon/'. $v['module_key'].'.png">';
                        echo '</li>';
                    } ?>
            </ul>
         </div>
                <ul id="moduleshid" style="display:none">
                <?php foreach ($modules as $v) {
                    echo '<li class="'.$v['module_key'].' closeparent" style="padding: 0px 0 0px 0;">';
                    echo '<img  title="description" src="'.site_url().'resources/img/module_icon/'. $v['module_key'].'.png">';
                    echo '</li>';
                } ?>
            </ul>
    </div>
<!-- Logout Modal-->
<div class="modal fade" id="veriationModal" tabindex="-1" role="dialog" aria-labelledby="variationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="variationModalLabel">Module Attributes</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="t_id">
                <div class="form-group" style="display: none;">
                    <label for="message-text" class="col-form-label">Block Start Code</label>
                    <textarea class="form-control form-control-sm" id="t_start_ampscript"></textarea>
                </div>
                <div class="form-group field_wrapper" id="t_new_variation_condition">
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Name</label>
                                <input type="text" class="form-control form-control-sm" name="t_condition_name[]" id="t_condition_name">
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label for="t_condition">Condition</label>
                                <select class="form-control form-control-sm" name="t_hide_or_show[]" id="t_hide_or_show">
                                    <option value="0">Hide</option>
                                    <option value="1">Show</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label for="t_condition">DE variable</label>
                                <input type="text" class="form-control form-control-sm" name="t_sending_de_variable[]" id="t_sending_de_variable">
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label for="t_condition">Condition</label>
                                <select class="form-control form-control-sm" name="t_condition[]" id="t_condition">
                                    <option value=">"> > (integer)</option>
                                    <option value="<">< (integer)</option>
                                    <option value=">=">>= (integer)</option>
                                    <option value="<="><= (integer)</option>
                                    <option value="==">== (integer)</option>
                                    <option value="and">And (integer,string)</option>
                                    <option value="or">Or (integer,string)</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <label for="recipient-name" class="col-form-label">Value</label>
                            <input type="text" class="form-control form-control-sm" name="t_hide_show_value[]" id="t_hide_show_value">
                        </div>
                        <div class="col-lg-1">
                            <label for="recipient-name" class="col-form-label"></label>
                            <a type="button" class="btn btn-primary" id="btn_savevaraitionscondition">Save</a>
                        </div>
                    </div>
                    <div id="variation_display_model" class="form-control" style="height:auto">
                    </div>
                </div>
                <div class="form-group row" style="display: none;">
                    <div class="col-lg-6">
                        <label for="recipient-name" class="col-form-label">Background Color</label>
                        <input type="text" class="form-control form-control-sm" id="t_background_color">
                    </div>
                    <div class="col-lg-6" style="display: none;">
                        <label for="recipient-name" class="col-form-label">Background Image Link</label>
                        <input type="text" class="form-control form-control-sm" id="t_background_image_link">
                    </div>
                </div>
                <div class="form-group" style="display: none;">
                    <label for="message-text" class="col-form-label">Block End Code</label>
                    <textarea class="form-control form-control-sm" id="t_end_ampscript"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<div id="hidden_variation_block" style="display: none;">
    <div class="row shadow" >
        <div class="col-lg-2">
            <label for="recipient-name"  class="hidden_variation_block_name" style="margin-bottom:0px">Name</label>
        </div>
        <div class="col-lg-2" >
            <label for="t_hide_show_value" class="hidden_variation_block_show_hide" style="margin-bottom:0px">Hide/Show</label>
        </div>
        <div class="col-lg-2">
            <label for="t_condition" class="hidden_variation_block_de_variable" style="margin-bottom:0px">DE variable</label>
        </div>
        <div class="col-lg-2">
            <label for="t_condition" class="hidden_variation_block_condition" style="margin-bottom:0px">Condition</label>
        </div>
        <div class="col-lg-2">
            <label for="recipient-name" class="hidden_variation_block_value" style="margin-bottom:0px">Value</label>
        </div>
        <div class="col-lg-1">
            <a  class="remove_variation" ><i class="fas fa-minus-square"></i></a>
        </div>
    </div>
</div>

<style type="text/css">
    .ui-widget-content {
    background: #ececec;
}

.ui-accordion .ui-accordion-content {
padding: 0px;
}
</style>