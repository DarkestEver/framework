<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fas fa-search"></i>
            </div>
            <div>Promo Code
                <div class="page-title-subheading">Search keyword or promo code
                </div>
            </div>
        </div>
</div>
</div>

<div class="row">
<div class="col-lg-12">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class='row'>
                            <div class="col-lg-12">
                     
                                    <div class="position-relative form-group">
                                           <div class="custom-checkbox custom-control custom-control-inline">
                                               <input type="text" class="form-control" name="keyword" id="keyword" placeholder="Promo Code">
                                            </div>
                                            <div class="custom-checkbox custom-control custom-control-inline">
                                                <input type="radio" value="p" id="radio_prmocode" name="search_radio" checked>Tagged Promo Code
                                                                        </label>
                                            </div>
                                            <div class="custom-checkbox custom-control custom-control-inline">
                                                 <label class="radio-inline">
                                                  <input type="radio" value="s" id="radio_keyword" name="search_radio" >Keyword
                                                  </label>
                                            </div>
                                            <div class="custom-checkbox custom-control custom-control-inline">
                                                  <a href="#" id="search" class="btn btn-primary">Search</a>
                                            </div>
                                    </div>
                                </div>
                             
                        </div>

            <div id="div_dataTable" >
                <table class='table table-bordered' id="dataTable" style="width: 100%">
                    <thead>
                        <tr>
                            <th>Campaign</th>
                            <th>Email Name</th>
                            <th>Country</th>
                            <th>Language</th>
                            <th>Status</th>
                            <th>Link</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <div id="div_dataTable_promo">
                <table class='table table-bordered' id="dataTable_promo"  style="width: 100%">
                    <thead>
                        <tr>
                            <th>Campaign</th>
                            <th>Email Name</th>
                            <th>Country</th>
                            <th>Language</th>
                            <th>Promo</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Status</th>
                            <th>Link</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
