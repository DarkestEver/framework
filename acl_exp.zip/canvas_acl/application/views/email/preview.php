<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fas fa-bars"></i>
            </div>
            <div>Preview : <b><lebel id="campaing_name_selected_from_menu"><a href="<?php echo site_url().'campaign/index/'.$campaign_id ;?>"> <?php  echo  $edm_details[0]['campaign_name'] ?> </a><i class='fas fa-arrow-right fa-sm'></i> 
                <a href="<?php echo site_url().'email/edit/'.$campaign_id.'/'.$edm_id.'/'.$country.'/'.$language ;?>"> <?php  echo  $edm_details[0]['email_name'] ?></a></lebel></b><?php echo ' ('.$country.'-'.$language .')'; ?>
                <div class="page-title-subheading">Desktop & Mobile
                </div>
            </div>
        </div>
        <div class="page-title-actions">
            <div class="d-inline-block dropdown">

                <a href="#" id="mobile_view"><i class="fas fa-mobile-alt fa-2x"></i>
				</a>
				<a href="#" id="desktop_view"><i class="fas fa-desktop fa-2x"></i>
				</a>

            </div>
        </div>
    </div>
</div>

<center>
<div class="row">
<div class="col-lg-12 m-auto">
<iframe frameBorder="0"  onload="this.style.height=this.contentDocument.body.scrollHeight +'px';" width="600px" id="ifram_preview" src="<?php echo site_url().$preview_url?>"></iframe>
</div>
</div>

<center>