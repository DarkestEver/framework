
                    </div>
                
                     </div>
        </div>
    </div>
  </div>


<!-- Javascripts -->
        <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
        <!-- Bootstrap core JavaScript-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js" type="text/javascript"></script>
        <script src="<?=base_url()?>resources/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <!-- Core plugin JavaScript-->
        <script src="<?=base_url()?>resources/vendor/jquery-easing/jquery.easing.min.js"></script>
        <!-- Page level plugins -->
        <script src="<?=base_url()?>resources/vendor/datatables/jquery.dataTables.min.js"></script>
        <script src="<?=base_url()?>resources/vendor/datatables/dataTables.bootstrap4.min.js"></script>
        <script type="text/javascript">
        $(document).ready(function() {
            //$.fn.dataTable.ext.errMode = 'none';
        });</script>
        <!-- Tree Folder Structure -->
        <script src="<?=base_url()?>resources/vendor/folderstructure/js/jquery-explr-1.4.js"></script>
        <!-- Tree Folder Structure -->
        <script src="<?=base_url()?>resources/vendor/contextMenu/dist/jquery.ui.position.js"></script>
        <script src="<?=base_url()?>resources/vendor/contextMenu/dist/jquery.contextMenu.js"></script>
        
        <!-- inline editable -->
        <script src="<?=base_url()?>resources/vendor/jquery_jeditable-master/src/jquery.jeditable.js"></script>
        <!-- NOtification -->
        <script src="<?=base_url()?>resources/vendor/notify.min.js"></script>
        <!-- Custom scripts for all pages
           <script src="<?=base_url()?>resources/js/main.js"></script>
        -->
        <script type="text/javascript">
            function alert_message(message,class_name) {
                $.notify(message, 
                    {
                          // whether to hide the notification on click
                          clickToHide: true,
                          // whether to auto-hide the notification
                          autoHide: true,
                          // if autoHide, hide after milliseconds
                          autoHideDelay: 5000,
                          // show the arrow pointing at the element
                          arrowShow: true,
                          // arrow size in pixels
                          arrowSize: 5,
                          // position defines the notification position though uses the defaults below
                          //position: 'left',
                          // default positions
                          elementPosition: 'bottom left',
                          globalPosition: 'top center',
                          // default style
                          style: 'bootstrap',
                          // default class (string or [string])
                          className: class_name,
                          // show animation
                          showAnimation: 'slideDown',
                          // show animation duration
                          showDuration: 400,
                          // hide animation
                          hideAnimation: 'slideUp',
                          // hide animation duration
                          hideDuration: 400,
                          // padding between element and notification
                          gap: 2
                        }
                    );
                
            }

            $(document).ready(function() {
                $(".ajax_loader").hide();
            });

            $(document).ajaxStart(function() {
                // show loader on start
                /*
                $.get('<?php echo base_url()?>login/ajax_verifulogin/', function(data) {
                     if( data != "1" ) {
                         alert_message("Session expired");
                         //window.location.href="<?=base_url()?>";
                         $.ajaxQ.abortAll();
                     } 
                 });
                */
                $(".ajax_loader").css("display","block");
                
            }).ajaxSuccess(function() {
                // hide loader on success
                $(".ajax_loader").css("display","none");
               
            });
        </script>

        <?php
        if (isset($js) && !(empty($js)))
        {
            include 'resources/custom/js/'.$js.'.js.php';
        }
        ?>

        <?php
        if (isset($css) && !(empty($css))) {
            include 'resources/custom/css/'.$css.'.css.php';
        }
        ?>
        

</body>
</html>



