  <?php
defined('BASEPATH') OR exit('No direct script access allowed');

 ?>

<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fas fa-bars"></i>
            </div>
             <div>SFMC : <b><lebel id="campaing_name_selected_from_menu"><a href="<?php echo site_url().'campaign/index/'.$edm_details[0]['campaign_id'] ;?>"> <?php  echo  $edm_details[0]['campaign_name'] ?> </a><i class='fas fa-arrow-right fa-sm'></i> <?php  echo  $edm_details[0]['email_name'] ?></lebel></b>
                <div class="page-title-subheading">Upload images & data extensions key using SFMC APIs.
                </div>
            </div>
        </div>
        <div class="page-title-actions">
            <div class="d-inline-block dropdown">
            <?php if ($folder_sync == false) { ?>
                <a  href="#" id="btn_confirm_folder_sync" data-toggle="tooltip" title="Download Translation DE" class="btn-shadow btn btn-info" data-original-title="Tooltip">
                    <i class="fas fa-sync"></i></i> Folder are not sync!!
                </a>
            <?php } else if (sizeof($de_details) == 0) { ?>   
                <a  href="#" id="btn_confirm_create_campaign" data-toggle="tooltip" title="Download Translation DE" class="btn-shadow btn btn-info" data-original-title="Tooltip">
                    <i class="fas fa-sync"></i></i> Campaign folders does not exits!!
                </a>
            <?php } else {?>
            <a  href="<?php echo site_url().'sfmc/export_de/'.$campaign_id.'/'.$edm_id; ?>"  data-toggle="tooltip" title="Download Translation DE" class="btn-shadow btn btn-info" data-original-title="Tooltip">
                <i class="fas fa-file-download" style="font-size: xx-large;"></i>
            </a>
            <a  href="#" id="btn_confirm_transfer" data-toggle="tooltip" title="Upload DE" class="btn-shadow btn btn-info" data-original-title="Tooltip">
                <i class="fas fa-upload" style="font-size: xx-large;"></i>
            </a>
            <a  href="#" id="btn__image_confirm_transfer" data-toggle="tooltip" title="Upload Images" class="btn-shadow btn btn-info" data-original-title="Tooltip">
                <i class="far fa-images" style="font-size: xx-large;"></i>
            </a>
             <a  href="<?php echo site_url().'email/get_ampscript2/'.$campaign_id.'/'.$edm_id ; ?>"  data-toggle="tooltip" title="Download Amp script" class="btn-shadow btn btn-info" data-original-title="Tooltip">
                            <i class="fas fa-code"  style="font-size: xx-large;" ></i>
                        </a> 
            <a  href="#" id="btn_api_sfmc_campaign_setting" data-toggle="tooltip" title="Setting" class="btn-shadow btn btn-info" data-original-title="Tooltip">
                    <i class="fas fa-sliders-h" style="font-size: xx-large;"></i>
            </a>
        <?php } ?>
            </div>
        </div>    </div>
</div>


<div class="row">                
    <div class="col-lg-12">
        <div class="main-card mb-3 card">
                                <div class="no-gutters row">
                                    <div class="col-md-4">
                                        <div class="widget-content">
                                            <div class="widget-content-wrapper">
                                                <div class="widget-content-right ml-0 mr-3">
                                                    <div class="widget-numbers text-success"><i class="far fa-envelope"> </i> <?php echo $v_count; ?></div>
                                                </div>
                                                <div class="widget-content-left">
                                                    <div class="widget-heading">Variations</div>
                                                    <div class="widget-subheading">Country + Language</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="widget-content">
                                            <div class="widget-content-wrapper">
                                                <div class="widget-content-right ml-0 mr-3">
                                                    <div class="widget-numbers text-warning"><i class="far fa-images"></i> <label id="image_count"> <?php echo $img_count; ?></label></div>
                                                </div>
                                                <div class="widget-content-left">
                                                    <div class="widget-heading">Images</div>
                                                    <div class="widget-subheading">Not Live</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="widget-content">
                                            <div class="widget-content-wrapper">
                                                <div class="widget-content-right ml-0 mr-3">
                                                    <div class="widget-numbers text-danger"><i class="fas fa-table"></i> <?php echo $key_count; ?></div>
                                                </div>
                                                <div class="widget-content-left">
                                                    <div class="widget-heading">Data Extension</div>
                                                    <div class="widget-subheading">Number Of Keys</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
        <div class="main-card mb-3 card">
            <div class="card-body"><h5 class="card-title">Email Language List</h5>
                <table class="mb-0 table table-bordered">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Country</th>
                        <th>Language</th>
                        <th>Action</th>
                        
                    </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $counter = 1;
                    foreach ($rows as $key => $value) { ?>
                    
                    <tr>
                        <th scope="row"><?php echo $counter;?></th>
                        <td><?php echo $value['country_code'];?></td>
                        <td><?php echo $value['language_code']?></td>
                        <td><a  href="<?php echo site_url().'email/preview_download/'.$value['campaign_id'].'/'.$value['edm_id'].'/'.$value['country_code'].'/'.$value['language_code']; ?>"  data-toggle="tooltip" title="Download HTML" class="btn-shadow btn btn-info" data-original-title="Tooltip">
                            <i class="fab fa-html5" ></i>
                        </a> 

                    </td>
                        
                    </tr>
                    <?php $counter++; } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<div class="modal" id="model_api_upload_de" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"  aria-modal="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Transfer DE To SFMC</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">

                <p class="mb-0" id="confirm_text"> Please confirm!</p>
                <p class="mb-0"  id="upload_api_spinner">Please Do Not Refresh!!! <i  class="fa fa-cog fa-w-16 fa-spin fa-2x"></i></p>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="btn_api_de_confirm_upload">Confirm Transfer</button>
            </div>
        </div>
    </div>
</div>


<div class="modal" id="model_api_upload_image" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"  aria-modal="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Upload Images To SFMC</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                
                <p class="mb-0" id="image_confirm_text"> Please confirm!</p>
                <p class="mb-0"  id="image_upload_api_spinner">Please Do Not Refresh!!! <i  class="fa fa-cog fa-w-16 fa-spin fa-2x"></i></p>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="image_btn_api_de_confirm_upload">Upload Images</button>
            </div>
        </div>
    </div>
</div>


<div class="modal" id="model_api_sfmc_campaign_setting" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"  aria-modal="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">SFMC</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                
                
                <div class="card-body">
                    <table class="mb-0 table">
                        <thead>
                        <tr>
                            <th>Type</th>
                            <th>Name</th>
                            <th>key</th>
                        </tr>
                        </thead>
                        <tbody>
                      <?php foreach ($de_details as $key => $value) { ?>
                         <tr>
                            <td><?php echo $value["type"]; ?></td>
                            <td><?php echo $value["name"]; ?></td>
                            <td><?php echo $value["customerkey"]; ?></td>
                         </tr>
                       <?php } ?>
                        </tbody>
                    </table>
                </div>         
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <?php if (sizeof($de_details) == 0 ) { ?>
                    <button type="button" class="btn btn-primary" id="model_de_folder_creation">Upload Images</button>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<?php  if (sizeof($de_details) == 0) { ?>   
<div class="modal" id="model_create_campaign" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"  aria-modal="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create Campaign Folder And DE</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                
                <p class="mb-0" id="create_campaign_confirm_text"> Please confirm!</p>
                <p class="mb-0"  id="create_campaign_api_spinner">Please Do Not Refresh. Might Take Few Minutes!!!! <i  class="fa fa-cog fa-w-16 fa-spin fa-2x"></i></p>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="btn_create_campaign">Create</button>
            </div>
        </div>
    </div>
</div>
<?php } ?>


<?php  if ($folder_sync == false) { ?>   
<div class="modal" id="model_folder_sync" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"  aria-modal="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create Folder Hierarchy</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                
                <p class="mb-0" id="folder_sync_confirm_text"> Please confirm!</p>
                <p class="mb-0"  id="folder_sync_api_spinner">Please Do Not Refresh. Might Take Few Minutes!!!! <i  class="fa fa-cog fa-w-16 fa-spin fa-2x"></i></p>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="btn_folder_sync">Sync</button>
            </div>
        </div>
    </div>
</div>
<?php } ?>