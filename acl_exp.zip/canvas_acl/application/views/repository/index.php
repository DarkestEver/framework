<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>

<input type="hidden" name="campaign_id">
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fas fa-bars"></i>
            </div>
            <div>Email Repository : <b><lebel id="campaing_name_selected_from_menu"><?php if(isset($campaign_name)) {echo $campaign_name;} ?></lebel></b>
                <div class="page-title-subheading">Right click on rows for more options
                </div>
            </div>
        </div>
        <div class="page-title-actions">
            <div class="d-inline-block dropdown">
             
             <!--   <a ><i id="comment_btn_toggle" class="far fa-comment-dots" style="font-size: xx-large;cursor: -webkit-grab; cursor: grab;"></i></a> -->
            </div>
        </div>    </div>
</div>
<div class="row">

<div class="col-md-12">
 
<div class='card panel-default'>
          <div class="card-header">
                    <i class="fa fa-table"></i>Preview List <a href="#" class="open_model_new"><button class="btn btn-primary">+</button></a>
                </div>
                <div class="card-block">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" id="dataTable" cellspacing="0">
                            <thead>
                                <tr>
                                    
                                    <th>Email</th>
                                    <th>Country</th>
                                    <th>Language</th>
                                    <th>Note</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if (isset($data)) { foreach ($data as $v) { ?>
                                <tr>
                                    
                                    <td><?=$v["email_name"]?></td>
                                    <td><?=$v["country_code"]?></td>
                                    <td><?=$v["language_code"]?></td>
                                    <td><?=$v["note"]?></td>
                                    <td><?=$v["createdDate"]?></td>
                                    <td> 
                                        <a class="" target="_blank" href="<?=base_url()?>repository/view/<?=$v["id"]?>"><i class="fas fa-eye btn"></i></a>
                                        <form method="POST" action="" style="display:inline;"><input type="hidden" name="delete_action" value="delete"><input type="hidden" name="delete_id" value="<?=$v["id"]?>">
                                        <button type="submit" class="btn">
                                          <i class="fas fa-trash-alt"></i> 
                                        </button>
                                        </form>
                                     </td>
                                </tr>
                            <?php }} ?>
                            </tbody>
                        </table>
                    </div>
                </div>
</div>           

<div class="modal fade" id="model_new" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add New Preview</span></h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                             <div class="main-card mb-3 card">
                <div class="card-body">
                    <div>
                        <form class="form" method="post">
                           <div class="mb-2 mr-sm-2 mb-sm-0 position-relative form-group"><label for="exampleEmail22" class="mr-sm-2">Email</label>
                                <select class="form-control" id="email_id" name="email_id" placeholder="" >
                                    <?php foreach ($edms as $key => $edm) {
                                        echo '<option value="'.$edm['id'].'">'.$edm['email_name'].'</option>';
                                    } ?>
                                </select>
                            </div>
                            <div class="mb-2 mr-sm-2 mb-sm-0 position-relative form-group"><label for="examplePassword22" class="mr-sm-2">Market</label>
                                <select class="form-control" id="country_code" name="country_code" placeholder="" >
                                    <?php foreach ($countries as $key => $country) {
                                        echo '<option value="'.$country['id'].'">'.$country['country_code']."_".$country['language_code'].'</option>';
                                    } ?>
                                </select>
                            </div>  
                        
                            <div class="position-relative form-group"><label for="exampleText" class=""><div class="position-relative form-check form-check-inline"><label class="form-check-label"><input type="radio" class="form-check-input" name="type1" value="html">HTML</label></div>


                            <div class="position-relative form-check form-check-inline"><label class="form-check-label"><input type="radio" class="form-check-input" name="type1" value="link">Preview Link</label></div></label>
                            <input type="text"  name="notes" id="notes" class="form-control" placeholder="Notes/Variation Name"></textarea>
                            <textarea name="text" id="exampleText" class="form-control" placeholder="Link/HTML"></textarea>
                            <button class="btn btn-primary" name="add" value="add">Submit</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </form>
                    </div>
                </div>
            </div>
                        </div>
                    </div>
            </div>
            
        </div>
    </div>
</div>