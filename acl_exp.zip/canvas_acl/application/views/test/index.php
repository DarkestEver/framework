

<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  

  Comment: <textarea name="comment" rows="5" cols="40"></textarea>

  <br><br>
  <input type="submit" name="submit" value="Submit">  
</form>
