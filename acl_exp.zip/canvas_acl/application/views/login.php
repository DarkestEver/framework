<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">
		<title>Canvas - Login</title>

		<!-- Custom fonts for this template-->
		<link href="<?=base_url()?>resources/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		<!-- Custom styles for this template-->
		<link href="<?=base_url()?>resources/css/application.css" rel="stylesheet" type="text/css" />
	</head>
  	<body class='login'>
  		<div class='wrapper'>
      		<div class='row'>
        		<div class='col-lg-12'>
          			<div class='brand text-center'>
            			<h1>
			              	<div class='logo-icon'>
                            	<img src="<?=base_url()?>resources/img/module_icon/canvas.png" alt="Canvas Logo" width="70" height="70">
			              	</div>
              				Canvas
            			</h1>
          			</div>
        		</div>
      		</div>
      		<div class='row'>
        		<div class='col-lg-12'>
          			<form class="user" action="<?=base_url()?>login" method="POST">
            			<fieldset class='text-center'>
              				<legend style="border: none;">Login to your account</legend>
              				<p><?php
								if ($error == 1) { echo "Too Many Login Attempts"; }
								if ($error == 2) { echo "Invalid Login Credentials."; }
								?>
							</p>
              				<div class='form-group'>
                				<input type='username' name='username' class='form-control form-control-user' id='username' aria-describedby='emailHelp' placeholder='Email address'>
              				</div>
              				<div class='form-group'>
                				<input type='password' name='password' class='form-control form-control-user' id='password' placeholder='Password'>
              				</div>
              				<div class='text-center'>
                				<div class='checkbox'>
                  					<label>
                    					<input type='checkbox'>Remember me
                  					</label>
                				</div>
								<input class="btn btn-default" type="submit" value="Sign in">
                				<br><br>
                				<a href="forgot-password.html">Forgot password?</a>
                				<br>
								<a href="register.html">Create an Account!</a>
              				</div>
            			</fieldset>
          			</form>
        		</div>
      		</div>
    	</div>
		<!-- Bootstrap core JavaScript-->
		<script src="<?=base_url()?>resources/vendor/jquery/jquery.min.js"></script>
		<script src="<?=base_url()?>resources/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
		<!-- Core plugin JavaScript-->
		<script src="<?=base_url()?>resources/vendor/jquery-easing/jquery.easing.min.js"></script>
		<!-- Custom scripts for all pages-->
		<script src="<?=base_url()?>resources/js/sb-admin-2.min.js"></script>
	</body>
</html>
