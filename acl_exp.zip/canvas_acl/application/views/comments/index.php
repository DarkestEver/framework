
<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fas fa-bars"></i>
            </div>
            <div>Campaigns : <b><lebel id="campaing_name_selected_from_menu"><?php if(isset($campaign_name)) {echo $campaign_name;} ?></lebel></b>
                <div class="page-title-subheading">Comments
                </div>
            </div>
        </div>
        <div class="page-title-actions">
            <div class="d-inline-block dropdown">
                
                
            </div>
        </div>    </div>
</div>

        <div class="container">
            
            <?php echo $comments ?>
            
            <div class="contact-form">
                <h3 class="comment-reply-title">
                    Leave a Reply
                </h3>

                <p class="notice error"><?= $this->session->flashdata('error_msg') ?></p><br/>

                <form id="comment_form" action="<?php echo base_url().'comments/add_comment/'.$campaign_id ?>" method='post'>
                    <div class="form-group">
                        <label for="comment_name">Name:</label>
                        <input class="form-control" type="text" required name="comment_name" id='name' value=""/>
                    </div>
                    <div class="form-group">
                        <label for="comment">Comment :</label>
                        <textarea class="form-control" name="comment_body" value="" id='comment'></textarea>
                    </div>
                    <input type='hidden' name='parent_id' value="0" id='parent_id' />
                    <input type='hidden' name='campaign_id' value="<?php echo $campaign_id ?>" id='parent_id'/>

                    <div id='submit_button'>
                        <input class="btn btn-success" type="submit" name="submit" value="add comment"/>
                    </div>
                </form>
            </div>
        </div><!-- /.container -->



