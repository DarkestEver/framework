<?php
defined('BASEPATH') OR exit('No direct script access allowed');

  ?>

<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fas fa-bars"></i>
            </div>
          
            </div>
        </div>
        <div class="page-title-actions">
            <div class="d-inline-block dropdown">

                

            </div>
        </div>  
</div>



<div class="row"> 
    <!-- Draggable container --> 
     <div class="col-md-5"> 
       <div class="row col-md-5" style="position: fixed;">
       <div class="card" style="width: 100%">
        <div class="card-header-tab card-header" style="height: auto;">
            <div class="card-header-title">
                <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                   <?php foreach ($modules_category as $key => $category) { ?>
                    <li class="nav-item">
                        <a role="tab" class="nav-link show" id="tab-<?php echo $category['id']; ?>" data-toggle="tab" href="#tab-content-<?php echo $category['id']; ?>" aria-selected="false">
                            <span><?php echo $category['mc_name']; ?></span>
                        </a>
                    </li>
                    <?php }    ?>   
                </ul>
            </div>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <?php foreach ($modules_category as $key => $category) { ?>
                <div class="tab-pane tabs-animation fade" id="tab-content-<?php echo $category['id']; ?>" role="tabpanel">
                    <div class="row">
                        <div class="col-md-12">
                            <?php foreach ($modules as $v) { if ($category['id'] == $v['module_category_id']) { 
                        echo ' <div data-toggle="tooltip" title="'.$v['description'].'"  class="draggable mb-2 mr-2 border-0 btn-transition btn btn-outline-info" id="' .$v['module_key'] .'" data-module="'.$v['module_key'] .'">' 
                        .$v['module_name'] 
                        .'</div>'; } } ?> 
                        </div>
                    </div>
                </div>
                <?php }    ?>
            </div>
        </div>
      </div> 
    </div>
    </div>
   
    <div class="col-md-7"> 
        <div class="card shadow" style="min-height:100px;width:600px;padding: 0px;margin: auto;"> 
            <ul class="card-body droppable" id="droppable" style="list-style: none;padding: 0px;margin:0px;" width="600">
                   
            </ul>
            <hr>
            <ul class="card-body droppable" id="droppable2" style="list-style: none;padding: 0px;margin:0px;" width="600">
                   
            </ul>
         </div>
                <ul id="moduleshid" style="display:none">
                <?php foreach ($modules as $v) {
                    echo '<li class="'.$v['module_key'].' closeparent" style="padding: 0px 0 0px 0;">';
                    echo '<img  title="description" src="'.site_url().'resources/img/module_icon/'. $v['module_key'].'.png">';
                    echo '</li>';
                } ?>
            </ul>
    </div>

<style type="text/css">
    .ui-widget-content {
    background: #ececec;
}

.ui-accordion .ui-accordion-content {
padding: 0px;
}
</style>