<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
            <!-- Example Tables Card -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> Master CSS 
                    <a href="#"  class="btn btn-secondary" id="add_new">+</a>
                </div>
                <div class="card-block">
                    <div class="table-responsive">
                        <table class="table table-bordered wrap table-responsives" width="100%" id="dataTable" cellspacing="0"  style="word-break: break-word;">
                            <thead>
                                <tr>
                                    <th  width="30%">CSS Name</th>
                                    <th  width="70%">Inline CSS Style</th>
                                    
                                </tr>
                            </thead>

                            <tbody>
                            <?php foreach ($list as $v) { ?>
                                <tr>
                                    
                                    <td><?=$v["css_name"]?></td>
                                    <td class="editkey" id="<?=$v["uuid"]?>"> <?=$v["inline_css"]?></td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


<!-- Copy Email -->
<div class="modal fade" id="new_css_model" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">New CSS</span></h5>
            </div>
            <div class="modal-body">
                    <div class='row'>
                        <div class="col-lg-12">
                             <div class="form-group row">
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control error_message" name="input_new_name" id="input_new_name" placeholder="Name">
                                    </div>
                             </div>
                        </div>
                        <div class="col-lg-12">
                             <div class="form-group row">
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control error_message" name="input_new_css" id="input_new_css" placeholder="Inline CSS">
                                    </div>
                             </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-primary" value="Save" id="btn_new_css_model" />
            </div>
        </div>
    </div>
</div>