<div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="fas fa-cogs"></i>
                                    </div>
                                    <div><?php echo $page_title?>
                                        <div class="page-title-subheading">
                                            <?php echo $page_sub_title?>
                                        </div>
                                    </div>
                                </div>
                                <div class="page-title-actions">
                                    <a href="<?php echo site_url().'settings/component'?>" class="btn mb-2 mr-2 border-0 btn-transition btn btn-outline-primary">
                                            <span class="btn-icon-wrapper pr-2 opacity-7">
                                                <i class="fa fa-business-time fa-w-20"></i>
                                            </span>
                                            Components
                                    </a>
                                    <a href="<?php echo site_url().'settings/master_css'?>" class="btn mb-2 mr-2 border-0 btn-transition btn btn-outline-primary">
                                            <span class="btn-icon-wrapper pr-2 opacity-7">
                                                <i class="fa fa-business-time fa-w-20"></i>
                                            </span>
                                            Master CSS
                                    </a>
                                   <a href="<?php echo site_url().'settings/admins'?>" class="btn mb-2 mr-2 border-0 btn-transition btn btn-outline-primary">
                                            <span class="btn-icon-wrapper pr-2 opacity-7">
                                                <i class="fa fa-business-time fa-w-20"></i>
                                            </span>
                                            User
                                    </a>
                                     <a href="<?php echo site_url().'settings/groups'?>" class="btn mb-2 mr-2 border-0 btn-transition btn btn-outline-primary">
                                            <span class="btn-icon-wrapper pr-2 opacity-7">
                                                <i class="fa fa-business-time fa-w-20"></i>
                                            </span>
                                            User Group
                                    </a>
                                     <a href="<?php echo site_url().'settings/countries'?>" class="btn mb-2 mr-2 border-0 btn-transition btn btn-outline-primary">
                                            <span class="btn-icon-wrapper pr-2 opacity-7">
                                                <i class="fa fa-business-time fa-w-20"></i>
                                            </span>
                                            Country
                                    </a>
                                     <a href="<?php echo site_url().'settings/apis'?>" class="btn mb-2 mr-2 border-0 btn-transition btn btn-outline-primary">
                                            <span class="btn-icon-wrapper pr-2 opacity-7">
                                                <i class="fa fa-business-time fa-w-20"></i>
                                            </span>
                                            API
                                    </a>

                                </div>    </div>
                        </div>