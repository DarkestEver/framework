<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
            <!-- Example Tables Card -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> API List <a href="<?=base_url()?>settings/apis/add"><button class="btn btn-primary">+</button></a>
                </div>
                <div class="card-block">
                    <div class="table-responsive">
                        <table class="table table-bordered wrap table-responsives" width="100%" id="dataTable" cellspacing="0"  style="word-break: break-word;">
                            <thead>
                                <tr>

                                    <th>Name</th>
                                    <th>Client Id</th>
                                    <th>Client Secret</th>
                                    <th>Auth</th>
                                    <th>Rest</th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody>
                            <?php foreach ($groups as $v) { ?>
                                <tr>
                                    <td><?=$v["api_name"]?></td>
                                    <td><?=$v["client_id"]?></td>
                                    <td><?=$v["client_secret"]?></td>
                                    <td><?=$v["auth_url"]?></td>
                                    <td><?=$v["rest_url"]?></td>
                                    <td><form method="POST" action="" style="display:inline;"><input type="hidden" name="id" value="<?=$v["id"]?>"></form> <a href="<?=base_url()?>settings/apis/edit/<?=$v["id"]?>"><button class="btn btn-primary"><i class="fas fa-pen-square"></i></button></a> </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>