<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (!empty($result))
{
  $result = $result[0];
  $post_type = 'edit';
}
else
{
  $post_type = 'save';
}
?>
        <form method="POST"  >
            <input type="hidden" name= "action" value="<?php echo $post_type;?>">
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Module Category</label>
              <div class="col-10">
                <?php if (empty($result)) { ?>
                <select class="form-control" name="module_category_id" required  >
                <?php 
                foreach ($groups as $v) {
                  echo "<option value='".$v["id"]."'>".$v["mc_name"]."</option>";
                } ?>
                </select>
                <?php  }  else { ?>
                  <label for="example-text-input" class="col-2 col-form-label"><?php echo  $result['mc_name']; ?></label>
                 <?php  }  ?> 
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Module Name</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['module_name'] :''   ;?>" name="module_name" placeholder="module name" <?php echo (!empty($result))?'readonly="readonly"':''   ;?> >
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Module HTML</label>
              <div class="col-10">
                <textarea class="form-control" name="module_html" placeholder="module html"><?php echo (!empty($result))?$result['module_html'] :'';?></textarea>
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Module Key</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['module_key'] :''   ;?>" name="module_key" placeholder="module key">
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Content Block</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['content_block'] :''   ;?>" name="content_block" placeholder="content block key name">
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Description</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['description'] :''   ;?>" name="description" placeholder="description">
              </div> 
            </div>

            <div class="form-group row">
              <div class="col-10">
                <input type="submit" value="<?php echo ucfirst($post_type);?>" class="btn btn-primary">
                <?php if($post_type =="edit") {
                  echo '<input type="submit" name="submit" value="delete" class="btn btn-primary">';
                } ?>
              </div>
            </div>


        </form>
