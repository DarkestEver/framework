<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
            <!-- Example Tables Card -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> API List <a href="<?=base_url()?>settings/component/add"><button class="btn btn-primary">+</button></a>
                </div>
                <div class="card-block">
                    <div class="table-responsive">
                        <table class="table table-bordered wrap table-responsives" width="100%" id="dataTable" cellspacing="0"  style="word-break: break-word;">
                            <thead>
                                <tr>
                                    <th>Sno</th>
                                    <th>Category</th>
                                    <th>Name</th>
                                    <th>Key</th>
                                    <th>SFMC Block Key</th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody>
                            <?php $count=1; foreach ($list as $v) { ?>
                                <tr>
                                    <td><?=$count?></td>
                                    <td><?=$v["mc_name"]?></td>
                                    <td><?=$v["module_name"]?></td>
                                    <td><?=$v["module_key"]?></td>
                                    <td><?=$v["content_block"]?></td>
                                    <td>
                                        <a data-toggle="tooltip" title="Edit" href="<?=base_url()?>settings/component/edit/<?=$v["id"]?>"><i class="fas fa-pen-square"></i></a>
                                        <a data-toggle="tooltip" title="Key Mapping" href="<?=base_url()?>settings/customkeymapping/<?=$v["id"]?>"><i class="fas fa-sitemap"></i></a>
                                    </td>
                                </tr>
                            <?php $count= $count +1; } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>