<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
            <!-- Example Tables Card -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> API List <a href="<?=base_url()?>settings/component/add"><button class="btn btn-primary">+</button></a>
                </div>
                <div class="card-block">
                    <div class="table-responsive">
                        <table class="table table-bordered wrap table-responsives" width="100%" id="dataTable" cellspacing="0"  style="word-break: break-word;">
                            <thead>
                                <tr>
                                    <th  width="25%">Element</th>
                                    <th  width="15%">Attribute</th>
                                    <th  width="60%">Key</th>
                                    
                                </tr>
                            </thead>

                            <tbody>
                            <?php foreach ($list as $v) { ?>
                                <tr>
                                    <td><?=$v["elements"]?></td>
                                    <td><?=$v["old_key"]?></td>
                                    <td class="editkey" id="<?=$v["uuid"]?>"> <?=$v["new_key"]?></td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>