<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (!empty($result))
{
  $result = $result[0];
  $post_type = 'edit';
}
else
{
  $post_type = 'save';
}
?>
 <form method="POST" action="#"  >
            <input type="hidden" name="action" value="<?php echo $post_type;?>">
             <input type="hidden" name="id" value="<?php echo (!empty($result))?$result['id'] :''   ;?>">
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Vertical Name</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['vertical_name'] :''   ;?>" placeholder="" name="vertical_name"   >
              </div>
            </div>

            <div class="form-group row">
              <div class="col-10">
                <input type="submit" value="<?php echo ucfirst($post_type);?>" class="btn btn-primary">
                <?php if($post_type =="edit") {
                  echo '<input type="submit" name="action" value="delete" class="btn btn-primary">';
                } ?>
              </div>
            </div>


        </form>
