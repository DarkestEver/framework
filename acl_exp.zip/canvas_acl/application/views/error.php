<div class="row m-0">
	<div class="col-md-12">
        <div class="alert alert-warning fade show" role="alert"><h5>Note : </h5>
            <p class="mb-0"><?php echo $error; ?></p></div>
    </div>
</div>