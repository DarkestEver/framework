-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2020 at 06:09 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `form_builder`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `last_signin` int(11) DEFAULT NULL,
  `created_date` int(11) NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `verification_key` varchar(255) NOT NULL,
  `admin_group` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zip` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`, `last_signin`, `created_date`, `ip`, `verification_key`, `admin_group`, `name`, `address`, `address2`, `city`, `state`, `zip`) VALUES
(1, 'admin', 'a1fa99a1724242d0931d4f9c62dd56a6', 'support@lenapo.com', 2147483647, 123132121, '::1', 'dfasdfa3a33a', 1, 'Joseph Opanel', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_groups`
--

CREATE TABLE `admin_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_groups`
--

INSERT INTO `admin_groups` (`id`, `name`) VALUES
(1, 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE `forms` (
  `UUID` varchar(128) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `form_name` varchar(50) DEFAULT NULL,
  `tablename` varchar(50) DEFAULT NULL,
  `createdby` int(11) DEFAULT NULL,
  `createddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifieddate` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modifiedby` int(11) DEFAULT NULL,
  `public_name` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`UUID`, `id`, `form_name`, `tablename`, `createdby`, `createddate`, `modifieddate`, `modifiedby`, `public_name`) VALUES
('b833481a-ae63-11ea-ba06-3417eb570eea', 1, 'test', NULL, NULL, '2020-06-14 17:24:46', '2020-06-14 22:54:46', NULL, 'test'),
('f85a2da5-ae81-11ea-ba06-3417eb570eea', 2, 'file', NULL, NULL, '2020-06-14 21:01:19', '2020-06-15 02:31:19', NULL, 'file'),
('87212e4c-aeeb-11ea-ba06-3417eb570eea', 3, 'All', NULL, NULL, '2020-06-15 09:36:34', '2020-06-15 15:06:34', NULL, 'all'),
('167c5749-af0e-11ea-ba06-3417eb570eea', 4, 'Hemmu', NULL, NULL, '2020-06-15 13:43:57', '2020-06-15 19:13:57', NULL, 'hemmu'),
('68a2c26b-b162-11ea-8ebf-3417eb570eea', 5, 'jacky', NULL, NULL, '2020-06-18 12:50:40', '2020-06-18 18:20:40', NULL, 'jaky'),
('ff300b4c-b163-11ea-8ebf-3417eb570eea', 6, 'survey', NULL, NULL, '2020-06-18 13:02:02', '2020-06-18 18:32:02', NULL, 'survey');

--
-- Triggers `forms`
--
DELIMITER $$
CREATE TRIGGER `forms_before_insert_uuid` BEFORE INSERT ON `forms` FOR EACH ROW BEGIN
SET NEW.uuid = UUID();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `form_data`
--

CREATE TABLE `form_data` (
  `id` int(11) NOT NULL,
  `fi_id` int(128) DEFAULT NULL,
  `value` text,
  `f_id` int(11) NOT NULL,
  `groups` varchar(128) NOT NULL,
  `createddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_data`
--

INSERT INTO `form_data` (`id`, `fi_id`, `value`, `f_id`, `groups`, `createddate`) VALUES
(1, 1, 'Hemmu', 1, '3412f926273b2a6c2d3b594a72b23d44', '2020-06-14 17:26:39'),
(2, 2, 'Himanshu Singh', 1, '3412f926273b2a6c2d3b594a72b23d44', '2020-06-14 17:26:39'),
(3, 4, '/resources/uploads/2020/06/14/14.png||/resources/uploads/2020/06/14/15.png', 2, 'e8a8da30b08ea4429348599e7d013066', '2020-06-14 21:03:06'),
(4, 4, '/resources/uploads/2020/06/14/16.png||/resources/uploads/2020/06/14/17.png', 2, 'a9d398fda7ba5dfb7c93ae8633194eeb', '2020-06-14 21:03:09'),
(5, 6, 'jhhhhj', 2, '488aa167680a86650c546326358ea0f2', '2020-06-14 23:10:51'),
(6, 4, '/resources/uploads/2020/06/15/1.png', 2, '488aa167680a86650c546326358ea0f2', '2020-06-14 23:10:51'),
(7, 7, 'twt', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(8, 8, 'twt', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(9, 9, '55', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(10, 10, '55', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(11, 11, 'on', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(12, 12, 'num2', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(13, 13, 'num2', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(14, 14, 'num', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(15, 15, 'num', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(16, 20, '#601010', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(17, 21, '2020-06-05', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(18, 22, 'adminhjjhhj@ff.com', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:24'),
(19, 25, '2020-07', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:25'),
(20, 26, '93', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:25'),
(21, 27, 'ggfhfhgf g hg ', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:25'),
(22, 18, 'error', 3, 'f1539a54122d535bf65885fed98b1e16', '2020-06-15 10:57:25'),
(23, 7, 'jhhjh', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(24, 8, 'hjhhj', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(25, 9, '7767', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(26, 10, '77767776', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(27, 11, 'on', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(28, 12, 'num', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(29, 13, 'num2', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(30, 14, 'num2', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(31, 15, 'num2', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(32, 20, '#2f2323', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(33, 22, 'admin@sdsd.com', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(34, 24, 'sddsd', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(35, 25, '2020-06', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(36, 26, '50', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:33'),
(37, 27, 'dsd', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:34'),
(38, 28, '16:38', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:34'),
(39, 18, '/resources/uploads/2020/06/15/11.png||/resources/uploads/2020/06/15/12.png', 3, '3074e970141291fb08dedfe72ae163b4', '2020-06-15 11:08:34'),
(40, 7, 'jjj', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:46'),
(41, 8, 'hjhhj', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:46'),
(42, 9, '7767', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(43, 10, '77767776', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(44, 11, 'on', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(45, 12, 'num', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(46, 13, 'num2', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(47, 14, 'num2', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(48, 15, 'num2', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(49, 20, '#2f2323', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(50, 22, 'admin@sdsd.com', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(51, 24, 'sddsd', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(52, 25, '2020-06', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(53, 26, '50', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(54, 27, 'dsd', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(55, 28, '16:38', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(56, 18, '/resources/uploads/2020/06/15/13.png||/resources/uploads/2020/06/15/14.png', 3, 'd7c9a8dfe21ba9e1972c6aefbc969b82', '2020-06-15 11:21:47'),
(57, 7, 'kj', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:24'),
(58, 8, 'admin', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:24'),
(59, 9, '7', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:24'),
(60, 10, '7', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:24'),
(61, 12, 'num', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:24'),
(62, 13, 'num||num2', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:24'),
(63, 14, 'num', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:24'),
(64, 15, 'num||num2', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:25'),
(65, 20, '#000000', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:25'),
(66, 22, 'admin@as.cp', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:25'),
(67, 19, 'error', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:25'),
(68, 18, 'error', 3, 'ed6bd3d8b809b22aa0d2defc87dd881d', '2020-06-15 12:29:25'),
(69, 29, '1', 4, '5ae9248c5db4ac05ce75b99fa4137d9b', '2020-06-15 13:49:47'),
(70, 30, '1', 4, '5ae9248c5db4ac05ce75b99fa4137d9b', '2020-06-15 13:49:47'),
(71, 31, '/resources/uploads/2020/06/15/17.png||/resources/uploads/2020/06/15/18.png', 4, '5ae9248c5db4ac05ce75b99fa4137d9b', '2020-06-15 13:49:47'),
(72, 7, 'a', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(73, 8, 'a', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(74, 9, '6', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(75, 10, 'a', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(76, 11, 'on', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(77, 12, 'num2', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(78, 13, 'num||num2', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(79, 14, 'num2', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(80, 15, 'num||num2', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(81, 20, '#7f3434', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(82, 21, '2020-06-13', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(83, 22, 'admin@dkjs.com', 3, '58f3987a42fbb8e24a9baa84a5c93614', '2020-06-15 18:33:10'),
(84, 7, 'a', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:17'),
(85, 8, 'a', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:17'),
(86, 9, '6', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(87, 10, 'a', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(88, 11, 'on', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(89, 12, 'num2', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(90, 13, 'num||num2', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(91, 14, 'num2', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(92, 15, 'num||num2', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(93, 20, '#7f3434', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(94, 21, '2020-06-13', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(95, 22, 'admin@dkjs.com', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(96, 19, '/resources/uploads/2020/06/15/19.png||/resources/uploads/2020/06/15/110.png', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(97, 18, '/resources/uploads/2020/06/15/111.png||/resources/uploads/2020/06/15/112.png', 3, '635d14b71b97109c45ba5fbf5db6be58', '2020-06-15 18:35:18'),
(98, 7, 'gg', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:04'),
(99, 8, 'a', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:04'),
(100, 9, '6', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:04'),
(101, 10, 'a', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:04'),
(102, 11, 'on', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:05'),
(103, 12, 'num2', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:05'),
(104, 13, 'num||num2', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:05'),
(105, 14, 'num2', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:05'),
(106, 15, 'num||num2', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:05'),
(107, 20, '#7f3434', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:05'),
(108, 21, '2020-06-13', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:05'),
(109, 22, 'admin@dkjs.com', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:05'),
(110, 19, '/resources/uploads/2020/06/15/113.png||/resources/uploads/2020/06/15/114.png', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:05'),
(111, 18, '/resources/uploads/2020/06/15/115.png||/resources/uploads/2020/06/15/116.png', 3, '4baa1b5ce1c6d190c3db93f14015696e', '2020-06-15 18:39:05'),
(112, 7, 'jjj', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:42'),
(113, 8, 'a', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:42'),
(114, 9, '6', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:42'),
(115, 10, 'a', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:42'),
(116, 11, 'on', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:42'),
(117, 12, 'num2', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:42'),
(118, 13, 'num||num2', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:42'),
(119, 14, 'num2', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:42'),
(120, 15, 'num||num2', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:42'),
(121, 20, '#7f3434', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:43'),
(122, 21, '2020-06-13', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:43'),
(123, 22, 'admin@dkjs.com', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:43'),
(124, 19, '/resources/uploads/2020/06/15/117.png||/resources/uploads/2020/06/15/118.png', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:43'),
(125, 18, '/resources/uploads/2020/06/15/119.png||/resources/uploads/2020/06/15/120.png', 3, 'ae585f1205b6089ef16ed2d2daafa501', '2020-06-15 18:41:43'),
(126, 33, 'name', 5, '9c63fe606f9229cd55ec2b2678959754', '2020-06-18 12:52:35'),
(127, 34, 'sing', 5, '9c63fe606f9229cd55ec2b2678959754', '2020-06-18 12:52:35'),
(128, 35, '/resources/uploads/2020/06/18/1.png||/resources/uploads/2020/06/18/11.png', 5, '9c63fe606f9229cd55ec2b2678959754', '2020-06-18 12:52:35'),
(129, 37, 'keshav', 6, '4a31beaa296ad93ddffe997ab571fa39', '2020-06-18 13:05:57'),
(130, 38, 'i am stupid', 6, '4a31beaa296ad93ddffe997ab571fa39', '2020-06-18 13:05:57'),
(131, 39, 'Pubg', 6, '4a31beaa296ad93ddffe997ab571fa39', '2020-06-18 13:05:57'),
(132, 40, '2020-07-01', 6, '4a31beaa296ad93ddffe997ab571fa39', '2020-06-18 13:05:57'),
(133, 41, 'kes@sjndjkas.co', 6, '4a31beaa296ad93ddffe997ab571fa39', '2020-06-18 13:05:57');

-- --------------------------------------------------------

--
-- Table structure for table `form_inputs`
--

CREATE TABLE `form_inputs` (
  `uuid` varchar(128) DEFAULT NULL,
  `fi_id` int(11) NOT NULL,
  `form_id` int(11) DEFAULT NULL,
  `form_group` varchar(50) DEFAULT NULL,
  `label` varchar(50) DEFAULT NULL,
  `field_id` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `placeholder` varchar(250) DEFAULT NULL,
  `htmlClass` varchar(250) DEFAULT NULL,
  `default_value` varchar(250) DEFAULT NULL,
  `style` varchar(500) DEFAULT NULL,
  `required` int(11) DEFAULT NULL,
  `disabled` int(11) DEFAULT NULL,
  `length` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `createdby` int(11) DEFAULT NULL,
  `createddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifieddate` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modifiedby` int(11) DEFAULT NULL,
  `listed` int(11) NOT NULL DEFAULT '1',
  `editable` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_inputs`
--

INSERT INTO `form_inputs` (`uuid`, `fi_id`, `form_id`, `form_group`, `label`, `field_id`, `type`, `placeholder`, `htmlClass`, `default_value`, `style`, `required`, `disabled`, `length`, `position`, `createdby`, `createddate`, `modifieddate`, `modifiedby`, `listed`, `editable`) VALUES
('ca31bfa8-ae63-11ea-ba06-3417eb570eea', 1, 1, NULL, 'Doc Name', 'doc_name', 'text', 'Doc Name', '', '', '', 1, NULL, 64, NULL, NULL, '2020-06-14 17:25:16', '2020-06-14 22:56:20', NULL, 1, 1),
('d6086949-ae63-11ea-ba06-3417eb570eea', 2, 1, NULL, 'Full Name', 'full_name', 'text', 'Full Name', '', '', '', 1, NULL, 64, NULL, NULL, '2020-06-14 17:25:36', '2020-06-14 22:56:17', NULL, 1, 1),
('e0a78a93-ae63-11ea-ba06-3417eb570eea', 3, 1, NULL, 'Submit', 'submit', 'submit', '', '', '', '', NULL, NULL, 64, NULL, NULL, '2020-06-14 17:25:54', '2020-06-14 22:55:54', NULL, 0, 1),
('171c8d46-ae82-11ea-ba06-3417eb570eea', 4, 2, NULL, 'Select Multiple Files', 'select_multiple_files', 'file', 'jpg|png', '', '', '', NULL, NULL, 0, NULL, NULL, '2020-06-14 21:02:10', '2020-06-15 02:33:35', NULL, 1, 1),
('1fbc2bca-ae82-11ea-ba06-3417eb570eea', 5, 2, NULL, 'Save', 'save', 'submit', '', '', '', '', NULL, NULL, 0, NULL, NULL, '2020-06-14 21:02:25', '2020-06-15 02:32:25', NULL, 0, 1),
('05f631fc-ae94-11ea-ba06-3417eb570eea', 6, 2, NULL, 'Input Name1', 'input_name1', 'text', 'Input Name1', '', '', '', 1, NULL, 77, NULL, NULL, '2020-06-14 23:10:33', '2020-06-15 04:41:03', NULL, 1, 1),
('11f9cf7f-aef1-11ea-ba06-3417eb570eea', 7, 3, NULL, 'text', 'text', 'text', 'text', '', '', '', 1, NULL, 44, NULL, NULL, '2020-06-15 10:16:14', '2020-06-15 15:46:14', NULL, 1, 1),
('1c4e58e1-aef1-11ea-ba06-3417eb570eea', 8, 3, NULL, 'password', 'password', 'password', 'password', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:16:32', '2020-06-15 15:46:32', NULL, 1, 1),
('2236e5f7-aef1-11ea-ba06-3417eb570eea', 9, 3, NULL, 'number', 'number', 'number', 'num', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:16:42', '2020-06-15 15:46:42', NULL, 1, 1),
('27a8cd19-aef1-11ea-ba06-3417eb570eea', 10, 3, NULL, 'textarea', 'textarea', 'textarea', 'num', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:16:51', '2020-06-15 15:46:51', NULL, 1, 1),
('34d8f0da-aef1-11ea-ba06-3417eb570eea', 11, 3, NULL, 'checkbox', 'checkbox', 'checkboxinput', 'num||num2', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:17:13', '2020-06-15 15:47:13', NULL, 1, 1),
('3a378064-aef1-11ea-ba06-3417eb570eea', 12, 3, NULL, 'select', 'select', 'select', 'num||num2', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:17:22', '2020-06-15 15:47:22', NULL, 1, 1),
('3fcc2e83-aef1-11ea-ba06-3417eb570eea', 13, 3, NULL, 'Select Multiple', 'select_multiple', 'selectmultiple', 'num||num2', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:17:31', '2020-06-15 15:47:31', NULL, 1, 1),
('4775b0a6-aef1-11ea-ba06-3417eb570eea', 14, 3, NULL, 'Select2', 'select2', 'select2', 'num||num2', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:17:44', '2020-06-15 15:47:44', NULL, 1, 1),
('4eae6091-aef1-11ea-ba06-3417eb570eea', 15, 3, NULL, 'Select Multiple2', 'select_multiple2', 'selectmultiple2', 'num||num2', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:17:56', '2020-06-15 15:47:56', NULL, 1, 1),
('57144258-aef1-11ea-ba06-3417eb570eea', 16, 3, NULL, 'button', 'button', 'button', 'button', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:18:10', '2020-06-15 15:48:10', NULL, 1, 1),
('60ee21fe-aef1-11ea-ba06-3417eb570eea', 17, 3, NULL, 'submit', 'submit', 'submit', 'submit', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:18:27', '2020-06-15 15:48:27', NULL, 1, 1),
('70e63a1d-aef1-11ea-ba06-3417eb570eea', 18, 3, NULL, 'Image', 'image', 'file', 'Image', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:18:54', '2020-06-15 15:48:54', NULL, 1, 1),
('76f53bea-aef1-11ea-ba06-3417eb570eea', 19, 3, NULL, 'File Upload', 'file_upload', 'filedoc', 'Image', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:19:04', '2020-06-15 16:24:37', NULL, 1, 1),
('81b14a96-aef1-11ea-ba06-3417eb570eea', 20, 3, NULL, 'color', 'color', 'color', 'color', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:19:22', '2020-06-15 15:49:22', NULL, 1, 1),
('8735a557-aef1-11ea-ba06-3417eb570eea', 21, 3, NULL, 'date', 'date', 'date', 'color', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:19:31', '2020-06-15 15:49:31', NULL, 1, 1),
('94cfa5e1-aef1-11ea-ba06-3417eb570eea', 22, 3, NULL, 'email', 'email', 'email', 'color', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:19:54', '2020-06-15 15:49:54', NULL, 1, 1),
('aad777d2-aef1-11ea-ba06-3417eb570eea', 23, 3, NULL, 'hidden', 'hidden', 'hidden', 'hidden', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:20:31', '2020-06-15 15:50:31', NULL, 1, 1),
('bce772c6-aef1-11ea-ba06-3417eb570eea', 24, 3, NULL, 'imagebutton', 'imagebutton', 'imagebutton', '', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:21:01', '2020-06-15 15:51:01', NULL, 1, 1),
('c80c06d6-aef1-11ea-ba06-3417eb570eea', 25, 3, NULL, 'month', 'month', 'month', 'month', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:21:20', '2020-06-15 15:51:20', NULL, 1, 1),
('d1b85e15-aef1-11ea-ba06-3417eb570eea', 26, 3, NULL, 'range', 'range', 'range', 'range', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:21:36', '2020-06-15 15:51:36', NULL, 1, 1),
('da845e93-aef1-11ea-ba06-3417eb570eea', 27, 3, NULL, 'tel', 'tel', 'tel', 'tel', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:21:51', '2020-06-15 15:51:51', NULL, 1, 1),
('e4c7eb7c-aef1-11ea-ba06-3417eb570eea', 28, 3, NULL, 'time', 'time', 'time', 'time', '', '', '', NULL, NULL, 44, NULL, NULL, '2020-06-15 10:22:08', '2020-06-15 15:52:08', NULL, 1, 1),
('357c470f-af0e-11ea-ba06-3417eb570eea', 29, 4, NULL, 'Document Name', 'document_name', 'text', 'Document Name', '', '', '', 1, NULL, 250, NULL, NULL, '2020-06-15 13:44:49', '2020-06-15 19:14:49', NULL, 1, 1),
('473a74d3-af0e-11ea-ba06-3417eb570eea', 30, 4, NULL, 'Project Name', 'project_name', 'text', 'Document Name', '', '', '', 1, NULL, 250, NULL, NULL, '2020-06-15 13:45:19', '2020-06-15 19:15:19', NULL, 1, 1),
('5b634c78-af0e-11ea-ba06-3417eb570eea', 31, 4, NULL, 'Upload Document Files', 'upload_document_files', 'filedoc', 'Select files', '', '', '', 1, NULL, 250, NULL, NULL, '2020-06-15 13:45:53', '2020-06-15 19:19:12', NULL, 1, 1),
('76859766-af0e-11ea-ba06-3417eb570eea', 32, 4, NULL, 'Save', 'save', 'submit', '', '', '', '', NULL, NULL, 22, NULL, NULL, '2020-06-15 13:46:39', '2020-06-15 19:16:39', NULL, 1, 1),
('7235be28-b162-11ea-8ebf-3417eb570eea', 33, 5, NULL, 'j', 'j', 'text', 'j', '', '', '', 1, NULL, 6, NULL, NULL, '2020-06-18 12:50:56', '2020-06-18 18:20:56', NULL, 1, 1),
('76a11a05-b162-11ea-8ebf-3417eb570eea', 34, 5, NULL, 'jacky', 'jacky', 'text', 'j', '', '', '', 1, NULL, 6, NULL, NULL, '2020-06-18 12:51:03', '2020-06-18 18:21:03', NULL, 1, 1),
('81ab2be2-b162-11ea-8ebf-3417eb570eea', 35, 5, NULL, 'image', 'image', 'file', 'j', '', '', '', 1, NULL, 6, NULL, NULL, '2020-06-18 12:51:22', '2020-06-18 18:21:22', NULL, 1, 1),
('9ecab0d9-b162-11ea-8ebf-3417eb570eea', 36, 5, NULL, 'Submit', 'submit', 'submit', '', '', '', '', NULL, NULL, 333, NULL, NULL, '2020-06-18 12:52:11', '2020-06-18 18:22:11', NULL, 1, 1),
('21b4b4aa-b164-11ea-8ebf-3417eb570eea', 37, 6, NULL, 'Fname', 'fname', 'text', 'first name', '', '', '', 1, NULL, 50, NULL, NULL, '2020-06-18 13:03:00', '2020-06-18 18:33:00', NULL, 1, 1),
('30519c49-b164-11ea-8ebf-3417eb570eea', 38, 6, NULL, 'Description', 'description', 'textarea', 'Description', '', '', '', NULL, NULL, 500, NULL, NULL, '2020-06-18 13:03:24', '2020-06-18 18:33:24', NULL, 1, 1),
('46bc3912-b164-11ea-8ebf-3417eb570eea', 39, 6, NULL, 'Hobby', 'hobby', 'selectmultiple2', 'Chess||Pubg', '', '', '', NULL, NULL, 500, NULL, NULL, '2020-06-18 13:04:02', '2020-06-18 18:34:02', NULL, 1, 1),
('5317b9f7-b164-11ea-8ebf-3417eb570eea', 40, 6, NULL, 'dob', 'dob', 'date', 'dob', '', '', '', 1, NULL, 500, NULL, NULL, '2020-06-18 13:04:23', '2020-06-18 18:34:23', NULL, 1, 1),
('5b735140-b164-11ea-8ebf-3417eb570eea', 41, 6, NULL, 'email', 'email', 'email', 'email', '', '', '', 1, NULL, 500, NULL, NULL, '2020-06-18 13:04:37', '2020-06-18 18:34:37', NULL, 1, 1),
('61bd7750-b164-11ea-8ebf-3417eb570eea', 42, 6, NULL, 'submit', 'submit', 'submit', 'email', '', '', '', 1, NULL, 500, NULL, NULL, '2020-06-18 13:04:47', '2020-06-18 18:34:47', NULL, 1, 1);

--
-- Triggers `form_inputs`
--
DELIMITER $$
CREATE TRIGGER `form_inputs_before_insert_uuid` BEFORE INSERT ON `form_inputs` FOR EACH ROW BEGIN
SET NEW.uuid = UUID();
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `form_record_view`
--

CREATE TABLE `form_record_view` (
  `id` int(11) NOT NULL,
  `f_id` int(11) DEFAULT NULL,
  `html` text,
  `createdby` int(11) DEFAULT NULL,
  `createddate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifieddate` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modifiedby` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_record_view`
--

INSERT INTO `form_record_view` (`id`, `f_id`, `html`, `createdby`, `createddate`, `modifieddate`, `modifiedby`) VALUES
(1, 1, '<div class=\"pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center\">\n      <h1 class=\"display-4\">__doc_name__<br></h1>\n      <p class=\"lead\">__full_name__<br></p>\n    </div><div class=\"container\">\n      <div class=\"card-deck mb-3 text-center\">\n        <div class=\"card mb-4 box-shadow\">\n          <div class=\"card-header\">\n            <h4 class=\"my-0 font-weight-normal\">Free</h4>\n          </div>\n          <div class=\"card-body\">\n            <h1 class=\"card-title pricing-card-title\">$0 <small class=\"text-muted\">/ mo</small></h1>\n            <ul class=\"list-unstyled mt-3 mb-4\">\n              <li>10 users included</li>\n              <li>2 GB of storage</li>\n              <li>Email support</li>\n              <li>Help center access</li>\n            </ul>\n            <button type=\"button\" class=\"btn btn-lg btn-block btn-outline-primary\">Sign up for free</button>\n          </div>\n        </div>\n        <div class=\"card mb-4 box-shadow\">\n          <div class=\"card-header\">\n            <h4 class=\"my-0 font-weight-normal\">Pro</h4>\n          </div>\n          <div class=\"card-body\">\n            <h1 class=\"card-title pricing-card-title\">$15 <small class=\"text-muted\">/ mo</small></h1>\n            <ul class=\"list-unstyled mt-3 mb-4\">\n              <li>20 users included</li>\n              <li>10 GB of storage</li>\n              <li>Priority email support</li>\n              <li>Help center access</li>\n            </ul>\n            <button type=\"button\" class=\"btn btn-lg btn-block btn-primary\">Get started</button>\n          </div>\n        </div>\n        <div class=\"card mb-4 box-shadow\">\n          <div class=\"card-header\">\n            <h4 class=\"my-0 font-weight-normal\">Enterprise</h4>\n          </div>\n          <div class=\"card-body\">\n            <h1 class=\"card-title pricing-card-title\">$29 <small class=\"text-muted\">/ mo</small></h1>\n            <ul class=\"list-unstyled mt-3 mb-4\">\n              <li>30 users included</li>\n              <li>15 GB of storage</li>\n              <li>Phone and email support</li>\n              <li>Help center access</li>\n            </ul>\n            <button type=\"button\" class=\"btn btn-lg btn-block btn-primary\">Contact us</button>\n          </div>\n        </div>\n      </div>\n\n      <footer class=\"pt-4 my-md-5 pt-md-5 border-top\">\n        <div class=\"row\">\n          <div class=\"col-12 col-md\">\n            <img class=\"mb-2\" src=\"https://getbootstrap.com/docs/4.0/assets/brand/bootstrap-solid.svg\" alt=\"\" width=\"24\" height=\"24\">\n            <small class=\"d-block mb-3 text-muted\">© 2017-2018</small>\n          </div>\n          <div class=\"col-6 col-md\">\n            <h5>Features</h5>\n            <ul class=\"list-unstyled text-small\">\n              <li><a class=\"text-muted\" href=\"#\">Cool stuff</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Random feature</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Team feature</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Stuff for developers</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Another one</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Last time</a></li>\n            </ul>\n          </div>\n          <div class=\"col-6 col-md\">\n            <h5>Resources</h5>\n            <ul class=\"list-unstyled text-small\">\n              <li><a class=\"text-muted\" href=\"#\">Resource</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Resource name</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Another resource</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Final resource</a></li>\n            </ul>\n          </div>\n          <div class=\"col-6 col-md\">\n            <h5>About</h5>\n            <ul class=\"list-unstyled text-small\">\n              <li><a class=\"text-muted\" href=\"#\">Team</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Locations</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Privacy</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Terms</a></li>\n            </ul>\n          </div>\n        </div>\n      </footer>\n    </div>', NULL, '2020-06-14 00:37:47', '2020-06-15 02:28:57', NULL),
(6, 2, '<div class=\"row\"><div class=\"col-md-3\">__select_multiple_files__</div><div class=\"col-md-9\"><span style=\"font-family: Nunito, -apple-system, BlinkMacSystemFont, \" segoe=\"\" ui\",=\"\" roboto,=\"\" \"helvetica=\"\" neue\",=\"\" arial,=\"\" sans-serif,=\"\" \"apple=\"\" color=\"\" emoji\",=\"\" \"segoe=\"\" ui=\"\" symbol\",=\"\" \"noto=\"\" emoji\";\"=\"\"></span></div><div class=\"col-md-9\">__input_name1__</div></div>', NULL, '2020-06-14 21:04:18', '2020-06-15 04:44:40', NULL),
(7, 3, '<div class=\"pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center\">\n      <h1 class=\"display-4\">__text__<br></h1>\n      <p class=\"lead\">__password__<br></p>\n    </div><div class=\"container\">\n      <div class=\"card-deck mb-3 text-center\">\n        <div class=\"card mb-4 box-shadow\">\n          <div class=\"card-header\">\n            <h4 class=\"my-0 font-weight-normal\">Free</h4>\n          </div>\n          <div class=\"card-body\">\n            <h1 class=\"card-title pricing-card-title\">$0 <small class=\"text-muted\">/ mo</small></h1>\n            <ul class=\"list-unstyled mt-3 mb-4\">\n              <li><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>textarea - __textarea__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>checkbox - __checkbox__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>select - __select__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>Select Multiple - __select_multiple__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>Select2 - __select2__</label></div></li><li><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label><div class=\"col\" style=\"width: 244.5px;\"><label>Select Multiple2 - __select_multiple2__</label></div><div class=\"col\" style=\"width: 244.5px;\"><label>button - __button__</label></div><div class=\"col\" style=\"width: 244.5px;\"><label>submit - __submit__</label></div></label></div></li>\n            </ul>\n            <button type=\"button\" class=\"btn btn-lg btn-block btn-outline-primary\">Sign up for free</button>\n          </div>\n        </div>\n        <div class=\"card mb-4 box-shadow\">\n          <div class=\"card-header\">\n            <h4 class=\"my-0 font-weight-normal\">Pro</h4>\n          </div>\n          <div class=\"card-body\">\n            <h1 class=\"card-title pricing-card-title\">$15 <small class=\"text-muted\">/ mo</small></h1>\n            <ul class=\"list-unstyled mt-3 mb-4\">\n              <li><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><div class=\"col\" style=\"width: 244.5px;\"><label>Image - __image__</label></div><div class=\"col\" style=\"width: 244.5px;\"><label>File Upload - __file_upload__</label></div></div></li>\n            </ul>\n            <button type=\"button\" class=\"btn btn-lg btn-block btn-primary\">Get started</button>\n          </div>\n        </div>\n        <div class=\"card mb-4 box-shadow\">\n          <div class=\"card-header\">\n            <h4 class=\"my-0 font-weight-normal\">Enterprise</h4>\n          </div>\n          <div class=\"card-body\">\n            <h1 class=\"card-title pricing-card-title\">$29 <small class=\"text-muted\">/ mo</small></h1>\n            <ul class=\"list-unstyled mt-3 mb-4\">\n              <li><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>color - __color__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>date - __date__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>email - __email__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>hidden - __hidden__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>imagebutton - __imagebutton__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>month - __month__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>range - __range__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>tel - __tel__</label></div><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;; text-align: left;\"><label>time - __time__</label></div></li>\n            </ul>\n            <button type=\"button\" class=\"btn btn-lg btn-block btn-primary\">Contact us</button>\n          </div>\n        </div>\n      </div>\n\n      <footer class=\"pt-4 my-md-5 pt-md-5 border-top\">\n        <div class=\"row\">\n          <div class=\"col-12 col-md\">\n            <img class=\"mb-2\" src=\"https://getbootstrap.com/docs/4.0/assets/brand/bootstrap-solid.svg\" alt=\"\" width=\"24\" height=\"24\">\n            <small class=\"d-block mb-3 text-muted\">© 2017-2018</small>\n          </div>\n          <div class=\"col-6 col-md\">\n            <h5>Features</h5>\n            <ul class=\"list-unstyled text-small\">\n              <li><a class=\"text-muted\" href=\"#\">Cool stuff</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Random feature</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Team feature</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Stuff for developers</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Another one</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Last time</a></li>\n            </ul>\n          </div>\n          <div class=\"col-6 col-md\">\n            <h5>Resources</h5>\n            <ul class=\"list-unstyled text-small\">\n              <li><a class=\"text-muted\" href=\"#\">Resource</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Resource name</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Another resource</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Final resource</a></li>\n            </ul>\n          </div>\n          <div class=\"col-6 col-md\">\n            <h5>About</h5>\n            <ul class=\"list-unstyled text-small\">\n              <li><a class=\"text-muted\" href=\"#\">Team</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Locations</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Privacy</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Terms</a></li>\n            </ul>\n          </div>\n        </div>\n      </footer>\n    </div>', NULL, '2020-06-15 11:02:38', '2020-06-15 18:20:59', NULL),
(8, 4, '<table class=\"table\" border=\"1\" cellspacing=\"1\" cellpadding=\"1\" style=\"width: 400px;\"><tbody><tr><td>&nbsp;Document Name</td><td><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"><label>Project Name - </label></div></td><td><div class=\"col\" style=\"width: 244.5px; font-family: Nunito, -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, &quot;Helvetica Neue&quot;, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;, &quot;Segoe UI Symbol&quot;, &quot;Noto Color Emoji&quot;;\"><label>Upload Document Files -&nbsp;</label></div></td></tr><tr><td>&nbsp;__document_name__</td><td>&nbsp;__project_name__</td><td>&nbsp;__upload_document_files__</td></tr></tbody></table>', NULL, '2020-06-15 13:53:20', '2020-06-15 19:23:20', NULL),
(9, 5, '<div class=\"alert alert-warning alert-dismissible fade show\" role=\"alert\">\n		The <strong>__jacky__</strong> is kept to fill dashboard with dummy content, but also to show you how you can add content to it.<br>\n	__image__\n	<button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\"><span aria-hidden=\"true\">×</span></button>\n</div>', NULL, '2020-06-18 12:54:12', '2020-06-18 18:24:12', NULL),
(10, 6, '<div class=\"container\">\n      <div class=\"card-deck mb-3 text-center\">\n        <div class=\"card mb-4 box-shadow\">\n          <div class=\"card-header\">\n            <h4 class=\"my-0 font-weight-normal\">__fname__</h4>\n          </div>\n          <div class=\"card-body\">\n            <h1 class=\"card-title pricing-card-title\">$0 <small class=\"text-muted\">/ mo</small></h1>\n            <ul class=\"list-unstyled mt-3 mb-4\">\n              <li>10 users included</li>\n              <li>2 GB of storage</li>\n              <li>Email support</li>\n              <li>Help center access</li>\n            </ul>\n            <button type=\"button\" class=\"btn btn-lg btn-block btn-outline-primary\">Sign up for free</button>\n          </div>\n        </div>\n        <div class=\"card mb-4 box-shadow\">\n          <div class=\"card-header\">\n            <h4 class=\"my-0 font-weight-normal\">__description__</h4>\n          </div>\n          <div class=\"card-body\">\n            <h1 class=\"card-title pricing-card-title\">$15 <small class=\"text-muted\">/ mo</small></h1>\n            <ul class=\"list-unstyled mt-3 mb-4\">\n              <li>20 users included</li>\n              <li>10 GB of storage</li>\n              <li>Priority email support</li>\n              <li>Help center access</li>\n            </ul>\n            <button type=\"button\" class=\"btn btn-lg btn-block btn-primary\">Get started</button>\n          </div>\n        </div>\n        <div class=\"card mb-4 box-shadow\">\n          <div class=\"card-header\">\n            <h4 class=\"my-0 font-weight-normal\">__dob__</h4>\n          </div>\n          <div class=\"card-body\">\n            <h1 class=\"card-title pricing-card-title\">$29 <small class=\"text-muted\">/ mo</small></h1>\n            <ul class=\"list-unstyled mt-3 mb-4\">\n              <li>30 users included</li>\n              <li>15 GB of storage</li>\n              <li>Phone and email support</li>\n              <li>Help center access</li>\n            </ul>\n            <button type=\"button\" class=\"btn btn-lg btn-block btn-primary\">Contact us</button>\n          </div>\n        </div>\n      </div>\n\n      <footer class=\"pt-4 my-md-5 pt-md-5 border-top\">\n        <div class=\"row\">\n          <div class=\"col-12 col-md\">\n            <img class=\"mb-2\" src=\"https://getbootstrap.com/docs/4.0/assets/brand/bootstrap-solid.svg\" alt=\"\" width=\"24\" height=\"24\">\n            <small class=\"d-block mb-3 text-muted\">© 2017-2018</small>\n          </div>\n          <div class=\"col-6 col-md\">\n            <h5>Features</h5>\n            <ul class=\"list-unstyled text-small\">\n              <li><a class=\"text-muted\" href=\"#\">Cool stuff</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Random feature</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Team feature</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Stuff for developers</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Another one</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Last time</a></li>\n            </ul>\n          </div>\n          <div class=\"col-6 col-md\">\n            <h5>Resources</h5>\n            <ul class=\"list-unstyled text-small\">\n              <li><a class=\"text-muted\" href=\"#\">Resource</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Resource name</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Another resource</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Final resource</a></li>\n            </ul>\n          </div>\n          <div class=\"col-6 col-md\">\n            <h5>About</h5>\n            <ul class=\"list-unstyled text-small\">\n              <li><a class=\"text-muted\" href=\"#\">Team</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Locations</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Privacy</a></li>\n              <li><a class=\"text-muted\" href=\"#\">Terms</a></li>\n            </ul>\n          </div>\n        </div>\n      </footer>\n    </div>', NULL, '2020-06-18 13:07:22', '2020-06-18 18:39:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `input_types`
--

CREATE TABLE `input_types` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `input_types`
--

INSERT INTO `input_types` (`id`, `name`) VALUES
(1, 'text'),
(2, 'password'),
(3, 'number'),
(4, 'textarea'),
(5, 'checkboxinput'),
(6, 'select'),
(7, 'selectmultiple'),
(8, 'select2'),
(9, 'selectmultiple2'),
(10, 'button'),
(11, 'submit'),
(12, 'file'),
(13, 'files'),
(14, 'color'),
(15, 'date'),
(16, 'datetimelocal'),
(17, 'email'),
(18, 'hidden'),
(19, 'imagebutton'),
(20, 'month'),
(21, 'range'),
(22, 'tel'),
(24, 'time');

-- --------------------------------------------------------

--
-- Table structure for table `log_table`
--

CREATE TABLE `log_table` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `log_message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `forms`
--
ALTER TABLE `forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_data`
--
ALTER TABLE `form_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_inputs`
--
ALTER TABLE `form_inputs`
  ADD PRIMARY KEY (`fi_id`);

--
-- Indexes for table `form_record_view`
--
ALTER TABLE `form_record_view`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `input_types`
--
ALTER TABLE `input_types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `forms`
--
ALTER TABLE `forms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `form_data`
--
ALTER TABLE `form_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT for table `form_inputs`
--
ALTER TABLE `form_inputs`
  MODIFY `fi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `form_record_view`
--
ALTER TABLE `form_record_view`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `input_types`
--
ALTER TABLE `input_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
