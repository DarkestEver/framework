<script type="text/javascript">
	$( document ).ready(function() {
    $( "#inputfields" ).sortable();
    //$( "#inputfields" ).disableSelection();
     $("#new_input_field_form").submit(function(){
	 	var outputForm = $(this);
	 	var form_id = $("#hidden_form_id").val();
	 	data = outputForm.serialize();
	 	//console.log(data);
		$.ajax({
	        type: "POST",
	        cache:false,
	        dataType: "text",
	        url: "<?php echo site_url();?>Form/add_new_field/" + form_id,
	        data:data,
	        success: function (data) {
	        	console.log(data);
	            if (data== "1") {
	            	$("#inputfields").append('<li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>'+$("#label").val()+'</li>');
	            }
	            else if (data== "2") 
	            {
	            	alert_message("Field name already exits!!");
	            }
	            else
	            {
	            	alert_message("Please try again.");
	            }
	        },
	        error: function () {
	            alert('Error');
	        }
	    });
	 	return false;
	 });
  } );

$(function() {
    $("#inputype").change(function() {
        alert( $('option:selected').val() );
    });
});

</script>

<?php
$ready_only = "";
if ( isset($form_info )) {
	$ready_only = "readonly";
}

 ?>
	<div class="container">
	
		<div class="row">
		
			<div class="col-md-12">
				

				<div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Basic Card Example</h6>
                </div>
                <div class="card-body">
                	<form class="form-inline" method="POST">
					  
					<?php if (isset($form_info) ) { ?> 
						<div class="form-group mb-2">
					    <label for="staticEmail2" class=""><?php echo $form_info["form_name"] ; ?></label>
					    <input type="hidden" id="hidden_form_id" value="<?php echo $form_info["public_name"] ; ?>">
					  </div>
					  <div class="form-group mx-sm-3 mb-2">
					     <label for="staticEmail2" class=""><?php echo $form_info["public_name"] ; ?></label>
					   
					  </div>
						<!-- Button trigger modal -->
						<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalScrollable">
						  Add Fields
						</button>
					<?php  } 
					else {
						?>
						<div class="form-group mb-2">
					    <label for="staticEmail2" class="sr-only">Form Name</label>
					    <input type="text" class="form-control-plaintext" id="form_name" name="form_name" placeholder="My Form Name"  >
					  </div>
					  <div class="form-group mx-sm-3 mb-2">
					    <label for="inputPassword2" class="sr-only">URL</label>
					    <input type="text" class="form-control-plaintext" id="form_public_url" name="form_public_url" placeholder="form_public_url" >
					  </div>
						<input type="submit" name="submit" value="Create New Form" class="btn btn-primary ">
					<?php  } ?>

					</form> 
					<ul id="inputfields">
						<?php foreach ($input_already_added as $key => $value) {
							echo  '<li class="ui-state-default"><span class="ui-icon ui-icon-arrowthick-2-n-s"></span>'.$value["label"].'</li>';
						}
					  	?>
					</ul>
                </div>
              </div>

			</div>
		</div>
	</div>



<!-- Modal -->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">New Form </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        	<form id="new_input_field_form" class="form">
			  <div class="form-group mx-sm-3 mb-2">
			        <select class="form-control" name="inputype">
				   	<?php foreach ($types as $key => $value) {
				   		echo "<option value=".$value["name"].">".$value["name"]."</option>";
				   	}
				   	?>
				      
				    </select>
			  </div>


			  <div class="form-group mx-sm-3 mb-2">
			    <label for="staticEmail2" class="sr-only">Input Name</label>
			    <input type="text" class="form-control" name="label" id="label" placeholder="Input Name" required>
			  </div>
			  <div class="form-group mx-sm-3 mb-2">
			    <label for="inputPassword2" class="sr-only">placeholder</label>
			    <input type="text" class="form-control" name="placeholder" name="id"  placeholder="placeholder">
			  </div>
			  <div class="form-group mx-sm-3 mb-2">
			    <label for="inputPassword2" class="sr-only">Lenght</label>
			    <input type="number" class="form-control" name="text_lenth" id="text_lenth" placeholder="Text Max Lenth" required="">
			  </div>
			  <div class="form-group mx-sm-3 mb-2">
			    <label for="inputPassword2" class="sr-only">Default Value</label>
			    <input type="text" class="form-control" name="default_value" id="default_value" placeholder="Default Value">
			  </div>
			  <div class="form-group mx-sm-3 mb-2">
			    <label for="inputPassword2" class="sr-only">Css Class</label>
			    <input type="text" class="form-control" name="css_class" id="css_class" placeholder="CSS Class Name">
			  </div>
			  <div class="form-group mx-sm-3 mb-2">
			    <label for="inputPassword2" class="sr-only">Css Style</label>
			    <input type="text" class="form-control" name="css_style" id="css_style" placeholder="CSS Style">
			  </div>
			  <div class="form-group mx-sm-3 mb-2">
			   <div class="form-inline">
				  <input class="form-check-input" type="checkbox" value="1" name="required" id="required">
				  <label class="form-check-label" for="Required"> 
				     Required 
				  </label>
				  <input class="form-check-input" type="checkbox" value="1" name="listed" id="listed" checked>
				  <label class="form-check-label" for="visible"> 
				     Visible 
				  </label> 
				  <input class="form-check-input" type="checkbox" value="1" name="editable" id="editable" checked>
				  <label class="form-check-label" for="Editable"> 
				      Editable 
				  </label> 
				  <input class="form-check-input" type="checkbox" value="1" name="disabled" id="disabled">
				  <label class="form-check-label" for="Required">  
				     Diabled 
				  </label>
				
				</div>
			  </div>
			  <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		        <button class="btn btn-primary" id="add_new_field" >Save changes</button>
		      </div>
			</form>
      </div>
      
    </div>
  </div>
</div>