<div class="container">
    
        <div class="row">
        
            <div class="col-md-12">
                

                <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Basic Card Example</h6>
                </div>
                <div class="card-body">
                    <table id="example" class="table table-responsive" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Public URL</th>
                                    <th>Edit Form</th>
                                    <th>View Form</th>
                                    <th>Data</th>
                                    <th>Record View</th>
                                </tr>
                            </thead>
                             <tbody>
                             <?php foreach ($form_data as $key => $value) { ?>
                             	 <tr>
                                    <td><?php echo $value["form_name"] ;?></td>
                                    <td><?php echo $value["public_name"] ;?></td>
                                    <td><a href="<?php echo site_url()."start/new/". $value["public_name"] ;?>" > link </a></td>
                                    <td><a href="<?php echo site_url()."start/add/". $value["public_name"] ;?>" > link </a></td>
                                    <td><a href="<?php echo site_url()."start/list/". $value["public_name"] ;?>" > link </a></td>
                                    <td><a href="<?php echo site_url()."start/form_record_view/". $value["public_name"] ;?>" > link </a></td>
                                    </tr>
                             <?php } ?>
                               
                            </tbody>
                     </table>
</div>
</div>
</div>
</div>
</div>
