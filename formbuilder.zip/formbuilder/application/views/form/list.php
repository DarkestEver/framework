<div class="container">
  
    <div class="row">
    
      <div class="col-md-12">
        

        <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Basic Card Example</h6>
                </div>
                <div class="card-body">
                    <div id="tableDiv">

                        <table class="table table-sm table-responsive">
                      <thead class="thead-dark">
                        <tr>
                          <?php foreach ($columns as $key => $value) {
                             echo '<th scope="col">'.$value[0].'</th>';

                          }
                          ?>
                          <th>View</th>
                        </tr>
                      </thead>
                      <tbody>
                        
                          <?php 
                    //var_dump($data );
                          foreach ($data as $key => $value) {
                            echo("<tr>");
                            $i = 1;
                            foreach ($value as $key => $val) {
                              if (sizeof($columns) + 1 == $i) {
                                   echo '<th scope="col"><a href='. site_url().'start/view/'.$val.' >View</a></th>';
                              }
                              else
                              {
                               echo '<th scope="col">'.$val.'</th>';  
                              }
                              
                               $i = $i + 1;
                            }
                             echo("<tr>");
                          }
                          ?>

                    </tbody>
                    </table>
                        
                    </div>
</div>
</div>
</div>
</div>
</div>
