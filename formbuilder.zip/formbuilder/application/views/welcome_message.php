
<script>
		$(document).ready(function() {

			var demoInput, example, outputForm;
			outputForm = $('#form-demo-output');
			outputForm.submit(function() { 
				//e.preventDefault();
		    	var data = outputForm.serialize();
		    	//alert(data);
		    	save_data(data);

		    	return false
		    	}
		    );

			formFields = <?php echo $data; ?>;

			//formFields = JSON.stringify(example);
			form = new FormForm( outputForm, formFields );
			form.render();


function save_data(data)
{
	var form_id = 1;
	$.ajax({
        type: "POST",
        cache:false,
        dataType: "text",
        url: "<?php echo site_url();?>Start/add_data_to_form/" + form_id,
        data:data,
        success: function (data) {
            console.log(data);
        },
        error: function () {
            alert('Error');
        }
    });
}


});
/*
name: '',
 * 		label: '', 
 * 		type: 'select',
 * 		'class': '',
 * 		id: null,
 * 		appendLabel: '',
 * 		default: '',
 * 		choices: []

 -----------type----------------
text
password
number
textarea
checkboxinput
select
selectmultiple
select2
selectmultiple2
button
submit
file
*/	
</script>
	<style>
		#input-alert,
		#form-demo-input {
			font-family: Menlo, Monaco, Consolas, "Courier New", monospace;
		}
	</style>



	<div class="container">
	
		<div class="row">
		
			<div class="col-md-12">
				

				<div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Basic Card Example</h6>
                </div>
                <div class="card-body">
                	<form id="form-demo-output" class="form-horizontal">
					</form>  
                </div>
              </div>

			</div>
		</div>
	</div>