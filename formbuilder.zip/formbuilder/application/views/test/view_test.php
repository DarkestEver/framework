<div>
        <h3>Select an image from your computer and upload it to the cloud</h3>

            <form id="input_sheet_upload" method="post"   enctype="multipart/form-data">
            	<input type="hidden" name="modal_country_code" />
            	<input type="hidden" name="modal_edm_id" />
            	<input type="hidden" name="modal_campaign_id" />
            	<input type="hidden" name="modal_language_code" />
                <input type="file" id="csv_file" name="csv_file" size="33" />
                <input type="submit" value="Upload Image" />
            </form>
    </div>