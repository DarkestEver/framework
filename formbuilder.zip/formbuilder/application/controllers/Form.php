<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form extends CI_Controller {

	public function __construct() {
	    parent::__construct();

	    // load base_url
	    $this->load->helper('url');
	     $this->load->helper("input_helper")
;    }

	public function index()
	{
		$this->load->model("Form_builder_model");
		$data = array();
		$field =  array('name' => "form_name", "label" => "Form Name", "type" => "text", "id"=>"form_name");$data[] = $field;	
		$field =  array('name' => "public_name", "label" => "Pulic URL Suffix", "type" => "text", "id"=>"public_name");$data[] = $field;
		//$field =  array('name' => "js", "label" => "Javascript", "type" => "textarea", "id"=>"js");$data[] = $field;	
		//$field =  array('name' => "css", "label" => "CSS", "type" => "textarea", "id"=>"css");$data[] = $field;	
		$field =  array('name' => "submit", "label" => "Submit", "type" => "submit", "id"=>"submit" ,"class" => "btn btn-primary");$data[] = $field;	
		//$field =  array('name' => "file", "label" => "file Name", "type" => "file", "id"=>"file");$data[] = $field;	
		if ($data != 0) {
			$data= json_encode($data);
			$view_data["data"] = $data; 
			$this->load->view('header');
			$this->load->view('welcome_message', $view_data);
			$this->load->view('footer');
		}
		else
		{

		}
	}


	public function add($public_form)
	{
		$this->load->model("Form_builder_model");
		$data = $this->Form_builder_model->get_form($public_form);
		$output_array = array();
		foreach ($data as $key => $value) {
			$output_array[] =  select_choices($value);
		}
		
		//var_dump($data);
		if (sizeof($data) != 0) {
			$output_array= json_encode($output_array);
			$view_data["data"] = $output_array; 
			$view_data["public_form"] = $public_form; 
			$this->load->view('header');
			$this->load->view('form/add', $view_data);
			$this->load->view('footer');
		}
	}

	public function new($public_name="")
	{
		$this->load->model("Form_builder_model");
		if ($public_name=="") {
			
		}
		else
		{
			$data["public_name"] = $public_name;
			$form_info = $this->Form_builder_model->getformInfoByPublicName($public_name);
			if (sizeof($form_info) > 0 ) {
				$data["form_info"] = $form_info[0];
			}
			else
			{
				return;
			}
		
		}
		if ($this->input->post()){

			$postData = $this->input->post();
			if (!isset($postData["form_name"]) && empty($postData["form_name"]) ) {
				return "Name Input Required";
			}

			if (!isset($postData["form_public_url"]) && empty($postData["form_public_url"]) ) {
				return "form_public_url Input Required";
			}

			$form_name = $postData["form_name"];
			$public_name = $postData["form_public_url"];
			$chk =  $this->Form_builder_model->new_form($form_name, $public_name);
			if ($chk) {
				redirect(site_url().'start/new/'.$public_name);
			}
			else
			{

			}
		}



		$input_already_added = $this->Form_builder_model->get_form($public_name);
		$data["input_already_added"] = $input_already_added;
		$types = $this->Form_builder_model->getAllInputTypes();
		$data["types"] = $types;
		$this->load->view('header');
		$this->load->view('form/new', $data);
		$this->load->view('footer');	
	}

	public function add_new_field($public_name)
	{
		if ($this->input->post()){
			$postData = $this->input->post();
			$data = array();
			if (isset($postData["label"]) || !empty($postData["label"])) { $data['label'] = (strip_tags($postData["label"])); }
			if (isset($postData["placeholder"]) || !empty($postData["placeholder"])) { $data['placeholder'] = (strip_tags($postData["placeholder"])); }
			if (isset($postData["text_lenth"]) || !empty($postData["text_lenth"])) { $data['length'] = (strip_tags($postData["text_lenth"])); } else { $data['length'] = "255";}
			if (isset($postData["inputype"]) || !empty($postData["inputype"])) { $data['type'] = (strip_tags($postData["inputype"])); }
			if (isset($postData["default_value"]) || !empty($postData["default_value"])) { $data['default_value'] = (strip_tags($postData["default_value"])); }
			if (isset($postData["css_class"]) || !empty($postData["css_class"])) { $data['htmlClass'] = (strip_tags($postData["css_class"])); }
			if (isset($postData["css_style"]) || !empty($postData["css_style"])) { $data['style'] = (strip_tags($postData["css_style"])); }
			if (isset($postData["required"]) || !empty($postData["required"])) { $data['required'] = (strip_tags($postData["required"])); }
			if (isset($postData["disabled"]) || !empty($postData["disabled"])) { $data['disabled'] = (strip_tags($postData["disabled"])); }

			$field_id = strtolower(str_replace(" ", "_", $data['label']));
			$data["field_id"] = $field_id;
			//echo $field_id; die;
			$this->load->model("Form_builder_model");
			$return = $this->Form_builder_model->add_new_field($public_name, $data);
			echo $return;
		}
		else
		{
			echo "not posted";
		}
	}

	public function list($public_name,$page=0)
	{
		$data["public_name"] = $public_name;
		$this->load->model("Form_builder_model");
		$data = $this->Form_builder_model->list($public_name);

		$this->load->view('header');
		$this->load->view('form/list',$data);
		$this->load->view('footer');
	}

	public function list_json_data($public_name)
	{
		$this->load->model("Form_builder_model");
		$data = $this->Form_builder_model->list($public_name);
		//echo "<pre>";
		echo(json_encode($data));
	}



	public function do_upload($file_name,$max_size='5000',$allowed_types='jpg|jpeg|png|gif'){
        // Set preference
          $directory = "/resources/uploads" .'/' . date("Y").'/'.date("m").'/'.date("d");
          //If the directory doesn't already exists.
          $dir = '.'.$directory;
		  if(!is_dir($dir)){
		    //Create our directory.
		    mkdir($dir , 755, true);
		  }
          $config['upload_path'] = $dir;
          $config['allowed_types'] = $allowed_types;
          $config['max_size'] = $max_size; // max_size in kb
          $config['file_name'] = $file_name;
 
          //Load upload library
          $this->load->library('upload',$config);
		  // File upload
          if($this->upload->do_upload('file')){
            // Get data about the file
            $uploadData = $this->upload->data();
            return $directory. "/". $uploadData['file_name'];
          }
	}


	public function add_data_to_form($public_name)
	{

		if ($this->input->post()){
			$postData = $this->input->post();
			$this->load->model("Form_builder_model");
			$form_id = $this->Form_builder_model->getformIdByPublicName($public_name);
			///////////////Multiple Document uploaf//////////////////
			if (isset($postData['hidden_multiple_file_doc_upload'])) {
				$multiple_file_upload = $postData['hidden_multiple_file_doc_upload'];
				$images_path ="";
				foreach ($multiple_file_upload as $key => $file_input) {
					//echo( $file_input);
				    $countfiles = count($_FILES[$file_input]['name']);
					// Looping all files
			        for($i=0;$i<$countfiles;$i++){		
			        	//echo( $_FILES[$file_input]['name'][$i]);	 
				        if(!empty($_FILES[$file_input]['name'][$i])){
					          // Define new $_FILES array - $_FILES['file']
					          $_FILES['file']['name'] = $_FILES[$file_input]['name'][$i];
					          $_FILES['file']['type'] = $_FILES[$file_input]['type'][$i];
					          $_FILES['file']['tmp_name'] = $_FILES[$file_input]['tmp_name'][$i];
					          $_FILES['file']['error'] = $_FILES[$file_input]['error'][$i];
					          $_FILES['file']['size'] = $_FILES[$file_input]['size'][$i];
					          
					          $images_path .= '||'. $this->do_upload( $_FILES[$file_input]['name'][$i]);
					    }
					    else
					    {
					    	$images_path .= "error";
					    }
					    
				    }
				}
				//echo $file_input;
			    $postData[$file_input] =ltrim( $images_path,'||');   
			}
			///////////////Multiple Document uploaf//////////////////
			if (isset($postData['hidden_multiple_file_upload'])) {
				$multiple_file_upload = $postData['hidden_multiple_file_upload'];
				$images_path ="";
				foreach ($multiple_file_upload as $key => $file_input) {
					//echo( $file_input);
				    $countfiles = count($_FILES[$file_input]['name']);
					// Looping all files
			        for($i=0;$i<$countfiles;$i++){		
			        	//echo( $_FILES[$file_input]['name'][$i]);	 
				        if(!empty($_FILES[$file_input]['name'][$i])){
					          // Define new $_FILES array - $_FILES['file']
					          $_FILES['file']['name'] = $_FILES[$file_input]['name'][$i];
					          $_FILES['file']['type'] = $_FILES[$file_input]['type'][$i];
					          $_FILES['file']['tmp_name'] = $_FILES[$file_input]['tmp_name'][$i];
					          $_FILES['file']['error'] = $_FILES[$file_input]['error'][$i];
					          $_FILES['file']['size'] = $_FILES[$file_input]['size'][$i];
					          
					          $images_path .= '||'. $this->do_upload( $_FILES[$file_input]['name'][$i]);
					    }
					    else
					    {
					    	$images_path .= "error";
					    }
					    
				    }
				}
				//echo $file_input;
			    $postData[$file_input] =ltrim( $images_path,'||');   
			}
			///////////////Create Data for insert//////////////////
			$today = date("Ymdjmyitis");   
            $group_key =  md5(uniqid(rand().$today, true));


			$input_multi = multi_select_inputs();
			$data_to_insert = array();
			foreach ($postData as $key => $value) {
				 
				 if ($key != 0 && !empty($value))
				 {
				 	$f = $this->Form_builder_model->getIdByUUID($key);
					$f_id = $f["fi_id"];
					$input_type =  $f["type"];
				 	if ( in_array($input_type,$input_multi ))
                    {
                    	$input_val = "";
                        //$arr_key = $key;
                        foreach ($value as $k => $v) {
                        	$input_val .= '||'.$v;
                        }
                        $input_val =  ltrim( $input_val,'||');  
                        $row = array(
	                        'f_id' => strip_tags($form_id),
	                        'fi_id' => strip_tags($f_id),
	                        'value' => strip_tags($input_val),
	                        'groups' => $group_key
	                    ); 
	                    $data_to_insert[] = $row;
                    }
                    else
                    {
                    	$row = array(
	                        'f_id' => strip_tags($form_id),
	                        'fi_id' => strip_tags($f_id),
	                        'value' => strip_tags($value),
	                        'groups' => $group_key
	                    ); 
	                    $data_to_insert[] = $row;
                    }
				 }
			}
			$this->Form_builder_model->set_form_data( $data_to_insert);
			return 0;
		}
	}

	public function form_list()
	{
		$this->load->model("Form_builder_model");
		$form_data = $this->Form_builder_model->getAllForms();

		$data["form_data"]=$form_data;
		$this->load->view('header');
		$this->load->view('form/form_list',$data);
		$this->load->view('footer');
		
	}

	public function form_record_view($public_name)
	{
		$this->load->model("Form_builder_model");
		if ($public_name=="") {
			
		}
		else
		{
			$data["public_name"] = $public_name;
			$form_info = $this->Form_builder_model->getformInfoByPublicName($public_name);
			if (sizeof($form_info) > 0 ) {
				$data["form_info"] = $form_info[0];
			}
			else
			{
				return;
			}		
		}
		//print_r($form_info); die;
		$form_id = $form_info[0]["id"];
		$data["form_id"] = $form_id;
		$view_html = $this->Form_builder_model->getViewByFormID($form_id);
		$data["view_html"] = $view_html;
		$input_already_added = $this->Form_builder_model->get_form($public_name);
		$data["input_fields"] = $input_already_added;
		
		$this->load->view('header');
		$this->load->view('form/form_record_view', $data);
		$this->load->view('footer');
		
	}

	public function add_view_add()
	{
		if ($this->input->post()){
			$postData = $this->input->post();
			$this->load->model("Form_builder_model");
			$this->Form_builder_model->add_update_view_html($postData);
			echo 1;
		}
	}

	public function view($group_id)
	{
		$this->load->model("Form_builder_model");
		$form_id = $this->Form_builder_model->getFormIdByGroup($group_id);
		$html = $this->Form_builder_model->getViewByFormID($form_id);
		if (!empty($html)) {
			$data = $this->Form_builder_model->getSingleRecordByGroupID($group_id,$form_id);
			//print_r($data);
			if ($data != 0) {
				//for ($i=0; $i < sizeof($data); $i++) { 
				foreach ($data as $key => $datavalue) {
					$replace_html = get_input_html($datavalue["type"],$datavalue["value"] );
					$html = str_replace("__". $datavalue["field_id"] ."__",$replace_html,$html);	
				}	
			}
		}
		$data1["html"]=$html;
		//$data1["replace"] = json_encode($data);
		$this->load->view('header');
		$this->load->view('form/view',$data1);
		$this->load->view('footer');
	}

	public function edit($group_id="")
	{
		$this->load->model("Form_builder_model");
		if ($group_id=="") {
			
		}
		else
		{
			$form_id = $this->Form_builder_model->getFormIdByGroup($group_id);
			if ($form_id != 0 ) {
				
			}
			else
			{
				return;
			}
		}
		
		$filled_data = $this->Form_builder_model->getSingleRecordByGroupID($group_id,$form_id);
		$data["filled_data"] = $filled_data;
		$input_already_added = $this->Form_builder_model->getFormByID($form_id);
		$output_array = array();
		foreach ($input_already_added as $key => $value) {
			$output_array[] =  select_choices($value);
		}
		$data["input_fields"] = $output_array;
		$this->load->view('header');
		$this->load->view('form/edit', $data);
		$this->load->view('footer');	
	}

}
