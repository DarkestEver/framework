<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fileeditor extends CI_Controller {

	public function __construct() {
	    parent::__construct();

	    // load base_url
	    //$this->load->helper('url');
	    
	    
	}

public function index()
{
	$this->load->helper("fileeditor_helper");
	$permissions = 'newfile,newdir,editfile,deletefile,deletedir,renamefile,renamedir,changepassword,uploadfile';
	$pattern = 'txt|php|htm|html|js|css|tpl|md|xml|json';
	editor(APPPATH.'third_party',$permissions, $pattern);
	$permissions = explode(",", $permissions);
	$data["permissions"] = $permissions;
	$this->load->view('header');
	$this->load->view("fileeditor/index", $data);
	$this->load->view('footer');	 
}

public function test()
{
	
	$this->load->view("fileeditor/test");
	 
}



}
?>