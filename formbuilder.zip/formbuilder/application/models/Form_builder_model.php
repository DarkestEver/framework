<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form_builder_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function new_form($form_name, $public_name)
        {

           $this->db->where('form_name', $form_name);
           $this->db->or_where('public_name', $public_name);
           $this->db->from('forms');
           $chk =  $this->db->count_all_results(); 
           //echo $chk; die;
           if ($chk == 0 ) {
               $data = array(
                            'form_name' => strip_tags($form_name),
                            'public_name' => strip_tags($public_name)
                        );
                 $this->db->insert("forms", $data);
                $chk =$this->db->insert_id();
                if ($chk > 0) {
                   return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return "already exits";
            }
        }


        public function getformInfoByPublicName($public_name)
        {
            $sql = "SELECT * FROM forms where public_name = '".$public_name."'";
            $query = $this->db->query($sql);
            if ($query->num_rows() > 0) {
                return  $query->result_array();
            } else {
                return 0;
            }
        }

        public function getformIdByPublicName($public_name)
        {
            $sql = "SELECT * FROM forms where public_name = '".$public_name."'";
            $query = $this->db->query($sql);
            if ($query->num_rows() > 0) {
                return  $query->result_array()[0]["id"];
            } else {
                return 0;
            }
        }
        public function get_form($public_name) {
          
           $form_id = $this->getformIdByPublicName($public_name);

            $sql = "SELECT uuid as name, label, type, htmlClass as class, field_id as id,  default_value as 'default' , placeholder , case when required = 1 then 'required' else '' end as required , length  FROM form_inputs where form_id = '".$form_id."'";
            $query = $this->db->query($sql);
            if ($query->num_rows() > 0) {
                return $query->result_array();
            } else {
                return array();
            }
        }

        public function getFormByID($form_id) {
          
           //$form_id = $this->getformIdByPublicName($public_name);

            $sql = "SELECT uuid as name, label, type, htmlClass as class, field_id as id,  default_value as 'default' , placeholder , case when required = 1 then 'required' else '' end as required , length  FROM form_inputs where form_id = '".$form_id."'";
            $query = $this->db->query($sql);
            if ($query->num_rows() > 0) {
                return $query->result_array();
            } else {
                return array();
            }
        }

        public function set_form_data( $data)
        {
            foreach ($data as $key => $value) {
                $this->db->insert("form_data", $value);
            }
        }

        public function getIdByUUID($uuid)
        {
            $sql = "SELECT * FROM form_inputs where uuid = '".$uuid."'";
            $query = $this->db->query($sql);
            if ($query->num_rows() > 0) {
                return  $query->result_array()[0];
            } else {
                return 0;
            }
        }


        public function getAllInputTypes()
        {
            $sql = "SELECT * FROM input_types";
            $query = $this->db->query($sql);
            if ($query->num_rows() > 0) {
                return  $query->result_array();
            } else {
                return 0;
            }
        }

        public function add_new_field($public_name, $data)
        {
            $form_id = $this->getformIdByPublicName($public_name);

            if ($form_id > 0) {
               $this->db->where('form_id', $form_id);
               $this->db->where('label', $data['label']);
               $this->db->from('form_inputs');
               $chk =  $this->db->count_all_results(); 
               if ($chk == 0) {
                    $data["form_id"] = $form_id;
                    $this->db->insert("form_inputs", $data);
                    return 1;
                    //$this->db->insert_id();
               }
               else
               {
                return 2;
               }
               
            }
            else
            {
                return 0;
            }
        }

        public function list($public_name, $offset=0)
        {
            $form_id = $this->getformIdByPublicName($public_name);
            if ($form_id > 0) {
                $data =array();
                $offset = "";
                $limit = 25;
                if ($offset != 0) {
                    $offset = "offset ". ($offset*$limit);
                }
                $group = "select distinct groups from form_data where f_id= ".$form_id." order by createddate desc limit 25  ". $offset ;
                $query_group = $this->db->query($group);
                if ($query_group->num_rows() > 0) {
                    $grouping =   $query_group->result_array();
                    $sql_listed = "select fi_id, label, type from form_inputs where listed = 1 and  form_id = ".$form_id." ;";
                    $query_listed = $this->db->query($sql_listed);
                    $listing =   $query_listed->result_array();
                    
                    foreach ($grouping as $grkey => $gr) {
                        $group_name = $gr["groups"];
                        $rows = array();
                        
                        foreach ($listing as $lskey => $ls) {
                          $label = $ls["label"];
                          $fl_id = $ls["fi_id"];
                          
                          $sql = "SELECT fd.value  FROM `form_data` fd where  fi_id = ".$fl_id." and  fd.groups = '".$gr["groups"]."'";
                          $query = $this->db->query($sql);

                           if ($query->num_rows() > 0) {
                            $row =   $query->result_array();
                            $replace_html = get_input_html($ls["type"],$row[0]["value"] );
                    
                            $rows[] = $replace_html;
                           }
                           else
                           {
                             $rows[] = "";
                           }

                        }
                        $rows[] = $gr["groups"];
                        $data[] = $rows;
                    }

                    $headers = array();
                    foreach ($listing as $lskey => $ls) {
                        $headers[] =   [$ls["label"]];
                    }
                    $data1=array();
                    $data1["data"] = $data;
                    $data1["draw"] = 1;
                    $data1["recordsTotal"] = 40;
                    $data1["recordsFiltered"] = 40;
                    $data1["columns"] = $headers;

                } else {
                    return 0;
                }
                return $data1;
            }
            else
            {
                return 0;
            }
        }

        public function getSingleRecordByGroupID($groups_id, $form_id)
        {
            $data =array();
            
            $sql_listed = "select label,field_id ,fi_id, type from form_inputs where form_id = ".$form_id;
            $query_listed = $this->db->query($sql_listed);
            if ($query_listed->num_rows() > 0) {
                $listing =   $query_listed->result_array();
                foreach ($listing as $key => $ls) {
                    $group = "select fd.value from form_data fd where groups = '".$groups_id."' and fi_id = '".$ls["fi_id"]."'";
                    $query_group = $this->db->query($group);
                    
                    if ($query_group->num_rows() > 0) {
                        $dvalue =  $query_group->result_array()[0]['value'];
                        $data[] = array("field_id" => $ls['field_id'], "value" => $dvalue, "type" => $ls["type"]);
                    }
                    else
                    {
                       $data[] = array("field_id" => $ls['field_id'], "value" => "", "type" => $ls["type"]);
                    }
                    
                }
                return $data;
            }
            else
            {
                return 0;
            }
        }

    public function getFormIdByGroup($groups_id)
    {
        $group = "select fd.f_id from form_data fd where groups = '".$groups_id."'";
        $query_group = $this->db->query($group);
        if ($query_group->num_rows() > 0) {
            return  $query_group->result_array()[0]['f_id'];
        }
        else
        {
            return 0;
             //$data[$ls['field_id']] =  "";
        }
    }


    public function getViewByFormID($form_id)
    {
        $group = "select html from form_record_view fd where f_id = ".$form_id;
        $query_group = $this->db->query($group);
        if ($query_group->num_rows() > 0) {
            return  $query_group->result_array()[0]['html'];
        }
        else
        {
            return 0;
             //$data[$ls['field_id']] =  "";
        }
    }

    public function getAllForms()
    {
        //$this->db->where('form_name', $form_name);
        //$this->db->or_where('public_name', $public_name);
        return $this->db->from('forms')->get()->result_array();
    }

    public function add_update_view_html($data)
    {
        $f_id = $data["f_id"];

        $this->db->where('f_id', $f_id);
        $this->db->from('form_record_view');
        $chk =  $this->db->count_all_results();
        if ($chk == 0) {
            $this->db->insert('form_record_view', $data);
        }
        else
        {
            $this->db->where('f_id', $f_id);
            $this->db->update('form_record_view', $data);
        }

    }
    
}

